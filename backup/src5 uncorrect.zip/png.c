
// png.c — загрузка PNG, создание спрайт-ректов и отрисовка (uv4/xform), совместимо с текущим png.h/level.c/graphics.c
#include "png.h"
#include <pspgu.h>
#include <pspgum.h>
#include <pspkernel.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

// ===== stb_image: публичный API =====
#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO
#define STBI_ONLY_PNG
#include "stb_image.h"

// ===== Вспомогательные вещи =====
static inline float clamp01f(float v) {
    if (v < 0.0f) return 0.0f;
    if (v > 1.0f) return 1.0f;
    return v;
}

// Вершинный формат: float (как в исходнике)
typedef struct {
    float u, v;
    unsigned int color;
    float x, y, z;
} TextureVertex;

// Локальная настройка GU для безопасной отрисовки спрайта,
// используется если вызывающий код не делает батч-проход.
static void png_state_apply_default(void) {
    sceGuEnable(GU_TEXTURE_2D);
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
    sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA);
    sceGuTexFilter(GU_LINEAR, GU_LINEAR);
    sceGuTexWrap(GU_CLAMP, GU_CLAMP);
    sceGuColor(0xFFFFFFFF);
}

static void png_bind_texture(texture_t* tex) {
    // Предполагаем 32-битную RGBA
    sceGuTexMode(tex->format, 0, 0, 0);
    sceGuTexImage(0, tex->width, tex->height, tex->width, tex->data);
}

// ===== Загрузка текстуры из файла =====
texture_t* png_load_texture(const char* path) {
    if (!path) return NULL;

    // Попытка открыть как есть
    FILE* file = fopen(path, "rb");
    if (!file) {
        // Альтернатива: убрать/добавить ведущий слэш
        if (path[0] == '/') {
            file = fopen(path + 1, "rb");
        } else {
            char alt[512];
            snprintf(alt, sizeof(alt), "/%s", path);
            file = fopen(alt, "rb");
        }
        if (!file) {
            printf("png_load_texture: cannot open file: %s\n", path);
            return NULL;
        }
    }

    // Читаем весь файл в память
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    if (file_size <= 0) { fclose(file); return NULL; }
    fseek(file, 0, SEEK_SET);

    stbi_uc* file_buf = (stbi_uc*)malloc((size_t)file_size);
    if (!file_buf) { fclose(file); return NULL; }
    size_t readn = fread(file_buf, 1, (size_t)file_size, file);
    fclose(file);
    if (readn != (size_t)file_size) { free(file_buf); return NULL; }

    int w=0, h=0, comp=0;
    stbi_uc* rgba = stbi_load_from_memory(file_buf, (int)file_size, &w, &h, &comp, 4);
    free(file_buf);
    if (!rgba || w <= 0 || h <= 0) {
        if (rgba) stbi_image_free(rgba);
        return NULL;
    }

    // PSP обычно требует размеры степени двойки в sceGuTexImage
    int pot_w = 1, pot_h = 1;
    while (pot_w < w) pot_w <<= 1;
    while (pot_h < h) pot_h <<= 1;

    texture_t* tex = (texture_t*)malloc(sizeof(texture_t));
    if (!tex) { stbi_image_free(rgba); return NULL; }

    tex->width = pot_w;
    tex->height = pot_h;
    tex->actual_width = w;
    tex->actual_height = h;
    tex->format = GU_PSM_8888;

    size_t tex_bytes = (size_t)pot_w * (size_t)pot_h * 4u;
    tex->data = memalign(16, tex_bytes);
    if (!tex->data) { free(tex); stbi_image_free(rgba); return NULL; }
    // Обнулим паддинг-область
    memset(tex->data, 0, tex_bytes);

    // Копируем построчно RGBA в верхний левый угол POT-текстуры
    for (int y = 0; y < h; ++y) {
        memcpy((unsigned char*)tex->data + (size_t)y * (size_t)pot_w * 4u,
               (const unsigned char*)rgba + (size_t)y * (size_t)w * 4u,
               (size_t)w * 4u);
    }

    stbi_image_free(rgba);
    return tex;
}

void png_free_texture(texture_t* tex) {
    if (!tex) return;
    if (tex->data) free(tex->data);
    free(tex);
}

// ===== Создание нормализованного sprite rect =====
sprite_rect_t png_create_sprite_rect(texture_t* tex, int x, int y, int w, int h) {
    sprite_rect_t r;
    if (!tex || tex->width <= 0 || tex->height <= 0) {
        r.u = r.v = 0.0f;
        r.width = r.height = 0.0f;
        return r;
    }
    // ВНИМАНИЕ: нормализуем по POT-размеру, потому что sceGuTexImage получал pot_w/pot_h
    r.u = (float)x / (float)tex->width;
    r.v = (float)y / (float)tex->height;
    r.width  = (float)w / (float)tex->width;
    r.height = (float)h / (float)tex->height;
    return r;
}

// ===== Внутренний рендер с 4 углами UV на TRIANGLE_STRIP =====
static void png_draw_sprite_uv4_impl(texture_t* tex,
                                     float u_tl, float v_tl,
                                     float u_tr, float v_tr,
                                     float u_bl, float v_bl,
                                     float u_br, float v_br,
                                     float x, float y, float w, float h) {
    // Нормализованные UV → в пикселях текстуры (по POT)
    float U_TL = clamp01f(u_tl) * (float)tex->width;
    float V_TL = clamp01f(v_tl) * (float)tex->height;
    float U_TR = clamp01f(u_tr) * (float)tex->width;
    float V_TR = clamp01f(v_tr) * (float)tex->height;
    float U_BL = clamp01f(u_bl) * (float)tex->width;
    float V_BL = clamp01f(v_bl) * (float)tex->height;
    float U_BR = clamp01f(u_br) * (float)tex->width;
    float V_BR = clamp01f(v_br) * (float)tex->height;

    TextureVertex* v = (TextureVertex*)sceGuGetMemory(4 * sizeof(TextureVertex));

    // Порядок TRIANGLE_STRIP: TL, BL, TR, BR
    v[0].u = U_TL; v[0].v = V_TL; v[0].color = 0xFFFFFFFF; v[0].x = x;     v[0].y = y;     v[0].z = 0.0f;
    v[1].u = U_BL; v[1].v = V_BL; v[1].color = 0xFFFFFFFF; v[1].x = x;     v[1].y = y+h;   v[1].z = 0.0f;
    v[2].u = U_TR; v[2].v = V_TR; v[2].color = 0xFFFFFFFF; v[2].x = x+w;   v[2].y = y;     v[2].z = 0.0f;
    v[3].u = U_BR; v[3].v = V_BR; v[3].color = 0xFFFFFFFF; v[3].x = x+w;   v[3].y = y+h;   v[3].z = 0.0f;

    sceGuDrawArray(GU_TRIANGLE_STRIP, GU_TEXTURE_32BITF | GU_COLOR_8888 | GU_VERTEX_32BITF | GU_TRANSFORM_2D, 4, 0, v);
}

// ===== Публичные функции рисования =====
void png_draw_sprite(texture_t* tex, sprite_rect_t* sprite, float x, float y, float w, float h) {
    if (!tex || !sprite) return;

    // Включаем состояние локально (без батча)
    png_state_apply_default();
    png_bind_texture(tex);

    float u1 = clamp01f(sprite->u);
    float v1 = clamp01f(sprite->v);
    float u2 = clamp01f(u1 + sprite->width);
    float v2 = clamp01f(v1 + sprite->height);

    png_draw_sprite_uv4_impl(tex, u1, v1,  // TL
                                   u2, v1,  // TR
                                   u1, v2,  // BL
                                   u2, v2,  // BR
                                   x, y, w, h);

    // Возврат к состоянию без текстур
    sceGuDisable(GU_TEXTURE_2D);
    sceGuDisable(GU_BLEND);
}

void png_draw_sprite_uv4(texture_t* tex,
                         float u_tl, float v_tl,
                         float u_tr, float v_tr,
                         float u_bl, float v_bl,
                         float u_br, float v_br,
                         float x, float y, float w, float h) {
    if (!tex) return;
    png_state_apply_default();
    png_bind_texture(tex);
    png_draw_sprite_uv4_impl(tex, u_tl, v_tl, u_tr, v_tr, u_bl, v_bl, u_br, v_br, x, y, w, h);
    sceGuDisable(GU_TEXTURE_2D);
    sceGuDisable(GU_BLEND);
}

void png_draw_sprite_xform(texture_t* tex, sprite_rect_t* sprite,
                           float x, float y, float w, float h,
                           png_xform_t xform) {
    if (!tex || !sprite) return;
    png_state_apply_default();
    png_bind_texture(tex);

    float u1 = clamp01f(sprite->u);
    float v1 = clamp01f(sprite->v);
    float u2 = clamp01f(u1 + sprite->width);
    float v2 = clamp01f(v1 + sprite->height);

    // Базовые углы
    float U_TL=u1, V_TL=v1;
    float U_TR=u2, V_TR=v1;
    float U_BL=u1, V_BL=v2;
    float U_BR=u2, V_BR=v2;

    switch (xform) {
        case PNG_XFORM_IDENTITY:
            // без изменений
            break;
        case PNG_XFORM_FLIP_X:
            // меняем левый/правый
            U_TL = u2; U_TR = u1;
            U_BL = u2; U_BR = u1;
            break;
        case PNG_XFORM_ROT_90:
            // Поворот по часовой: TL<-BL, TR<-TL, BR<-TR, BL<-BR
            {
                float tU_TL=U_TL, tV_TL=V_TL;
                float tU_TR=U_TR, tV_TR=V_TR;
                float tU_BL=U_BL, tV_BL=V_BL;
                float tU_BR=U_BR, tV_BR=V_BR;
                U_TL=tU_BL; V_TL=tV_BL;
                U_TR=tU_TL; V_TR=tV_TL;
                U_BR=tU_TR; V_BR=tV_TR;
                U_BL=tU_BR; V_BL=tV_BR;
            }
            break;
        case PNG_XFORM_ROT_270:
            // Поворот против часовой: TL<-TR, TR<-BR, BR<-BL, BL<-TL
            {
                float tU_TL=U_TL, tV_TL=V_TL;
                float tU_TR=U_TR, tV_TR=V_TR;
                float tU_BL=U_BL, tV_BL=V_BL;
                float tU_BR=U_BR, tV_BR=V_BR;
                U_TL=tU_TR; V_TL=tV_TR;
                U_TR=tU_BR; V_TR=tV_BR;
                U_BR=tU_BL; V_BR=tV_BL;
                U_BL=tU_TL; V_BL=tV_TL;
            }
            break;
        default:
            // неизвестное преобразование — рендерим как есть
            break;
    }

    png_draw_sprite_uv4_impl(tex, U_TL, V_TL, U_TR, V_TR, U_BL, V_BL, U_BR, V_BR, x, y, w, h);
    sceGuDisable(GU_TEXTURE_2D);
    sceGuDisable(GU_BLEND);
}
