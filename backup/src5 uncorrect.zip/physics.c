// physics.c - Портированная физика из Ball.java (ПОЛНАЯ ВЕРСИЯ С УРОВНЯМИ)
#include "types.h"
#include "level.h"
#include <stdlib.h>

// Дополнительные константы физики из BounceConst.java
#define JUMP_STRENGTH -67           // было JUMP_SPEED 67
#define JUMP_STRENGTH_INC -10       // было неправильно
#define JUMP_BONUS_STRENGTH -80

#define NORMAL_GRAVITY_ACCELL 4     // было GRAVITY_NORMAL 4
#define LARGE_GRAVITY_ACCELL 3      // было GRAVITY_LARGE 3

#define NORMAL_MAX_GRAVITY 80       // было gravity = 80
#define LARGE_MAX_GRAVITY 38        // было gravity = 38

#define MAX_TOTAL_SPEED 150         // было MAX_SPEED 150
#define HORZ_ACCELL 6              // было ACCELERATION 6  
#define FRICTION_DECELL 4          // было FRICTION 4
#define MAX_HORZ_SPEED 50          // было maxSpeed = 50
#define MAX_HORZ_BONUS_SPEED 100   // было maxSpeed = 100

#define BOUNCE_NUMERATOR -1
#define BOUNCE_DENOMINATOR 2
#define MIN_BOUNCE_SPEED 10
#define ROOF_COLLISION_SPEED 20

// Инициализация игрока (ОБНОВЛЕНО)
void player_init(Player* p, int x, int y, int sizeState) {
    p->xPos = x;
    p->yPos = y;
    p->xSpeed = 0;
    p->ySpeed = 0;
    p->direction = 0;
    p->jumpOffset = 0;
    p->ballState = BALL_STATE_NORMAL;
    p->sizeState = sizeState;
    
    // Установка размера в зависимости от состояния
    if (sizeState == SMALL_SIZE_STATE) {
        p->ballSize = NORMAL_SIZE;
        p->mHalfBallSize = HALF_NORMAL_SIZE;
    } else if (sizeState == LARGE_SIZE_STATE) {
        p->ballSize = ENLARGED_SIZE;
        p->mHalfBallSize = HALF_ENLARGED_SIZE;
    }
    
    p->mGroundedFlag = 0;
    p->mCDRubberFlag = 0;
    p->mCDRampFlag = 0;
    
    p->speedBonusCntr = 0;
    p->gravBonusCntr = 0;
    p->jumpBonusCntr = 0;
    p->slideCntr = 0;
}

// Увеличение мяча (портировано из enlargeBall()) - ИСПРАВЛЕНО
void enlarge_ball(Player* p) {
    if (p->sizeState == LARGE_SIZE_STATE) return; // Уже большой
    
    p->sizeState = LARGE_SIZE_STATE;
    p->ballSize = ENLARGED_SIZE;
    p->mHalfBallSize = HALF_ENLARGED_SIZE;
    
    // ИСПРАВЛЕНО: убрали инверсию логики
    int offset = 2;
    while (check_collision_at(p, p->xPos, p->yPos)) {  // Было !check_collision_at
        p->yPos -= offset;
        offset++;
        if (offset > 10) break; // Защита от бесконечного цикла
    }
}

// Уменьшение мяча (портировано из shrinkBall())
void shrink_ball(Player* p) {
    if (p->sizeState == SMALL_SIZE_STATE) return; // Уже маленький
    
    p->sizeState = SMALL_SIZE_STATE;
    p->ballSize = NORMAL_SIZE;
    p->mHalfBallSize = HALF_NORMAL_SIZE;
    
    // Простая проверка позиции после уменьшения
    if (!check_collision_at(p, p->xPos, p->yPos + 2)) {
        p->yPos += 2;
    }
}

// Лопание мяча (портировано из popBall())
void pop_ball(Player* p) {
    p->ballState = BALL_STATE_POPPED;
    p->xSpeed = 0;
    p->ySpeed = 0;
    
    // Сброс бонусов
    p->speedBonusCntr = 0;
    p->gravBonusCntr = 0;
    p->jumpBonusCntr = 0;
}

// Установка направления (битовые флаги)
void set_direction(Player* p, int dir) {
    if (dir == MOVE_LEFT || dir == MOVE_RIGHT || dir == MOVE_UP) {
        p->direction |= dir;
    }
}

// Сброс направления
void release_direction(Player* p, int dir) {
    if (dir == MOVE_LEFT || dir == MOVE_RIGHT || dir == MOVE_UP) {
        p->direction &= (dir ^ 0xFFFFFFFF);
    }
}

// Проверка коллизий с тайловой системой (ОБНОВЛЕНО)
int check_collision_at(Player* p, int x, int y) {
    // Границы уровня (по фактической карте)
    int levelW = g_level.width * TILE_SIZE;
    int levelH = g_level.height * TILE_SIZE;
    if (x < 0 || y < 0 || x + p->ballSize > levelW || y + p->ballSize > levelH) {
        return 0; // Коллизия с границами уровня
    }
    
    // Используем новую тайловую систему
    return level_check_collision_at_pixel(x, y, p->ballSize, p->ballSize);
}

// Основное обновление физики (ИСПРАВЛЕННОЕ по Ball.java)
void player_update(Player* p) {
    if (p->ballState == 2) return; // Если мяч лопнул
    
    int gravity, gravityStep;
    int maxSpeed;
    int reverseGrav = 0;
    
    // ИСПРАВЛЕНО: правильные константы из BounceConst
    if (p->ballSize == 16) {
        gravity = LARGE_MAX_GRAVITY;        // 38
        gravityStep = LARGE_GRAVITY_ACCELL; // 3
    } else {
        gravity = NORMAL_MAX_GRAVITY;        // 80
        gravityStep = NORMAL_GRAVITY_ACCELL; // 4
    }
    
    // Бонус гравитации (обратная гравитация)
    if (p->gravBonusCntr > 0) {
        reverseGrav = 1;
        gravity *= -1;
        gravityStep *= -1;
        p->gravBonusCntr--;
    }
    
    // Счётчик скольжения
    p->slideCntr++;
    if (p->slideCntr == 3) {
        p->slideCntr = 0;
    }
    
    // Ограничение скорости (ИСПРАВЛЕНО)
    if (p->ySpeed < -MAX_TOTAL_SPEED) p->ySpeed = -MAX_TOTAL_SPEED;
    else if (p->ySpeed > MAX_TOTAL_SPEED) p->ySpeed = MAX_TOTAL_SPEED;
    if (p->xSpeed < -MAX_TOTAL_SPEED) p->xSpeed = -MAX_TOTAL_SPEED;
    else if (p->xSpeed > MAX_TOTAL_SPEED) p->xSpeed = MAX_TOTAL_SPEED;
    
    // === ФИЗИКА ПО ОСИ Y ===
    int ySteps = abs(p->ySpeed) / 10;
    for (int i = 0; i < ySteps; i++) {
        int yStep = 0;
        if (p->ySpeed != 0) {
            yStep = (p->ySpeed < 0) ? -1 : 1;
        }
        
        if (check_collision_at(p, p->xPos, p->yPos + yStep)) {
            p->yPos += yStep;
            p->mGroundedFlag = 0;
        } else {
            // Коллизия - отскок (ИСПРАВЛЕНО по оригинальным константам)
            if (yStep > 0 || (reverseGrav && yStep < 0)) {
                // Используем правильные константы отскока
                p->ySpeed = p->ySpeed * BOUNCE_NUMERATOR / BOUNCE_DENOMINATOR; // * -1 / 2
                p->mGroundedFlag = 1;
                
                // Обработка прыжка при касании земли
                if (p->mCDRubberFlag && (p->direction & MOVE_UP)) {
                    p->mCDRubberFlag = 0;
                    if (reverseGrav) {
                        p->jumpOffset += JUMP_STRENGTH_INC;  // -10
                    } else {
                        p->jumpOffset += -JUMP_STRENGTH_INC; // +10
                    }
                } else if (p->jumpBonusCntr == 0) {
                    p->jumpOffset = 0;
                }
                
                // Минимальная скорость отскока (ИСПРАВЛЕНО)
                if (p->ySpeed < MIN_BOUNCE_SPEED && p->ySpeed > -MIN_BOUNCE_SPEED) {
                    if (reverseGrav) {
                        p->ySpeed = -MIN_BOUNCE_SPEED;
                    } else {
                        p->ySpeed = MIN_BOUNCE_SPEED;
                    }
                }
                break;
            }
            
            if (yStep < 0 || (reverseGrav && yStep > 0)) {
                if (reverseGrav) {
                    p->ySpeed = -ROOF_COLLISION_SPEED;
                } else {
                    p->ySpeed = ROOF_COLLISION_SPEED;
                }
            }
        }
    }
    
    // Применение гравитации (ИСПРАВЛЕНО)
    if (reverseGrav) {
        if (gravityStep == -2 && p->ySpeed < gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed > gravity) p->ySpeed = gravity;
        } else if (!p->mGroundedFlag && p->ySpeed > gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed < gravity) p->ySpeed = gravity;
        }
    } else {
        if (gravityStep == -2 && p->ySpeed > gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed < gravity) p->ySpeed = gravity;
        } else if (!p->mGroundedFlag && p->ySpeed < gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed > gravity) p->ySpeed = gravity;
        }
    }
    
    // === УПРАВЛЕНИЕ ГОРИЗОНТАЛЬНЫМ ДВИЖЕНИЕМ === (ИСПРАВЛЕНО)
    maxSpeed = (p->speedBonusCntr > 0) ? MAX_HORZ_BONUS_SPEED : MAX_HORZ_SPEED;
    if (p->speedBonusCntr > 0) p->speedBonusCntr--;
    
    if ((p->direction & MOVE_RIGHT) && p->xSpeed < maxSpeed) {
        p->xSpeed += HORZ_ACCELL;
    } else if ((p->direction & MOVE_LEFT) && p->xSpeed > -maxSpeed) {
        p->xSpeed -= HORZ_ACCELL;
    } else if (p->xSpeed > 0) {
        p->xSpeed -= FRICTION_DECELL;
    } else if (p->xSpeed < 0) {
        p->xSpeed += FRICTION_DECELL;
    }
    
    // === ПРЫЖОК === (ИСПРАВЛЕНО с правильными константами)
    if (p->mGroundedFlag && (p->direction & MOVE_UP)) {
        if (reverseGrav) {
            p->ySpeed = -JUMP_STRENGTH + p->jumpOffset; // 67 + offset
        } else {
            p->ySpeed = JUMP_STRENGTH + p->jumpOffset;  // -67 + offset
        }
        p->mGroundedFlag = 0;
        
        // ВАЖНО: сразу сбрасываем флаг прыжка после выполнения
        p->direction &= ~MOVE_UP;
    }
    
    // === ФИЗИКА ПО ОСИ X ===
    int xSteps = abs(p->xSpeed) / 10;
    for (int i = 0; i < xSteps; i++) {
        int xStep = 0;
        if (p->xSpeed != 0) {
            xStep = (p->xSpeed < 0) ? -1 : 1;
        }
        
        if (check_collision_at(p, p->xPos + xStep, p->yPos)) {
            p->xPos += xStep;
        } else {
            // Коллизия по X - отскок (ИСПРАВЛЕНО с защитой от деления на ноль)
            if (p->xSpeed != 0) {  // ДОБАВЛЕНА защита
                p->xSpeed = -(p->xSpeed >> 1);
            }
        }
    }
    
    // Границы уровня по X
    { int levelW = g_level.width * TILE_SIZE;
      if (p->xPos < 0) p->xPos = 0;
      if (p->xPos > levelW - p->ballSize) p->xPos = levelW - p->ballSize; }
    
    // Сброс флагов коллизий
    p->mCDRubberFlag = 0;
    p->mCDRampFlag = 0;
}