#ifndef PNG_H_INCLUDED
#define PNG_H_INCLUDED

#include <pspgu.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct texture_s {
    int width;          /* real image width in pixels */
    int height;         /* real image height in pixels */
    int actual_width;   /* same as width; kept for backward compatibility */
    int actual_height;  /* same as height; kept for backward compatibility */
    int format;         /* GU_PSM_* */
    void* data;         /* pixel buffer (RGBA8888) */
} texture_t;

/* Normalized sub-rect inside a texture (UV space [0..1]) */
typedef struct sprite_rect_s {
    float u;
    float v;
    float width;
    float height;
} sprite_rect_t;

typedef enum {
    PNG_XFORM_IDENTITY = 0,
    PNG_XFORM_FLIP_X   = 1,
    PNG_XFORM_ROT_90   = 2,
    PNG_XFORM_ROT_180  = 3,
    PNG_XFORM_ROT_270  = 4
} png_xform_t;

/* Lifetime ------------------------------------------------------------ */
texture_t* png_load_texture(const char* path);
void       png_free_texture(texture_t* tex);

/* Utilities ----------------------------------------------------------- */
sprite_rect_t png_create_sprite_rect(texture_t* tex, int x, int y, int w, int h);

/* Rendering ----------------------------------------------------------- */
void png_begin_sprites(void);
void png_end_sprites(void);

/* Basic draw from rect */
void png_draw_sprite(texture_t* tex,
                     const sprite_rect_t* sprite,
                     float x, float y, float w, float h);

/* Draw with transform (rotation/flip) */
void png_draw_sprite_xform(texture_t* tex,
                           const sprite_rect_t* sprite,
                           float x, float y, float w, float h,
                           png_xform_t xform);

/* Draw using explicit UVs (u1,v1 ... u4,v4) for advanced effects */
void png_draw_sprite_uv4(texture_t* tex,
                         const sprite_rect_t* sprite,
                         float x, float y, float w, float h,
                         float u1, float v1, float u2, float v2,
                         float u3, float v3, float u4, float v4);

/* Public vertex format (float positions as in the original code) */
typedef struct {
    float x, y, z;
    float u, v;
} TextureVertex;

#ifdef __cplusplus
}
#endif

#endif /* PNG_H_INCLUDED */
