// level.c - Парсер уровней + отрисовка с атласом PNG (с PNG тестом)
#include "level.h"
#include "graphics.h"
#include "png.h"       // ваш модуль PNG
#include <string.h>
#include <stdio.h>
#include <stdlib.h>


/* __IS_RAMP__ */
#define TILE_IS_RAMP(id) ((id)>=TILE_RAMP_1 && (id)<=TILE_RAMP_4)
Level g_level;

// --- Текстуры/атлас ---
texture_t* g_tileset = NULL;   // лениво загружаемый атлас - УБРАЛИ static
int g_tiles_per_row = 0;       // УБРАЛИ static

// Цвета-фолбэк для тайлов (если атлас не загружен)
static u32 tile_colors[] = {
    0xFFE3D3A2,  // 0: пусто - ИЗМЕНЕНО на #A2D3E3 (в формате ABGR для PSP)
    0xFF808080,  // 1: стена
    0xFFAA4422,  // 2: кирпич
    0xFF228844,  // 3
    0xFF228844,  // 4
    0xFF228844,  // 5
    0xFF228844,  // 6
    0xFFFF4444,  // 7: резина
    0xFF4444FF,  // 8: лед
    0xFFFFFF00,  // 9: выход
    0xFFFF00FF,  // 10: шип
    0xFF00FF00,  // 11
    0xFF00FFFF,  // 12
    // 13.. добавочные — кольца/спец
    0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,
    0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,0xFFFFD700,
    0xFFFF8800,  // 29 лава
    0xFF88AAFF,0xFF88AAFF,0xFF88AAFF,0xFF88AAFF,
    0xFF88FF88,0xFF88FF88,0xFF88FF88,0xFF88FF88,
    0xFFAA88FF,
    0xFF88AAFF,0xFF88AAFF,0xFF88AAFF,0xFF88AAFF,0xFF88AAFF,0xFF88AAFF,0xFF88AAFF,0xFF88AAFF,
    0xFFFF88AA,0xFFFF88AA,0xFFFF88AA,0xFFFF88AA,0xFFFF88AA,0xFFFF88AA,0xFFFF88AA,0xFFFF88AA
};
#define MAX_TILE_COLORS (sizeof(tile_colors)/sizeof(tile_colors[0]))

// --- Тест PNG ---
static texture_t* g_test_texture = NULL;

void level_test_png_rendering(void) {
    // Попробуем загрузить тестовую текстуру
    if (!g_test_texture) {
        g_test_texture = png_load_texture("test.png"); // путь не важен, создастся тестовая
        if (!g_test_texture) {
            // Если и тестовая не создалась - рендерим фолбэк
            graphics_draw_rect(50, 50, 64, 64, 0xFFFF0000); // Красный квадрат
            graphics_draw_text(50, 120, "PNG FAILED", 0xFFFFFFFF);
            return;
        }
    }
    
    // Рендерим тестовую текстуру
    sprite_rect_t full_sprite = png_create_sprite_rect(g_test_texture, 0, 0, 64, 64);
    png_draw_sprite(g_test_texture, &full_sprite, 50, 50, 64, 64);
    
    // Рендерим частичный спрайт
    sprite_rect_t quarter = png_create_sprite_rect(g_test_texture, 0, 0, 32, 32);
    png_draw_sprite(g_test_texture, &quarter, 150, 50, 64, 64);
    
    graphics_draw_text(50, 120, "PNG TEST OK", 0xFF00FF00);
}

// --- Вспомогательное: единожды загрузить атлас ---
static void level_load_tileset_once(void) {
    if (g_tileset) return;
    // Включаем обратно PNG загрузку для тестирования минимальной версии
    g_tileset = png_load_texture("icons/objects_nm.png");
    if (g_tileset) {
        if (g_tileset && g_tileset->width > 0) {
            g_tiles_per_row = g_tileset->width / TILE_SIZE; // 12 px на тайл
        } else {
            g_tiles_per_row = 0;
        }
    }
}

// --- Загрузка уровня из файла ---
int level_load_from_file(const char* filename) {
    FILE* file = fopen(filename, "rb");
    if (!file) {
        // Фолбэк: попробуем добавить/убрать ведущий слеш
        if (filename && filename[0] == '/') {
            file = fopen(filename + 1, "rb");
        } else {
            char alt[512];
            snprintf(alt, sizeof(alt), "/%s", filename);
            file = fopen(alt, "rb");
        }
        if (!file) return 0;
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    fseek(file, 0, SEEK_SET);
    if (fileSize < 8) { fclose(file); return 0; }

    unsigned char* buffer = (unsigned char*)malloc((size_t)fileSize);
    if (!buffer) { fclose(file); return 0; }

    size_t bytesRead = fread(buffer, 1, (size_t)fileSize, file);
    fclose(file);
    if (bytesRead != (size_t)fileSize) { free(buffer); return 0; }

    int result = level_load_from_memory((const char*)buffer, (int)fileSize);
    free(buffer);
    return result;
}

// --- Загрузка уровня по номеру ---
int level_load_by_number(int levelNumber) {
    level_load_tileset_once(); // попытка загрузить атлас один раз
    char filename[256];
    snprintf(filename, sizeof(filename), "/levels/J2MElvl.%03d", levelNumber);
    return level_load_from_file(filename);
}

// --- Парсер из памяти (как в TileCanvas: 8 байт заголовка + карта + опциональный хвост) ---
int level_load_from_memory(const char* levelData, int dataSize) {
    if (!levelData || dataSize < 8) return 0;
    memset(&g_level, 0, sizeof(Level));

    const unsigned char* data = (const unsigned char*)levelData;
    int offset = 0;

    int startX_tiles   = data[offset++];
    int startY_tiles   = data[offset++];
    g_level.ballSize   = data[offset++];
    g_level.exitPosX   = data[offset++];
    g_level.exitPosY   = data[offset++];
    g_level.totalRings = data[offset++];
    g_level.width      = data[offset++];
    g_level.height     = data[offset++];

    if (g_level.width <= 0 || g_level.height <= 0 ||
        g_level.width  > MAX_LEVEL_WIDTH || g_level.height > MAX_LEVEL_HEIGHT) {
        return 0;
    }

    int mapBytes = g_level.width * g_level.height;
    if (offset + mapBytes > dataSize) return 0;

    g_level.startPosX = startX_tiles * TILE_SIZE;
    g_level.startPosY = startY_tiles * TILE_SIZE;

    for (int y = 0; y < g_level.height; ++y) {
        for (int x = 0; x < g_level.width; ++x) {
            g_level.tileMap[y][x] = data[offset++];
        }
    }

    // Опционально: хвост движущихся объектов (numMoveObj * 8) — игнорируем, если есть
    if (dataSize - offset >= 1) {
        int numMoveObj = data[offset++];
        int tail = numMoveObj * 8;
        if (dataSize - offset >= tail) {
            // пропускаем
            // offset += tail; // не обязателен, не используем хвост
        } else {
            // некорректный хвост — не критично для статической карты
        }
    }

    return 1;
}

// --- Тестовый уровень (оставлен без изменений) ---
int level_create_test_level(void) {
    static const unsigned char testLevelData[] = {
        2,18,0,35,18,3,40,23,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
    };
    return level_load_from_memory((const char*)testLevelData, sizeof(testLevelData));
}

// --- Доступ к тайлам ---
int level_get_tile_at(int tileX, int tileY) {
    if (tileX < 0 || tileX >= g_level.width || tileY < 0 || tileY >= g_level.height) {
        return TILE_WALL; // вне карты считаем стеной
    }
    return g_level.tileMap[tileY][tileX];
}

// --- Твердость тайлов ---
int level_is_tile_solid(int tile) {
    switch (tile) {
        case TILE_WALL:
        case TILE_BRICK:
        case TILE_RAMP_1:
        case TILE_RAMP_2:
        case TILE_RAMP_3:
        case TILE_RAMP_4:
        case TILE_RUBBER:
        case TILE_ICE:
            return 1;
        default:
            return 0;
    }
}

// --- Проверка коллизии по пикселям ---
int level_check_collision_at_pixel(int pixelX, int pixelY, int width, int height) {
    int leftTile   = pixelX / TILE_SIZE;
    int rightTile  = (pixelX + width  - 1) / TILE_SIZE;
    int topTile    = pixelY / TILE_SIZE;
    int bottomTile = (pixelY + height - 1) / TILE_SIZE;

    if (leftTile   < 0) leftTile = 0;
    if (topTile    < 0) topTile = 0;
    if (rightTile  >= g_level.width)  rightTile  = g_level.width  - 1;
    if (bottomTile >= g_level.height) bottomTile = g_level.height - 1;

    for (int y = topTile; y <= bottomTile; ++y) {
        for (int x = leftTile; x <= rightTile; ++x) {
            int t = level_get_tile_at(x, y);
            if (level_is_tile_solid(t)) return 0;
        }
    }
    return 1;
}

// ИСПРАВЛЕНО: маппинг тайлов согласно оригинальному Java коду
static void get_tile_atlas_coords(int tile, int* srcX, int* srcY) {
    // Маппинг согласно loadTileImages() из Java кода
    switch(tile) {
        case 1:  // стена - tileImages[0] = extractImage(image, 1, 0)
            *srcX = 1 * TILE_SIZE; *srcY = 0 * TILE_SIZE; break;
        case 2:  // кирпич - tileImages[1] = extractImage(image, 1, 2) 
            *srcX = 1 * TILE_SIZE; *srcY = 2 * TILE_SIZE; break;
        case 3:  // рампа - основан на tileImages[2] = extractImageBG(image, 0, 3, ...)
            *srcX = 0 * TILE_SIZE; *srcY = 3 * TILE_SIZE; break;
        case 4:  // рампа
            *srcX = 0 * TILE_SIZE; *srcY = 3 * TILE_SIZE; break;
        case 5:  // рампа  
            *srcX = 0 * TILE_SIZE; *srcY = 3 * TILE_SIZE; break;
        case 6:  // рампа
            *srcX = 0 * TILE_SIZE; *srcY = 3 * TILE_SIZE; break;
        case 7:  // резина - tileImages[10] = extractImage(image, 0, 4)
            *srcX = 0 * TILE_SIZE; *srcY = 4 * TILE_SIZE; break;
        case 8:  // лед - tileImages[11] = extractImage(image, 3, 4)
            *srcX = 3 * TILE_SIZE; *srcY = 4 * TILE_SIZE; break;
        case 9:  // выход - специальная обработка, пока используем tileImages[12]
            *srcX = 2 * TILE_SIZE; *srcY = 3 * TILE_SIZE; break;
        case 10: // шипы - tileImages[46] = extractImage(image, 1, 3)
            *srcX = 1 * TILE_SIZE; *srcY = 3 * TILE_SIZE; break;
        case 29: // лава - tileImages[45] = extractImage(image, 3, 3)
            *srcX = 3 * TILE_SIZE; *srcY = 3 * TILE_SIZE; break;
        default:
            // Если тайл неизвестен, используем первый тайл
            *srcX = 0; *srcY = 0; break;
    }
}

// --- Рендер видимой области ---
void level_render_visible_area(int cameraX, int cameraY, int screenWidth, int screenHeight) {
    if (g_level.width <= 0 || g_level.height <= 0) return;

    int startTileX = cameraX / TILE_SIZE;
    int endTileX   = (cameraX + screenWidth  - 1) / TILE_SIZE;
    int startTileY = cameraY / TILE_SIZE;
    int endTileY   = (cameraY + screenHeight - 1) / TILE_SIZE;

    if (startTileX < 0) startTileX = 0;
    if (startTileY < 0) startTileY = 0;
    if (endTileX >= g_level.width)   endTileX = g_level.width - 1;
    if (endTileY >= g_level.height)  endTileY = g_level.height - 1;
    png_begin_sprites();


    for (int y = startTileY; y <= endTileY; ++y) {
        for (int x = startTileX; x <= endTileX; ++x) {
            int tile = g_level.tileMap[y][x];
            
            int tile_flags = (tile & 0xC0);
            int tile_id = (tile & 0x3F);
if (tile_id == TILE_EMPTY) continue;

            int screenX = x * TILE_SIZE - cameraX;
            int screenY = y * TILE_SIZE - cameraY;

            if (g_tileset && g_tiles_per_row > 0 && tile >= 0) {
                // ИСПРАВЛЕНО: используем правильный маппинг тайлов
                int srcX, srcY;
                get_tile_atlas_coords(tile_id, &srcX, &srcY);
/* Ramp handling: background fill and variant-based source row */
if (TILE_IS_RAMP(tile_id)) {
    u32 bg = (tile_flags & TILE_FLAG_VARIANT) ? TILE_DARK_BG : TILE_LIGHT_BG;
    graphics_draw_rect((float)screenX, (float)screenY, (float)TILE_SIZE, (float)TILE_SIZE, bg);/* Disabled coordinate override to keep atlas coords from get_tile_atlas_coords() */ if(0){
    /* If variant set, use alternate atlas row (0,3) for ramps */
    if (tile_flags & TILE_FLAG_VARIANT) {
        srcX = 0;
        srcY = 3 * TILE_SIZE;
    } else {
        srcX = 0;
        srcY = 0;
    }
}}
/* Ramp handling: background fill and variant atlas row */
if (TILE_IS_RAMP(tile_id)) {
    u32 bg = (tile_flags & TILE_FLAG_VARIANT) ? TILE_DARK_BG : TILE_LIGHT_BG;
    graphics_draw_rect((float)screenX, (float)screenY, (float)TILE_SIZE, (float)TILE_SIZE, bg);/* Disabled coordinate override to keep atlas coords from get_tile_atlas_coords() */ if(0){
    /* choose atlas row: 0,0 for normal; 0,3 for variant */
    if (tile_flags & TILE_FLAG_VARIANT) { srcX = 0; srcY = 3 * TILE_SIZE; }
    else { srcX = 0; srcY = 0; }
}}


                
                // Проверяем, что координаты не выходят за границы текстуры
                if (srcX + TILE_SIZE <= g_tileset->width && srcY + TILE_SIZE <= g_tileset->height) {
                    
sprite_rect_t r = png_create_sprite_rect(g_tileset, srcX, srcY, TILE_SIZE, TILE_SIZE);
if (TILE_IS_RAMP(tile_id)) {
    png_xform_t xf = PNG_XFORM_IDENTITY;
    switch (tile_id) {
        case TILE_RAMP_1: xf = PNG_XFORM_IDENTITY; break;
        case TILE_RAMP_2: xf = PNG_XFORM_ROT_270;  break;
        case TILE_RAMP_3: xf = PNG_XFORM_FLIP_X;   break;
        case TILE_RAMP_4: xf = PNG_XFORM_ROT_90;   break;
    }
    png_draw_sprite_xform(g_tileset, &r, (float)screenX, (float)screenY, (float)TILE_SIZE, (float)TILE_SIZE, xf);
} else {
    png_draw_sprite(g_tileset, &r, (float)screenX, (float)screenY, (float)TILE_SIZE, (float)TILE_SIZE);
}

                } else {
                    // Фолбэк на цветной квадрат если координаты некорректные
                    if ((unsigned)tile < (unsigned)MAX_TILE_COLORS) {
                        graphics_draw_rect((float)screenX, (float)screenY, (float)TILE_SIZE, (float)TILE_SIZE, tile_colors[tile_id]);
                    } else {
                        graphics_draw_rect((float)screenX, (float)screenY, (float)TILE_SIZE, (float)TILE_SIZE, 0xFFFF0000);
                    }
                }
            } else {
                // Фолбэк на цветные квадраты
                if ((unsigned)tile < (unsigned)MAX_TILE_COLORS) {
                    graphics_draw_rect((float)screenX, (float)screenY, (float)TILE_SIZE, (float)TILE_SIZE, tile_colors[tile_id]);
                } else {
                    graphics_draw_rect((float)screenX, (float)screenY, (float)TILE_SIZE, (float)TILE_SIZE, 0xFFFF0000);
                }
            }
        }
    }
    // Больше не трогаем глобальные состояния GU здесь.

    png_end_sprites();
}
