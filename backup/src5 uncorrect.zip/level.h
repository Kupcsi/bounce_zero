// level.h - Парсер оригинальных уровней Bounce
#ifndef LEVEL_H
#define LEVEL_H

#include <psptypes.h>

// Константы тайлов (из оригинального TileCanvas.java)
#define TILE_EMPTY 0          // Пустое место (фон)
#define TILE_WALL 1           // Обычная стена
#define TILE_BRICK 2          // Кирпичная стена
#define TILE_RAMP_1 3         // Наклонная поверхность (вариант 1)
#define TILE_RAMP_2 4         // Наклонная поверхность (вариант 2)
#define TILE_RAMP_3 5         // Наклонная поверхность (вариант 3)
#define TILE_RAMP_4 6         // Наклонная поверхность (вариант 4)

/* --- Tile flags --- */
#ifndef TILE_FLAG_VARIANT
#define TILE_FLAG_VARIANT 0x40  /* альтернативный фон/вариант */
#endif
#ifndef TILE_FLAG_DIRTY
#define TILE_FLAG_DIRTY   0x80  /* «грязный» тайл (на будущее) */
#endif

/* --- Background colors for ramp tiles (temporary placeholders).
   TODO: заменить на точные значения из Java (11591920 и 1073328) --- */
#ifndef TILE_LIGHT_BG
#define TILE_LIGHT_BG 0xFFB0B0B0
#endif
#ifndef TILE_DARK_BG
#define TILE_DARK_BG  0xFF203020
#endif

#define TILE_RUBBER 7         // Резиновая поверхность (отскок)
#define TILE_ICE 8            // Лед (скользкая поверхность)
#define TILE_EXIT 9           // Выход из уровня
#define TILE_SPIKE 10         // Движущиеся шипы

// Кольца для сбора (13-28 в оригинале)
#define TILE_RING_1A 13       
#define TILE_RING_1B 14       
#define TILE_RING_2A 15       
#define TILE_RING_2B 16       
#define TILE_RING_3A 17       
#define TILE_RING_3B 18       
#define TILE_RING_4A 19       
#define TILE_RING_4B 20       
#define TILE_RING_5A 21       
#define TILE_RING_5B 22       
#define TILE_RING_6A 23       
#define TILE_RING_6B 24       
#define TILE_RING_7A 25       
#define TILE_RING_7B 26       
#define TILE_RING_8A 27       
#define TILE_RING_8B 28       

// Размеры
#define TILE_SIZE 12
#define MAX_LEVEL_WIDTH 255
#define MAX_LEVEL_HEIGHT 255

// Структура уровня
typedef struct {
    int width;              // Ширина карты в тайлах
    int height;             // Высота карты в тайлах
    int startPosX;          // Стартовая позиция игрока X (в пикселях)
    int startPosY;          // Стартовая позиция игрока Y (в пикселях)
    int ballSize;           // Размер мяча (0=маленький, 1=большой)
    int exitPosX;           // Позиция выхода X (в тайлах)
    int exitPosY;           // Позиция выхода Y (в тайлах)
    int totalRings;         // Общее количество колец для сбора
    
    // Карта тайлов
    short tileMap[MAX_LEVEL_HEIGHT][MAX_LEVEL_WIDTH];
} Level;

// Глобальный уровень
extern Level g_level;

// Функции
int level_load_from_memory(const char* levelData, int dataSize);
int level_load_from_file(const char* filename);
int level_load_by_number(int levelNumber);
int level_create_test_level(void);
int level_get_tile_at(int tileX, int tileY);
int level_is_tile_solid(int tile);
int level_check_collision_at_pixel(int pixelX, int pixelY, int width, int height);
void level_render_visible_area(int cameraX, int cameraY, int screenWidth, int screenHeight);

// PNG тест
void level_test_png_rendering(void);

#endif
