#include <pspkernel.h>
#include <pspdebug.h>
#include <pspctrl.h>
#include <pspdisplay.h>
#include <psppower.h>
#include <stdlib.h>
#include "graphics.h"
#include "input.h"
#include "game.h"
#include "types.h"

PSP_MODULE_INFO("2D Platformer", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER);

int exit_callback(int arg1, int arg2, void *common) {
    sceKernelExitGame();
    return 0;
}

int callback_thread(SceSize args, void *argp) {
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();
    return 0;
}

int setup_callbacks(void) {
    int thid = sceKernelCreateThread("update_thread", callback_thread, 0x11, 0xFA0, 0, 0);
    if(thid >= 0)
        sceKernelStartThread(thid, 0, 0);
    return thid;
}

int main(void) {
    setup_callbacks();
    
    // Инициализация
    graphics_init();
    input_init();
    game_init();
    
    // Счётчик для замедления физики до оригинальной частоты
    static int tick_counter = 0;
    // Буфер для сохранения нажатий между тиками физики
    static int buffered_jump = 0;
    
    // Главный цикл
    while(g_game.state != STATE_EXIT) {
        input_update();
        
        // === ОБНОВЛЕНИЕ МЕНЮ И ИНТЕРФЕЙСА (каждый кадр) ===
        if(g_game.state == STATE_MENU || g_game.state == STATE_ABOUT || g_game.state == STATE_LEVEL_SELECT) {
            game_update();  // Меню и About обновляются на полной частоте
        }
        
        // === ОБНОВЛЕНИЕ ИГРОВОЙ ФИЗИКИ (замедленно) ===
        else if(g_game.state == STATE_GAME) {
            // Сохраняем нажатие прыжка, если оно было
            if(input_pressed(PSP_CTRL_CROSS)) {
                buffered_jump = 1;
            }
            
            // Обновляем физику только каждый 2-й кадр (60 FPS -> 30 FPS)
            tick_counter++;
            if(tick_counter >= 2) {
                // Передаём сохранённое нажатие в игровую логику
                g_game.buffered_jump = buffered_jump;
                game_update();
                
                // Сбрасываем буфер после обработки
                buffered_jump = 0;
                tick_counter = 0;
            }
        }
        
        // Рендеринг всегда на полной частоте для плавности
        graphics_start_frame();
        game_render();
        graphics_end_frame();
    }
    
    // Очистка
    graphics_shutdown();
    sceKernelExitGame();
    return 0;
}