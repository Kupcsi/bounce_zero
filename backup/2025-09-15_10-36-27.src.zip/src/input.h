#ifndef INPUT_H
#define INPUT_H

#include <pspctrl.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Инициализация подсистемы ввода
 * Настраивает контроллер и обнуляет состояния
 */
void input_init(void);

/**
 * Обновить состояние контроллера
 * Должна вызываться каждый кадр для корректной работы input_pressed()
 */
void input_update(void);

/**
 * Проверить нажатие кнопки (одноразовое срабатывание)
 * @param button Битовая маска кнопки (см. PSP_CTRL_* константы в <pspctrl.h>)
 * @return 1 если кнопка только что была нажата, иначе 0
 */
int input_pressed(unsigned int button);

/**
 * Проверить удержание кнопки (непрерывное срабатывание)
 * @param button Битовая маска кнопки (см. PSP_CTRL_* константы в <pspctrl.h>)
 * @return 1 если кнопка в данный момент удерживается, иначе 0
 */
int input_held(unsigned int button);

/**
 * Проверить отпускание кнопки (одноразовое срабатывание при отпускании)
 * @param button Битовая маска кнопки (см. PSP_CTRL_* константы в <pspctrl.h>)
 * @return 1 если кнопка только что была отпущена, иначе 0
 */
int input_released(unsigned int button);

#ifdef __cplusplus
}
#endif

#endif