#ifndef TILE_TABLE_H
#define TILE_TABLE_H

#include <psptypes.h>

// Размер тайла в пикселях
#define TILE_SIZE 12

// Фиксированная точка Q15 для нормалей поверхностей
typedef s16 q15_t;

// Категории тайлов (соответствуют константам BounceConst.java)
typedef enum {
    EMPTY_SPACE = 0,           // ID_EMPTY_SPACE
    BRICK_RED,                 // ID_BRICK_RED
    BRICK_BLUE,                // ID_BRICK_BLUE (резиновый)
    SPIKE_FLOOR,               // ID_SPIKE_FLOOR
    SPIKE_LEFT_WALL,           // ID_SPIKE_LEFT_WALL
    SPIKE_CEILING,             // ID_SPIKE_CEILING
    SPIKE_RIGHT_WALL,          // ID_SPIKE_RIGHT_WALL
    RESPAWN_GEM,               // ID_RESPAWN_GEM (чекпоинт)
    RESPAWN_INDICATOR,         // ID_RESPAWN_INDICATOR (активированный чекпоинт)
    EXIT_TILE,                 // ID_EXIT_TILE
    MOVING_SPIKE_TILE,         // ID_MOVING_SPIKE_TILE
    HOOP_ACTIVE,               // ID_HOOP_ACTIVE_* (13-16) - активные кольца
    HOOP_INACTIVE,             // ID_HOOP_INACTIVE_* (17-20) - неактивные кольца  
    LARGE_HOOP_ACTIVE,         // ID_LARGE_HOOP_ACTIVE_* (21-24) - большие активные
    LARGE_HOOP_INACTIVE,       // ID_LARGE_HOOP_INACTIVE_* (25-28) - большие неактивные
    TRIANGLE_FLOOR,            // ID_TRIANGLE_* (рампы)
    EXTRA_LIFE,                // ID_EXTRA_LIFE
    SPEED_BONUS,               // ID_SPEED
    DEFLATOR_TILE,             // ID_DEFLATOR_* (уменьшение)  
    INFLATOR_TILE,             // ID_INFLATOR_* (увеличение)
    GRAVITY_BONUS,             // ID_GRAVITY_* (бонус гравитации)
    JUMP_BONUS,                // ID_JUMP_* (бонус прыжка)
    GENERIC_TILE               // Для остальных/неопределенных
} TileCategory;

// Ориентация тайла
typedef enum {
    ORIENT_NONE = 0,           // Без ориентации
    ORIENT_TL,                 // Top-Left (верхний левый угол)
    ORIENT_TR,                 // Top-Right (верхний правый угол)
    ORIENT_BL,                 // Bottom-Left (нижний левый угол)
    ORIENT_BR,                 // Bottom-Right (нижний правый угол)
    // Ориентации для колец (на основе Java BounceConst)
    ORIENT_VERT_TOP,           // Вертикальное кольцо - верхняя часть
    ORIENT_VERT_BOTTOM,        // Вертикальное кольцо - нижняя часть  
    ORIENT_HORIZ_LEFT,         // Горизонтальное кольцо - левая часть
    ORIENT_HORIZ_RIGHT,        // Горизонтальное кольцо - правая часть
    // Ориентации для шипов с тонкими коллизиями
    ORIENT_SPIKE_THIN_HORIZ,   // Тонкая коллизия горизонтально (для шипов вверх/вниз)
    ORIENT_SPIKE_THIN_VERT     // Тонкая коллизия вертикально (для шипов лево/право)
} TileOrientation;

// Тип коллизии
typedef enum {
    COLLISION_NONE = 0,        // Нет коллизии (проходимый)
    COLLISION_SOLID,           // Полная коллизия (непроходимый блок)
    COLLISION_ORIENTED         // Ориентированная коллизия (используется orientation)
} CollisionType;

// Трансформации спрайтов (на основе Java manipulateImage)
typedef enum {
    TF_NONE = 0,               // Без трансформации
    TF_FLIP_X = 1,             // Отражение по X (manipulateImage case 0)
    TF_FLIP_Y = 2,             // Отражение по Y (manipulateImage case 1) 
    TF_FLIP_XY = 3,            // Отражение по X и Y (manipulateImage case 2)
    TF_ROT_90 = 4,             // Поворот на 90° (manipulateImage case 3)
    TF_ROT_180 = 5,            // Поворот на 180° (manipulateImage case 4)
    TF_ROT_270 = 6,            // Поворот на 270° (manipulateImage case 5)
    // Составные трансформации для Java-совместимости
    TF_ROT_270_FLIP_X = 7,     // ROT_270 + FLIP_X (для Java tileImages[35])
    TF_ROT_270_FLIP_Y = 8,     // ROT_270 + FLIP_Y (для Java tileImages[34])
    TF_ROT_270_FLIP_XY = 9     // ROT_270 + FLIP_X + FLIP_Y
} TileTransform;

// Логика поведения тайла
typedef enum {
    LOGIC_NONE = 0,            // Нет специальной логики
    LOGIC_HAZARD,              // Опасность (шипы)
    LOGIC_RING,                // Кольцо для сбора
    LOGIC_EXIT,                // Выход из уровня
    LOGIC_SHRINK,              // Уменьшение мяча
    LOGIC_GROW,                // Увеличение мяча
    LOGIC_RUBBER,              // Резиновая поверхность
    LOGIC_SPEED_BONUS,         // Бонус скорости
    LOGIC_GRAVITY_BONUS,       // Бонус гравитации
    LOGIC_JUMP_BONUS           // Бонус прыжка
} TileLogic;

// Специальные флаги для составных тайлов
typedef enum {
    SPECIAL_NONE = 0,          // Обычный тайл
    SPECIAL_COMPOSITE = 1,     // Составной тайл (EXIT, движущиеся шипы)
    // SPECIAL_DUAL_SPRITE = 2 - REMOVED (was deprecated, not used)
    SPECIAL_WATER_VARIANT = 4, // Тайл имеет водный вариант (мокрые шипы, рампы)
    SPECIAL_HOOP = 8           // Кольцо-обруч (как в Java: add2HoopList)
} TileSpecialFlags;

// Константы ID тайлов (соответствуют оригинальному Java коду)
#define TILE_EMPTY           0
#define TILE_BRICK_RED       1
#define TILE_BRICK_BLUE      2
#define TILE_SPIKE_UP        3
#define TILE_SPIKE_LEFT      4
#define TILE_SPIKE_DOWN      5
#define TILE_SPIKE_RIGHT     6
#define TILE_CHECKPOINT      7
#define TILE_CHECKPOINT_ON   8
#define TILE_EXIT            9
#define TILE_MOVING_SPIKES   10
#define TILE_EXTRA_LIFE      29
#define TILE_SPEED_BONUS     38

// Флаги тайлов (соответствуют BounceConst.java)
#define TILE_DIRTY_BIT    0x80   // TILE_DIRTY = 128
#define TILE_CLEAN_MASK   0x7F   // Маска для очистки dirty флага

// Основная структура метаданных тайла
typedef struct {
    TileCategory category;         // 1. Категория тайла (для читаемости кода - документирует тип тайла)
    TileOrientation orientation;   // 2. Ориентация (✅ используется в physics)
    CollisionType collision_type;  // 3. НЕ ИСПОЛЬЗУЕТСЯ (заменен на прямую логику по tileID)
    q15_t normal_x, normal_y;      // 4-5. Нормаль поверхности Q15 (НЕ ИСПОЛЬЗУЮТСЯ)
    uint16_t base_sprite_index;    // 6. Базовый спрайт в атласе 0-23 (✅ используется в graphics)
    TileTransform transform;       // 7. Трансформация базового спрайта (✅ используется в graphics)
    TileLogic logic;               // 8. Логика поведения (НЕ ИСПОЛЬЗУЕТСЯ)
    uint8_t special_flags;         // 9. Специальные флаги (✅ используется в graphics)
    uint8_t alt_sprite_index;      // 10. Альтернативный спрайт для флага 0x40 (✅ используется в graphics)
    TileTransform alt_transform;   // 11. Трансформация альтернативного спрайта (✅ используется в graphics)
    
    // Для 4-частных колец (SPECIAL_HOOP)
    uint8_t ring_bg_sprite;        // 12. Индекс атласа для фоновой части (✅ используется в graphics, трансформация захардкожена в level.c)
    uint8_t ring_fg_sprite;        // 13. Индекс атласа для передней части (✅ используется в graphics, трансформация захардкожена в level.c)
} TileMeta;

// Функции доступа к таблице тайлов
const TileMeta* tile_meta_db(void);
uint32_t tile_meta_count(void);

// Вспомогательные функции для работы с трансформациями
const char* tile_transform_name(TileTransform transform);
int tile_needs_alt_sprite(const TileMeta* tile, int tile_flags);

#endif // TILE_TABLE_H