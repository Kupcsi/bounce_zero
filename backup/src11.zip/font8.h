#ifndef FONT8_FONT_H
#define FONT8_FONT_H

#include <psptypes.h>

#ifdef __cplusplus
extern "C" {
#endif

#define FONT8_W 8
#define FONT8_H 8
#define FONT8_FIRST 32   // Первый печатный ASCII символ (пробел)
#define FONT8_LAST  126  // Последний печатный ASCII символ (~)
#define FONT8_COUNT (FONT8_LAST - FONT8_FIRST + 1)

typedef struct {
    u8 row[FONT8_H];  // 8 строк пиксельных данных
    u8 width;         // Ширина символа в пикселях
} Glyph8;

/**
 * Получить указатель на таблицу шрифта
 * @return Указатель на массив всех глифов
 */
const Glyph8* font8_table(void);

/**
 * Получить глиф для символа
 * @param c Код символа (ASCII 32-126)
 * @return Указатель на глиф. Для символов вне диапазона возвращает пробел
 */
const Glyph8* font8_get_glyph(char c);

#ifdef __cplusplus
}
#endif

#endif