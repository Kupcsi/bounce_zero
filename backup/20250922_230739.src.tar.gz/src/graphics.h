#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <psptypes.h>
#include "png.h"  // Для texture_t в batch функциях

// PSP VRAM буферы должны иметь ширину кратную степени двойки для оптимизации
// Экран 480px округляется до 512px - стандартное требование PSP SDK
#define VRAM_BUFFER_WIDTH  512
#define VRAM_BUFFER_HEIGHT 272

#ifdef __cplusplus
extern "C" {
#endif

/**
 * ПРОТОКОЛ ИСПОЛЬЗОВАНИЯ ГРАФИЧЕСКОЙ СИСТЕМЫ:
 *
 * 1. Всегда вызывайте graphics_begin_plain() перед рисованием фигур
 * 2. Всегда вызывайте graphics_begin_textured() перед рисованием спрайтов
 * 3. НЕ вызывайте напрямую sceGuEnable/Disable(GU_TEXTURE_2D)
 * 4. graphics_end_frame() автоматически делает flush всех батчей
 *
 * Переключение режимов автоматически сбрасывает накопленные батчи.
 */

/**
 * Инициализация графической подсистемы
 */
void graphics_init(void);

/**
 * Завершение работы графической подсистемы
 */
void graphics_shutdown(void);

/**
 * Начать новый кадр
 */
void graphics_start_frame(void);

/**
 * Завершить текущий кадр и отобразить на экране
 */
void graphics_end_frame(void);

/**
 * Очистить экран указанным цветом.
 *
 * @param color Цвет в формате ABGR (нативный для PSP GU_PSM_8888).
 *
 *        Формат: 0xAABBGGRR где:
 *        - AA = Alpha (прозрачность, FF = непрозрачный)
 *        - BB = Blue  (синий компонент)
 *        - GG = Green (зеленый компонент)
 *        - RR = Red   (красный компонент)
 *
 *        Примеры основных цветов:
 *        - Красный:   0xFF0000FF (A=FF, B=00, G=00, R=FF)
 *        - Зеленый:   0xFF00FF00 (A=FF, B=00, G=FF, R=00)
 *        - Синий:     0xFFFF0000 (A=FF, B=FF, G=00, R=00)
 *        - Белый:     0xFFFFFFFF (A=FF, B=FF, G=FF, R=FF)
 *        - Черный:    0xFF000000 (A=FF, B=00, G=00, R=00)
 */
void graphics_clear(u32 color);

/**
 * Нарисовать прямоугольник
 * @param x X координата левого верхнего угла
 * @param y Y координата левого верхнего угла
 * @param w Ширина прямоугольника
 * @param h Высота прямоугольника
 * @param color Цвет в формате ABGR (тот же что и в graphics_clear())
 */
void graphics_draw_rect(float x, float y, float w, float h, u32 color);

/**
 * Нарисовать текст стандартного размера
 * @param x X координата левого верхнего угла текста
 * @param y Y координата левого верхнего угла текста
 * @param text Строка для отображения
 * @param color Цвет текста в формате ABGR (тот же что и в graphics_clear())
 */
void graphics_draw_text(float x, float y, const char* text, u32 color);

/**
 * Нарисовать текст с масштабированием
 * @param x X координата левого верхнего угла текста
 * @param y Y координата левого верхнего угла текста
 * @param text Строка для отображения
 * @param color Цвет текста в формате ABGR (тот же что и в graphics_clear())
 * @param scale Коэффициент масштабирования (1 или 2)
 */
void graphics_draw_text_scaled(float x, float y, const char* text, u32 color, int scale);

/**
 * Измерить ширину текста с учетом масштабирования
 * @param text Строка для измерения
 * @param scale Коэффициент масштабирования (1 или 2)
 * @return Ширина текста в пикселях
 */
float graphics_measure_text(const char* text, int scale);


/**
 * Декодировать UTF-8 символ прямо в индекс таблицы font9
 * @param str UTF-8 строка
 * @param bytes_read Количество прочитанных байт
 * @return Индекс в таблице font9 (0-193) или 32 (пробел) для неизвестных
 */
int utf8_decode_to_index(const char* str, int* bytes_read);

/**
 * Единое управление состоянием текстур
 * ВАЖНО: Вне graphics.* запрещены прямые вызовы sceGuEnable/Disable(GU_TEXTURE_2D)!
 */
void graphics_set_texturing(int enabled);  // 0=off, 1=on
void graphics_begin_plain(void);           // гарантирует выключенные текстуры (HUD фон/текст)
void graphics_begin_textured(void);        // гарантирует включенные текстуры + сброс цвета (ОБЯЗАТЕЛЬНО перед PNG!)
int graphics_get_texturing_state(void);    // получить текущее состояние (0=plain, 1=textured)

/**
 * Sprite batching система для оптимизации рендера (по образцу pspsdk/samples/gu/sprite)
 * Объединяет множественные draw вызовы в пачки для минимизации texture bind'ов
 */
void graphics_bind_texture(texture_t* tex);         // Привязать текстуру для batch'а
void graphics_batch_sprite(float u1, float v1, float u2, float v2, 
                          float x, float y, float w, float h); // Добавить спрайт в batch
void graphics_flush_batch(void);                    // Принудительно отрисовать накопленные спрайты



#ifdef __cplusplus
}
#endif

#endif