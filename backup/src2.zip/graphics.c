#include "graphics.h"
#include "font8.h"
#include <pspgu.h>
#include <pspdisplay.h>
#include <pspkernel.h>
#include <string.h>

#define BUFFER_WIDTH 512
#define BUFFER_HEIGHT 272
#define SCREEN_WIDTH 480
#define SCREEN_HEIGHT BUFFER_HEIGHT

static char list[0x20000] __attribute__((aligned(64)));

// Вариант B: примитивы без текстурных координат; цвет задаём через sceGuColor(...)
typedef struct {
    short x, y, z;
} Vertex2D;

void graphics_init(void) {
    sceGuInit();

    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, (void*)0, BUFFER_WIDTH);
    sceGuDispBuffer(SCREEN_WIDTH, SCREEN_HEIGHT, (void*)0x88000, BUFFER_WIDTH);
    sceGuDepthBuffer((void*)0x110000, BUFFER_WIDTH);

    sceGuOffset(2048 - (SCREEN_WIDTH / 2), 2048 - (SCREEN_HEIGHT / 2));
    sceGuViewport(2048, 2048, SCREEN_WIDTH, SCREEN_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuScissor(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    sceGuDepthRange(65535, 0);
    sceGuDepthFunc(GU_GEQUAL);
    sceGuEnable(GU_DEPTH_TEST);

    // Вариант B: базовый блендинг — режимы управляются на уровне кадра (game_render)
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);

    sceGuFinish();
    sceGuDisplay(GU_TRUE);
}

void graphics_start_frame(void) {
    sceGuStart(GU_DIRECT, list);
}

void graphics_clear(u32 color) {
    sceGuClearColor(color);
    sceGuClear(GU_COLOR_BUFFER_BIT);
}

void graphics_draw_rect(float x, float y, float w, float h, u32 color) {
    // Не трогаем GU_TEXTURE_2D / GU_BLEND — вариант B
    Vertex2D* v = (Vertex2D*)sceGuGetMemory(2 * sizeof(Vertex2D));

    v[0].x = (short)x;
    v[0].y = (short)y;
    v[0].z = 0;

    v[1].x = (short)(x + w);
    v[1].y = (short)(y + h);
    v[1].z = 0;

    sceGuColor(color);
    sceGuDrawArray(GU_SPRITES, GU_VERTEX_16BIT | GU_TRANSFORM_2D, 2, 0, v);
}

void graphics_draw_char_scaled(float x, float y, char c, u32 color, float scale) {
    const Glyph8* glyph = font8_get_glyph(c);
    if (!glyph) return;

    for (int row = 0; row < 8; row++) {
        for (int col = 0; col < glyph->width; col++) {
            if (glyph->row[row] & (1 << (7 - col))) {
                graphics_draw_rect(x + col * scale, y + row * scale, scale, scale, color);
            }
        }
    }
}

void graphics_draw_char(float x, float y, char c, u32 color) {
    graphics_draw_char_scaled(x, y, c, color, 1.0f);
}

void graphics_draw_text_scaled(float x, float y, const char* text, u32 color, float scale) {
    if (!text) return;
    float cur_x = x;
    for (int i = 0; text[i] != '\0'; i++) {
        const Glyph8* glyph = font8_get_glyph(text[i]);
        if (glyph) {
            graphics_draw_char_scaled(cur_x, y, text[i], color, scale);
            cur_x += (glyph->width + 1) * scale;
        }
    }
}

void graphics_draw_text(float x, float y, const char* text, u32 color) {
    graphics_draw_text_scaled(x, y, text, color, 1.0f);
}

float graphics_measure_text(const char* text, float scale) {
    if (!text) return 0.0f;
    float width = 0.0f;
    for (int i = 0; text[i] != '\0'; i++) {
        const Glyph8* glyph = font8_get_glyph(text[i]);
        if (glyph) {
            width += (glyph->width + 1) * scale;
        }
    }
    if (width > 0) width -= scale; // убрать последний межсимвольный отступ
    return width;
}

void graphics_end_frame(void) {
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

void graphics_shutdown(void) {
    sceGuDisplay(GU_FALSE);
    sceGuTerm();
}
