#ifndef INPUT_H
#define INPUT_H

#include <pspctrl.h>

void input_init(void);
void input_update(void);
int input_pressed(int button);
int input_held(int button);

#endif