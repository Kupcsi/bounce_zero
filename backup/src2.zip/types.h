#ifndef TYPES_H
#define TYPES_H

#include <psptypes.h>

// Состояния игры
typedef enum {
    STATE_MENU,
    STATE_LEVEL_SELECT,  // ДОБАВЛЕНО для выбора уровня
    STATE_GAME,
    STATE_ABOUT,
    STATE_EXIT
} GameState;

// Константы размеров (из BounceConst.java)
#define NORMAL_SIZE 12
#define HALF_NORMAL_SIZE 6
#define ENLARGED_SIZE 16  
#define HALF_ENLARGED_SIZE 8
#define POPPED_SIZE 12
#define HALF_POPPED_SIZE 6

// Состояния размера
#define SMALL_SIZE_STATE 0    // использует NORMAL_SIZE
#define LARGE_SIZE_STATE 1    // использует ENLARGED_SIZE

// Состояния мяча
#define BALL_STATE_NORMAL 0
#define BALL_STATE_DEAD 1
#define BALL_STATE_POPPED 2

// Константы движения (из BounceConst.java)
#define MOVE_UP 8
#define MOVE_DOWN 4  
#define MOVE_RIGHT 2
#define MOVE_LEFT 1

// Размеры и константы (из оригинального Bounce)
#define TILE_SIZE 12
#define SCREEN_WIDTH 480
#define SCREEN_HEIGHT 272

// Структура игрока (адаптированная из Ball.java)
typedef struct {
    int xPos, yPos;           // Позиция игрока
    int xSpeed, ySpeed;       // Скорость (умножена на 10 для точности)
    int direction;            // Битовые флаги направления (1=LEFT, 2=RIGHT, 8=JUMP)
    int ballSize;             // Размер мяча (12 или 16)
    int mHalfBallSize;        // Половина размера
    int jumpOffset;           // Смещение прыжка
    int ballState;            // 0=normal, 1=respawn, 2=popped
    int sizeState;            // 0=small (12), 1=large (16)
    
    // Флаги состояния
    int mGroundedFlag;        // На земле ли игрок
    int mCDRubberFlag;        // Коллизия с резиновой поверхностью
    int mCDRampFlag;          // Коллизия с наклонной поверхностью
    
    // Бонусы
    int speedBonusCntr;       // Счётчик бонуса скорости
    int gravBonusCntr;        // Счётчик бонуса гравитации
    int jumpBonusCntr;        // Счётчик бонуса прыжка
    
    int slideCntr;            // Счётчик скольжения
} Player;

// Глобальное состояние
typedef struct {
    GameState state;
    int menu_selection;
    int selected_level;    // ДОБАВЛЕНО: текущий выбранный уровень (1-11)
    Player player;
    int buffered_jump;     // Буфер для нажатий прыжка между тиками
} Game;

extern Game g_game;

// Функции физики
void player_init(Player* p, int x, int y, int sizeState);
void player_update(Player* p);
int check_collision_at(Player* p, int x, int y);
void set_direction(Player* p, int dir);
void release_direction(Player* p, int dir);

// Функции изменения размера (для будущего)
void enlarge_ball(Player* p);
void shrink_ball(Player* p);
void pop_ball(Player* p);

#endif