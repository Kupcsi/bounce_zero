#ifndef SAVE_H
#define SAVE_H

#include "types.h"

#ifdef __cplusplus
extern "C" {
#endif

// Функции системы сохранений - объявления уже есть в types.h
// Этот header нужен для включения в другие файлы

#ifdef __cplusplus
}
#endif

#endif // SAVE_H