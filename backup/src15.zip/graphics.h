#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <psptypes.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Инициализация графической подсистемы
 */
void graphics_init(void);

/**
 * Завершение работы графической подсистемы
 */
void graphics_shutdown(void);

/**
 * Начать новый кадр
 */
void graphics_start_frame(void);

/**
 * Завершить текущий кадр и отобразить на экране
 */
void graphics_end_frame(void);

/**
 * Очистить экран указанным цветом.
 *
 * @param color Цвет в формате ABGR (A в старшем байте).
 *        ВАЖНО: Формат соответствует внутреннему формату PSP GU (GU_PSM_8888).
 *        На PSP (little-endian) это значит, что байты в памяти лежат как R,G,B,A.
 *        Пример: непрозрачный красный = 0xFF0000FF (A=FF, B=00, G=00, R=FF).
 */
void graphics_clear(u32 color);

/**
 * Нарисовать прямоугольник
 * @param x X координата левого верхнего угла
 * @param y Y координата левого верхнего угла
 * @param w Ширина прямоугольника
 * @param h Высота прямоугольника
 * @param color Цвет в формате ABGR (A в старшем байте).
 *        ВАЖНО: Тот же формат что и в graphics_clear() - PSP GU нативный.
 */
void graphics_draw_rect(float x, float y, float w, float h, u32 color);

/**
 * Нарисовать текст стандартного размера
 * @param x X координата левого верхнего угла текста
 * @param y Y координата левого верхнего угла текста
 * @param text Строка для отображения
 * @param color Цвет текста в формате ABGR (A в старшем байте)
 */
void graphics_draw_text(float x, float y, const char* text, u32 color);

/**
 * Нарисовать текст с масштабированием
 * @param x X координата левого верхнего угла текста
 * @param y Y координата левого верхнего угла текста
 * @param text Строка для отображения
 * @param color Цвет текста в формате ABGR (A в старшем байте)
 * @param scale Коэффициент масштабирования (1.0f = стандартный размер)
 */
void graphics_draw_text_scaled(float x, float y, const char* text, u32 color, float scale);

/**
 * Измерить ширину текста с учетом масштабирования
 * @param text Строка для измерения
 * @param scale Коэффициент масштабирования
 * @return Ширина текста в пикселях
 */
float graphics_measure_text(const char* text, float scale);

#ifdef __cplusplus
}
#endif

#endif