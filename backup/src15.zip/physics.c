// physics.c - Портированная физика из Ball.java (с подводной физикой)
#include "types.h"
#include "level.h"
#include <stdlib.h>



// Константы перенесены в types.h для централизации

// Инициализация игрока (ОБНОВЛЕНО)
void player_init(Player* p, int x, int y, BallSizeState sizeState) {
    p->xPos = x;
    p->yPos = y;
    p->xSpeed = 0;
    p->ySpeed = 0;
    p->direction = 0;
    p->jumpOffset = 0;
    p->ballState = BALL_STATE_NORMAL;
    p->sizeState = sizeState;
    
    // Установка размера в зависимости от состояния
    if (sizeState == SMALL_SIZE_STATE) {
        p->ballSize = NORMAL_SIZE;
        p->mHalfBallSize = HALF_NORMAL_SIZE;
    } else if (sizeState == LARGE_SIZE_STATE) {
        p->ballSize = ENLARGED_SIZE;
        p->mHalfBallSize = HALF_ENLARGED_SIZE;
    }
    
    p->mGroundedFlag = 0;
    p->mCDRubberFlag = 0;
    
    p->speedBonusCntr = 0;
    p->gravBonusCntr = 0;
    p->jumpBonusCntr = 0;
    p->slideCntr = 0;
    
    // ДОБАВЛЕНО: инициализация подводного флага
    p->isInWater = 0;
}

// Увеличение мяча (портировано из enlargeBall()) - ПОЛНОСТЬЮ ИСПРАВЛЕНО
void enlarge_ball(Player* p) {
    if (p->sizeState == LARGE_SIZE_STATE) return; // Уже большой
    
    p->sizeState = LARGE_SIZE_STATE;
    p->ballSize = ENLARGED_SIZE;
    p->mHalfBallSize = HALF_ENLARGED_SIZE;
    
    // Полная логика поиска свободного места как в оригинале
    int offset = 2;
    int found_free_space = 0;
    
    while (!found_free_space) {
        found_free_space = 1;
        
        // Проверяем все 6 направлений в порядке приоритета как в Ball.java:
        if (check_collision_at(p, p->xPos, p->yPos - offset)) {
            // 1. Вверх (приоритет)
            p->yPos -= offset;
        } else if (check_collision_at(p, p->xPos - offset, p->yPos - offset)) {
            // 2. Лево-вверх
            p->xPos -= offset;
            p->yPos -= offset;
        } else if (check_collision_at(p, p->xPos + offset, p->yPos - offset)) {
            // 3. Право-вверх
            p->xPos += offset;
            p->yPos -= offset;
        } else if (check_collision_at(p, p->xPos, p->yPos + offset)) {
            // 4. Вниз
            p->yPos += offset;
        } else if (check_collision_at(p, p->xPos - offset, p->yPos + offset)) {
            // 5. Лево-вниз
            p->xPos -= offset;
            p->yPos += offset;
        } else if (check_collision_at(p, p->xPos + offset, p->yPos + offset)) {
            // 6. Право-вниз
            p->xPos += offset;
            p->yPos += offset;
        } else {
            // Не нашли свободное место - увеличиваем радиус поиска
            found_free_space = 0;
            offset++;
            if (offset > 20) break; // Защита от бесконечного цикла
        }
    }
}

// Уменьшение мяча (портировано из shrinkBall()) - ИСПРАВЛЕНО
void shrink_ball(Player* p) {
    if (p->sizeState == SMALL_SIZE_STATE) return; // Уже маленький
    
    p->sizeState = SMALL_SIZE_STATE;
    p->ballSize = NORMAL_SIZE;
    p->mHalfBallSize = HALF_NORMAL_SIZE;
    
    // Проверка позиции после уменьшения как в оригинале
    int offset = 2;
    if (check_collision_at(p, p->xPos, p->yPos + offset)) {
        p->yPos += offset;
    } else if (check_collision_at(p, p->xPos, p->yPos - offset)) {
        p->yPos -= offset;
    }
    // Если оба направления заняты - остаемся на месте
}

// Лопание мяча (портировано из popBall())
void pop_ball(Player* p) {
    p->ballState = BALL_STATE_POPPED;
    p->xSpeed = 0;
    p->ySpeed = 0;
    
    // Сброс бонусов
    p->speedBonusCntr = 0;
    p->gravBonusCntr = 0;
    p->jumpBonusCntr = 0;
}

// Установка направления (битовые флаги)
// MOVE_DOWN не используется - падение происходит автоматически через гравитацию
void set_direction(Player* p, MoveDirection dir) {
    if (dir == MOVE_LEFT || dir == MOVE_RIGHT || dir == MOVE_UP) {
        p->direction |= (MoveMask)dir;
    }
}

// Сброс направления
// MOVE_DOWN не используется - падение происходит автоматически через гравитацию
void release_direction(Player* p, MoveDirection dir) {
    if (dir == MOVE_LEFT || dir == MOVE_RIGHT || dir == MOVE_UP) {
        p->direction &= (MoveMask)~dir;
    }
}

// Проверка коллизий с тайловой системой (ОБНОВЛЕНО с подводной физикой и рампами)
// Возвращает: 1 = свободно (можно двигаться), 0 = коллизия (препятствие)
int check_collision_at(Player* p, int x, int y) {
    p->mCDRubberFlag = 0;
    // Убрана проверка рамп (ID 30-37) - теперь они проходимы

    // Границы уровня (по фактической карте)
    int levelW = g_level.width * TILE_SIZE;
    int levelH = g_level.height * TILE_SIZE;
    if (x < 0 || y < 0 || x + p->ballSize > levelW || y + p->ballSize > levelH) {
        return 0; // 0 = коллизия с границами уровня (нельзя двигаться)
    }
    
    // ДОБАВЛЕНО: Проверка водного тайла под мячом
    int tileX = x / TILE_SIZE;
    int tileY = y / TILE_SIZE; 
    
    if (tileX >= 0 && tileX < g_level.width && tileY >= 0 && tileY < g_level.height) {
        int fullTile = g_level.tileMap[tileY][tileX];
        p->isInWater = (fullTile & TILE_FLAG_WATER) ? 1 : 0;  // Проверяем водный флаг
        
    } else {
        p->isInWater = 0;  // Вне карты - не в воде
    }
    
    // Коллизии делегированы на level_is_area_free (рампы/треугольники поддерживаются там)
    return level_is_area_free(x, y, p->ballSize, p->ballSize, p);
}

// Основное обновление физики (ИСПРАВЛЕННОЕ с подводной физикой)
void player_update(Player* p) {
    if (p->ballState == BALL_STATE_POPPED) return; // Если мяч лопнул
    
    // КРИТИЧНО: сохраняем состояние воды в начале кадра
    
    int gravity, gravityStep;
    int maxSpeed;
    int reverseGrav = 0;
    
    // ИСПРАВЛЕНО: выбор гравитации с учетом воды
    if (p->isInWater) {
        // В ВОДЕ - совершенно другая физика!
        if (p->ballSize == 16) {
            gravity = UWATER_LARGE_MAX_GRAVITY;    // -30 (всплывает!)
            gravityStep = LARGE_UWATER_GRAVITY_ACCELL; // -2
            
            // Большой мяч в воде автоматически получает начальную скорость всплытия
            if (p->mGroundedFlag) {
                p->ySpeed = UWATER_FLOAT_SPEED;
            }
        } else {
            gravity = UWATER_MAX_GRAVITY;       // 42 
            gravityStep = UWATER_GRAVITY_ACCELL; // 6
        }
    } else {
        // НА СУШЕ - обычная физика
        if (p->ballSize == 16) {
            gravity = LARGE_MAX_GRAVITY;        // 38
            gravityStep = LARGE_GRAVITY_ACCELL; // 3
        } else {
            gravity = NORMAL_MAX_GRAVITY;        // 80
            gravityStep = NORMAL_GRAVITY_ACCELL; // 4
        }
    }
    
    // Вычисляем флаг подводного большого мяча ДО изменения знака gravityStep
    const int isUnderwaterLarge = (p->isInWater && p->ballSize == ENLARGED_SIZE);
    
    // Бонус гравитации (обратная гравитация)
    if (p->gravBonusCntr > 0) {
        reverseGrav = 1;
        gravity *= -1;
        gravityStep *= -1;
        p->gravBonusCntr--;
    }
    
    // Счётчик скольжения
    p->slideCntr++;
    if (p->slideCntr == 3) {
        p->slideCntr = 0;
    }
    
    // Ограничение скорости (ИСПРАВЛЕНО)
    if (p->ySpeed < -MAX_TOTAL_SPEED) p->ySpeed = -MAX_TOTAL_SPEED;
    else if (p->ySpeed > MAX_TOTAL_SPEED) p->ySpeed = MAX_TOTAL_SPEED;
    if (p->xSpeed < -MAX_TOTAL_SPEED) p->xSpeed = -MAX_TOTAL_SPEED;
    else if (p->xSpeed > MAX_TOTAL_SPEED) p->xSpeed = MAX_TOTAL_SPEED;
    
    // === ФИЗИКА ПО ОСИ Y ===
    int ySteps = abs(p->ySpeed) / 10;
    for (int i = 0; i < ySteps; i++) {
        int yStep = 0;
        if (p->ySpeed != 0) {
            yStep = (p->ySpeed < 0) ? -1 : 1;
        }
        
        if (check_collision_at(p, p->xPos, p->yPos + yStep)) {
            p->yPos += yStep;
            p->mGroundedFlag = 0;
        } else {
            // Коллизия - пытаемся скользить
            int slideStep = 1;
            if (check_collision_at(p, p->xPos + slideStep, p->yPos + yStep)) {
                p->xPos += slideStep;
                p->yPos += yStep;
            } else if (check_collision_at(p, p->xPos - slideStep, p->yPos + yStep)) {
                p->xPos -= slideStep;
                p->yPos += yStep;
            } else {
                // Коллизия - отскок (ИСПРАВЛЕНО: точный Java-порядок операций)
                if (yStep > 0 || (reverseGrav && yStep < 0)) {
                    // 1) Java: this.ySpeed = this.ySpeed * BOUNCE_NUMERATOR / BOUNCE_DENOMINATOR;
                    p->ySpeed = p->ySpeed * BOUNCE_NUMERATOR / BOUNCE_DENOMINATOR;
                    p->mGroundedFlag = 1;
                    
                    // 2) Java-порядок нормализации скорости в зависимости от среды
                    if (!p->isInWater) {
                        // В сухой среде: нормализовать до ±MIN_BOUNCE_SPEED при |v| < MIN
                        if (p->ySpeed < MIN_BOUNCE_SPEED && p->ySpeed > -MIN_BOUNCE_SPEED) {
                            if (reverseGrav) {
                                p->ySpeed = -MIN_BOUNCE_SPEED;  // Java: this.ySpeed = -10;
                            } else {
                                p->ySpeed = MIN_BOUNCE_SPEED;   // Java: this.ySpeed = 10;
                            }
                        }
                    } else {
                        // В водной среде: для большого мяча может стать 0
                        if (p->ballSize == ENLARGED_SIZE && abs(p->ySpeed) <= MIN_BOUNCE_SPEED) {
                            p->ySpeed = 0;  // Java: разрешается 0 в воде для большого мяча
                        }
                    }
                    
                    // Обработка прыжка при касании земли (как в Java)
                    if (p->mCDRubberFlag && (p->direction & MOVE_UP)) {
                        p->mCDRubberFlag = 0;
                        if (reverseGrav) {
                            p->jumpOffset += -JUMP_STRENGTH_INC;  // Java: += 10, но JUMP_STRENGTH_INC = -10
                        } else {
                            p->jumpOffset += JUMP_STRENGTH_INC;   // Java: += -10
                        }
                    } else if (p->jumpBonusCntr == 0) {
                        p->jumpOffset = 0;
                    }
                    
                    break;
                }
                
                if (yStep < 0 || (reverseGrav && yStep > 0)) {
                    if (reverseGrav) {
                        p->ySpeed = -ROOF_COLLISION_SPEED;
                    } else {
                        p->ySpeed = ROOF_COLLISION_SPEED;
                    }
                }
            }
        }
    }
    
    // УДАЛЕНО: старая дублированная логика "выхода из воды"
    // Теперь нормализация скорости выполняется в блоке коллизии по Java-порядку
    
    // КАЖДОКАДРОВОЕ накопление jumpOffset для большого мяча (как в Java 1118-1124)
    if (p->ballSize == ENLARGED_SIZE && p->jumpBonusCntr == 0) {
        if (reverseGrav) {
            p->jumpOffset += 5;   // Java: this.jumpOffset += 5;
        } else {
            p->jumpOffset += -5;  // Java: this.jumpOffset += -5;
        }
    }
    
    // Применение гравитации (ИСПРАВЛЕНО с использованием isUnderwaterLarge)
    if (reverseGrav) {
        if (isUnderwaterLarge && p->ySpeed < gravity) {
            p->ySpeed = p->ySpeed + gravityStep;
            if (p->ySpeed > gravity) p->ySpeed = gravity;
        } else if (!p->mGroundedFlag && p->ySpeed > gravity) {
            p->ySpeed = p->ySpeed + gravityStep;
            if (p->ySpeed < gravity) p->ySpeed = gravity;
        }
    } else {
        if (isUnderwaterLarge && p->ySpeed > gravity) {
            p->ySpeed = p->ySpeed + gravityStep;
            if (p->ySpeed < gravity) p->ySpeed = gravity;
        } else if (!p->mGroundedFlag && p->ySpeed < gravity) {
            p->ySpeed = p->ySpeed + gravityStep;
            if (p->ySpeed > gravity) p->ySpeed = gravity;
        }
    }
    
    // === УПРАВЛЕНИЕ ГОРИЗОНТАЛЬНЫМ ДВИЖЕНИЕМ === (ИСПРАВЛЕНО)
    maxSpeed = (p->speedBonusCntr > 0) ? MAX_HORZ_BONUS_SPEED : MAX_HORZ_SPEED;
    if (p->speedBonusCntr > 0) p->speedBonusCntr--;
    
    if ((p->direction & MOVE_RIGHT) && p->xSpeed < maxSpeed) {
        p->xSpeed = p->xSpeed + HORZ_ACCELL;
    } else if ((p->direction & MOVE_LEFT) && p->xSpeed > -maxSpeed) {
        p->xSpeed = p->xSpeed - HORZ_ACCELL;
    } else if (p->xSpeed > 0) {
        p->xSpeed = p->xSpeed - FRICTION_DECELL;
    } else if (p->xSpeed < 0) {
        p->xSpeed = p->xSpeed + FRICTION_DECELL;
    }
    
    // === ПРЫЖОК === (ИСПРАВЛЕНО с правильными константами)
    if (p->mGroundedFlag && (p->direction & MOVE_UP)) {
        if (reverseGrav) {
            p->ySpeed = -JUMP_STRENGTH + p->jumpOffset; // 67 + offset
        } else {
            p->ySpeed = JUMP_STRENGTH + p->jumpOffset;  // -67 + offset
        }
        p->mGroundedFlag = 0;
        
        // В 100% Java-совместимой архитектуре физика НЕ сбрасывает флаги.
        // Модуль ввода управляет всеми direction флагами.
    }
    
    // === ФИЗИКА ПО ОСИ X ===
    int xSteps = abs(p->xSpeed) / 10;
    for (int i = 0; i < xSteps; i++) {
        int xStep = 0;
        if (p->xSpeed != 0) {
            xStep = (p->xSpeed < 0) ? -1 : 1;
        }
        
        if (check_collision_at(p, p->xPos + xStep, p->yPos)) {
            p->xPos += xStep;
        } else {
            // Коллизия по X - отскок (ИСПРАВЛЕНО с защитой от деления на ноль)
            if (p->xSpeed != 0) {  // ДОБАВЛЕНА защита
                p->xSpeed = -(p->xSpeed >> 1);
            }
            break;
        }
    }
    
    // Границы уровня по X
    int levelW = g_level.width * TILE_SIZE;
    if (p->xPos < 0) p->xPos = 0;
    if (p->xPos > levelW - p->ballSize) p->xPos = levelW - p->ballSize;

    
    // Сброс флагов коллизий
    p->mCDRubberFlag = 0;
}