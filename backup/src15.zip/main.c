#include <pspkernel.h>
#include "graphics.h"
#include "input.h"
#include "game.h"
#include "types.h"

PSP_MODULE_INFO("2D Platformer", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(PSP_THREAD_ATTR_USER);

// Макрос для подавления предупреждений о неиспользуемых параметрах
#define UNUSED(x) ((void)(x))

// Делитель частоты обновления физики (60 FPS -> 30 FPS)
#define PHYSICS_TICK_DIVIDER 2

/**
 * Callback для выхода из приложения при нажатии HOME
 */
int exit_callback(int arg1, int arg2, void *common) {
    UNUSED(arg1); UNUSED(arg2); UNUSED(common);
    g_game.state = STATE_EXIT;  // Элегантное завершение через игровой цикл
    return 0;
}

/**
 * Поток для обработки системных callback'ов PSP
 */
int callback_thread(SceSize args, void *argp) {
    UNUSED(args); UNUSED(argp);
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();
    return 0;
}

int setup_callbacks(void) {
    int thid = sceKernelCreateThread("update_thread", callback_thread, 0x11, 0xFA0, 0, 0);
    if(thid >= 0)
        sceKernelStartThread(thid, 0, 0);
    return thid;
}

int main(void) {
    setup_callbacks();
    
    graphics_init();
    input_init();
    game_init();
    
    // Счётчик для замедления физики до оригинальной частоты
    int tick_counter = 0;
    // Универсальные буферы для input'ов между тиками физики  
    int buffered_jump_pressed = 0;
    int buffered_jump_released = 0;
    
    while(g_game.state != STATE_EXIT) {
        input_update();
        
        // === ОБНОВЛЕНИЕ МЕНЮ И ИНТЕРФЕЙСА (каждый кадр) ===
        if(g_game.state == STATE_MENU || g_game.state == STATE_ABOUT || g_game.state == STATE_LEVEL_SELECT) {
            game_update();  // Меню и About обновляются на полной частоте
        }
        
        // === ОБНОВЛЕНИЕ ИГРОВОЙ ФИЗИКИ (замедленно) ===
        else if(g_game.state == STATE_GAME) {
                        // Обработка выхода/ABOUT на полной частоте кадров, независимо от тика физики
            if(input_pressed(PSP_CTRL_START)) {
                g_game.state = STATE_MENU;
            }
            if(input_pressed(PSP_CTRL_TRIANGLE)) {
                g_game.state = STATE_ABOUT;
            }

            // Чистые буферы input'ов - main.c не знает о игровой логике
            if(input_pressed(PSP_CTRL_CROSS)) {
                buffered_jump_pressed = 1;
            }
            if(input_released(PSP_CTRL_CROSS)) {
                buffered_jump_released = 1;
            }
            
            // Обновляем физику только каждый N-й кадр для оптимизации
            tick_counter++;
            if(tick_counter >= PHYSICS_TICK_DIVIDER) {
                // Передаём все буферы в игровую логику
                g_game.buffered_jump = buffered_jump_pressed;
                g_game.buffered_jump_released = buffered_jump_released;
                game_update();
                
                // Сбрасываем все буферы после обработки
                buffered_jump_pressed = 0;
                buffered_jump_released = 0;
                tick_counter = 0;
            }
        }
        
        // Рендеринг всегда на полной частоте для плавности
        graphics_start_frame();
        game_render();
        graphics_end_frame();
    }
    
    graphics_shutdown();
    sceKernelExitGame();
    return 0;
}