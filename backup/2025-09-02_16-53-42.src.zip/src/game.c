#include "game.h"
#include "graphics.h"
#include "input.h"
#include "types.h"
#include "level.h"  // Содержит #include "png.h" и extern объявления
#include "tile_table.h" // Для TILE_SIZE
#include "menu.h"
#include <pspctrl.h>
#include <stdio.h>

Game g_game;

// УБРАЛИ дублированные extern объявления - они теперь в level.h
// extern texture_t* g_tileset;
// extern int g_tiles_per_row;

#define SCREEN_HEIGHT 272
#define CAMERA_UNINITIALIZED -999
#define CAMERA_DEADZONE_RATIO 0.30f

// HUD позиции и размеры
#define HUD_X 10.0f
#define HUD_Y_INFO 258.0f
#define HUD_HEIGHT 12               // Высота HUD полосы в пикселях

// Статическая переменная для вертикальной камеры с мертвой зоной
static int s_currentCameraY = CAMERA_UNINITIALIZED;

// Проверка является ли уровень маленьким (ниже экрана по высоте)
// Такие уровни центрируются по вертикали без мертвой зоны камеры
static inline int is_level_small(void) {
    return (g_level.height * TILE_SIZE) < SCREEN_HEIGHT;
}

// Получить смещение камеры для вертикального центрирования маленького уровня
// Возвращает отрицательное значение для центрирования уровня на экране
static inline int get_center_offset(void) {
    int levelPixelHeight = g_level.height * TILE_SIZE;
    return -(SCREEN_HEIGHT - levelPixelHeight) / 2;
}

void game_reset_camera(void) {
    if (is_level_small()) {
        s_currentCameraY = get_center_offset();
    } else {
        s_currentCameraY = CAMERA_UNINITIALIZED; // Будет инициализирована позицией игрока
    }
}

void game_init(void) {
    g_game.state = STATE_MENU;
    g_game.menu_selection = 0;
    g_game.selected_level = 1;
    g_game.buffered_jump = 0;
    
    // Инициализация системы колец (как в Java BounceCanvas.resetGame)
    g_game.numRings = 0;
    g_game.score = 0;
    g_game.exitOpen = false;
    
    
    // Инициализация меню
    menu_init();
    
    // Загружаем уровень 1
    level_load_by_number(1);
    
    // Инициализация игрока из данных уровня
    player_init(&g_game.player, g_level.startPosX, g_level.startPosY, 
                g_level.ballSize == 0 ? SMALL_SIZE_STATE : LARGE_SIZE_STATE);
}

void game_update(void) {
    switch(g_game.state) {
        case STATE_MENU:
            menu_update();
            break;
            
        case STATE_LEVEL_SELECT:
            level_select_update();
            break;
            
        case STATE_GAME: {
            // Обновление направления из инпута
            Player* p = &g_game.player;
            
            // Java-совместимая архитектура: ввод управляет флагами, физика их только читает
            
            // Движение ВЛЕВО
            if(input_held(PSP_CTRL_LEFT)) {
                set_direction(p, MOVE_LEFT);  
            } else {
                release_direction(p, MOVE_LEFT);  // Сбрасываем если НЕ нажато
            }
            
            // Движение ВПРАВО  
            if(input_held(PSP_CTRL_RIGHT)) {
                set_direction(p, MOVE_RIGHT);  
            } else {
                release_direction(p, MOVE_RIGHT);  // Сбрасываем если НЕ нажато
            }
            
            // ПРЫЖОК: 100% Java-совместимая логика
            // keyPressed -> set_direction, keyReleased -> release_direction
            if(g_game.buffered_jump || input_pressed(PSP_CTRL_CROSS)) {
                set_direction(p, MOVE_UP);
                g_game.buffered_jump = 0; // Сбрасываем буфер после использования
            }
            // Отпускание прыжка через буфер (красивая архитектура!)
            if(g_game.buffered_jump_released) {
                release_direction(p, MOVE_UP);
            }
            
            // Обновление физики игрока (частота 30 FPS управляется из main.c)
            player_update(p);
            
            // Обновление движущихся объектов  
            level_update_moving_objects();
            
            // Возврат в меню
            if(input_pressed(PSP_CTRL_START)) {
                g_game.state = STATE_MENU;
            }
            break;
        }
            
        case STATE_ABOUT:
            about_update();
            break;
            
        case STATE_EXIT:
            // Ничего не делаем, выход обрабатывается в main.c
            break;
    }
}

void game_render(void) {
    graphics_clear(BACKGROUND_COLOUR);
    
    switch(g_game.state) {
        case STATE_MENU:
            menu_render();
            break;
            
        case STATE_LEVEL_SELECT:
            level_select_render();
            break;
            
        case STATE_GAME: {
            Player* p = &g_game.player;
            
            // Горизонтальная камера - следует за игроком (как раньше)
            int cameraX = p->xPos - SCREEN_WIDTH / 2;
            
            // Вертикальная камера с мертвой зоной
            if (s_currentCameraY == CAMERA_UNINITIALIZED) {
                // Первая инициализация - только для больших уровней
                s_currentCameraY = p->yPos - SCREEN_HEIGHT / 2;
            }
            
            // Размеры мертвой зоны
            int deadZoneTop = (int)(SCREEN_HEIGHT * CAMERA_DEADZONE_RATIO);
            int deadZoneBottom = SCREEN_HEIGHT - deadZoneTop;
            
            // Мертвая зона работает только для больших уровней
            if (!is_level_small()) {
                int tempPlayerScreenY = p->yPos - s_currentCameraY;
                
                if (tempPlayerScreenY < deadZoneTop) {
                    // Игрок слишком высоко - двигаем камеру вверх
                    s_currentCameraY = p->yPos - deadZoneTop;
                } else if (tempPlayerScreenY > deadZoneBottom) {
                    // Игрок слишком низко - двигаем камеру вниз
                    s_currentCameraY = p->yPos - deadZoneBottom;
                }
                // Иначе камера остается на месте (мертвая зона)
            }
            
            int cameraY = s_currentCameraY;
            
            // Ограничиваем камеру границами уровня
            int maxCameraX = g_level.width * TILE_SIZE - SCREEN_WIDTH;
            int maxCameraY = g_level.height * TILE_SIZE - SCREEN_HEIGHT;
            
            if (cameraX < 0) cameraX = 0;
            if (cameraX > maxCameraX && maxCameraX > 0) cameraX = maxCameraX;
            
            if (is_level_small()) {
                // Для маленьких уровней фиксируем камеру по центру
                cameraY = get_center_offset();
            } else {
                // Обычное ограничение для больших уровней
                if (cameraY < 0) cameraY = 0;
                if (cameraY > maxCameraY && maxCameraY > 0) cameraY = maxCameraY;
            }
            
            // Рендерим уровень (исключая область HUD)
            level_set_ring_fg_defer(1);
            level_render_visible_area(cameraX, cameraY, SCREEN_WIDTH, SCREEN_HEIGHT - HUD_HEIGHT);
            
            // Игрок - позиция относительно камеры
            int playerScreenX = p->xPos - cameraX;
            int playerScreenY = p->yPos - cameraY;
            
            // ИСПРАВЛЕНО: Рисуем спрайт шара вместо цветного квадрата
            texture_t* tileset = level_get_tileset();
            if (tileset && level_get_tiles_per_row() > 0) {
                int ballSpriteX, ballSpriteY;
                
                if (p->ballState == BALL_STATE_POPPED) {
                    // Лопнувший шар - tileImages[48] = extractImage(image, 0, 1)
                    // Атлас позиция (0,1) = индекс 4
                    ballSpriteX = 0 * TILE_SIZE;
                    ballSpriteY = 1 * TILE_SIZE;
                } else if (p->sizeState == LARGE_SIZE_STATE) {
                    // Большой шар - tileImages[49] = createLargeBallImage(extractImage(image, 3, 0))
                    // Атлас позиция (3,0) = индекс 3, но это составной 2x2, используем базовый кусок
                    ballSpriteX = 3 * TILE_SIZE;
                    ballSpriteY = 0 * TILE_SIZE;
                } else {
                    // Маленький шар - tileImages[47] = extractImage(image, 2, 0)
                    // Атлас позиция (2,0) = индекс 2
                    ballSpriteX = 2 * TILE_SIZE;
                    ballSpriteY = 0 * TILE_SIZE;
                }
                
                sprite_rect_t ballSprite = png_create_sprite_rect(tileset, ballSpriteX, ballSpriteY, TILE_SIZE, TILE_SIZE);
                
                // Для большого мяча рендерим 2x2
                if (p->sizeState == LARGE_SIZE_STATE) {
                    // Рендерим 4 куска для большого мяча (как в Java createLargeBallImage)
                    for (int dy = 0; dy < 2; dy++) {
                        for (int dx = 0; dx < 2; dx++) {
                            png_xform_t xf = PNG_XFORM_IDENTITY;
                            if (dx == 1) xf = PNG_XFORM_FLIP_X;
                            if (dy == 1 && dx == 0) xf = PNG_XFORM_FLIP_Y;
                            if (dy == 1 && dx == 1) xf = PNG_XFORM_ROT_180;
                            
                            float x = (float)(playerScreenX + HALF_ENLARGED_SIZE - TILE_SIZE + dx * TILE_SIZE);
                            float y = (float)(playerScreenY + HALF_ENLARGED_SIZE - TILE_SIZE + dy * TILE_SIZE);
                            
                            if (xf == PNG_XFORM_IDENTITY) {
                                png_draw_sprite(tileset, &ballSprite, x, y, (float)TILE_SIZE, (float)TILE_SIZE);
                            } else {
                                png_draw_sprite_xform(tileset, &ballSprite, x, y, (float)TILE_SIZE, (float)TILE_SIZE, xf);
                            }
                        }
                    }
                } else {
                    // Обычный рендер для маленького мяча
                    png_draw_sprite(tileset, &ballSprite, (float)playerScreenX, (float)playerScreenY, (float)p->ballSize, (float)p->ballSize);
                }
            }
            
            // Инструкции и отладка (поверх всего)
            level_flush_ring_foreground();
            level_set_ring_fg_defer(0);

            // === HUD ФОНОВАЯ ПОЛОСА ===
            // Отключаем текстуры для рисования цветных примитивов
            sceGuDisable(GU_TEXTURE_2D);
            
            // Белая разделительная полоса (1 пиксель)
            float separator_y = SCREEN_HEIGHT - HUD_HEIGHT;
            graphics_draw_rect(0.0f, separator_y, (float)SCREEN_WIDTH, 1.0f, 0xFFFFFFFF);
            
            // HUD полоса водяным цветом (11 пикселей под белой полосой)
            float hud_y = separator_y + 1.0f;
            graphics_draw_rect(0.0f, hud_y, (float)SCREEN_WIDTH, (float)(HUD_HEIGHT - 1), WATER_COLOUR);

            // Восстанавливаем текстуры для PNG-рендера
            sceGuEnable(GU_TEXTURE_2D);
            sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
            
            // Простой тест HUD текста
            graphics_draw_text(10.0f, 260.0f, "HELLO", 0xFF000000);  // Простой чёрный текст

            break;
        }
            
        case STATE_ABOUT:
            about_render();
            break;
            
        case STATE_EXIT:
            break;
    }
}


// Добавляем функцию cleanup для game
void game_cleanup(void) {
    menu_cleanup();
    level_cleanup();
}

void game_add_score(int points) {
}

void game_add_ring(void) {
}

void game_set_respawn(int x, int y) {
}

void game_add_extra_life(void) {
}