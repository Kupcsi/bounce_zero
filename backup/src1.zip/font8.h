#ifndef FONT8_FONT_H
#define FONT8_FONT_H

#include <psptypes.h>

#ifdef __cplusplus
extern "C" {
#endif

#define FONT8_W 8
#define FONT8_H 8
#define FONT8_FIRST 32
#define FONT8_LAST  126
#define FONT8_COUNT (FONT8_LAST - FONT8_FIRST + 1)

typedef struct {
    u8 row[FONT8_H];
    u8 width;
} Glyph8;

const Glyph8* font8_table(void);
const Glyph8* font8_get_glyph(char c);

#ifdef __cplusplus
}
#endif

#endif