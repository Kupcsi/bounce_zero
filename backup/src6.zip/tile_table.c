#include "tile_table.h"

// Константы для нормалей поверхностей в Q15
static const q15_t Q15_NEG_ONE = -32767, Q15_ZERO = 0, Q15_INV_SQRT2 = 23170;

// Макросы для нормалей
#define N_NONE Q15_ZERO, Q15_ZERO
#define N_SOLID Q15_ZERO, Q15_NEG_ONE
#define N_BR Q15_INV_SQRT2, -Q15_INV_SQRT2
#define N_BL -Q15_INV_SQRT2, -Q15_INV_SQRT2
#define N_TR Q15_INV_SQRT2, Q15_INV_SQRT2
#define N_TL -Q15_INV_SQRT2, Q15_INV_SQRT2

// ПРАВИЛЬНАЯ таблица тайлов на основе точного анализа Java кода
__attribute__((aligned(64)))
static const TileMeta TILE_DB[67] = {
    /* 00 EMPTY - пустой тайл, фон заливается цветом */
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE },


    /* 01 BLOCK - tileImages[0] = extractImage(image, 1, 0) = атлас[1] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 1, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },

    /* 02 RUBBER_BLOCK - tileImages[1] = extractImage(image, 1, 2) = атлас[9] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 9, TF_NONE, LOGIC_RUBBER, SPECIAL_NONE, 0 },

    /* 03 SPIKES - Java case 3: bool ? tileImages[6] : tileImages[2]
       Оба из extractImageBG(image, 0, 3, цвет) = позиция (0,3) = атлас[12]
       Без трансформаций - просто базовый спрайт факел */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 12, TF_NONE, LOGIC_HAZARD, SPECIAL_FLAG_0x40, 12 },

    /* 04 SPIKES - tileImages[4] = manipulateImage(tileImages[2], 3) = атлас[12] + ROT_90 */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 12, TF_ROT_90, LOGIC_HAZARD, SPECIAL_FLAG_0x40, 12 },

    /* 05 SPIKES - tileImages[5] = manipulateImage(tileImages[2], 5) = атлас[12] + ROT_270 */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 12, TF_ROT_270, LOGIC_HAZARD, SPECIAL_FLAG_0x40, 12 },

    /* 06 SPIKES - tileImages[2] = extractImageBG(image, 0, 3, светлый) = атлас[12] без трансформации */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 12, TF_NONE, LOGIC_HAZARD, SPECIAL_FLAG_0x40, 12 },

    /* 07 CHECKPOINT - tileImages[10] = extractImage(image, 0, 4) = атлас[16] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 16, TF_NONE, LOGIC_RING, SPECIAL_NONE, 0 },

    /* 08 BLOCK - tileImages[11] = extractImage(image, 3, 4) = атлас[19] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 19, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },

    /* 09 EXIT - составной тайл из tileImages[12] = createExitImage(атлас[14]) */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 14, TF_NONE, LOGIC_EXIT, SPECIAL_COMPOSITE, 0 },

    /* 10 MOVING_SPIKES - составной из tileImages[46] = атлас[13] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 13, TF_NONE, LOGIC_HAZARD, SPECIAL_COMPOSITE, 0 },

    /* 11-12 - неиспользуемые слоты */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },

    /* 13 RING - ТЕСТ: делаем EMPTY чтобы не рендерился */
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_DUAL_SPRITE, 21, TF_NONE },

    /* 14 RING - ТОЧНО по Java коду:  
       Фон: tileImages[36] = атлас[21] + ROT_270 + FLIP_Y + FLIP_X
       Кольцо: tileImages[34] = атлас[21] + ROT_270 + FLIP_Y */
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_DUAL_SPRITE, 21, TF_FLIP_Y },

    /* 15 RING - Java: fillRect + drawImage(tileImages[17]) + add2HoopList(tileImages[18])
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_DUAL_SPRITE, 21, TF_NONE },
       tileImages[18] = extractImage(image, 1, 5) = атлас[21] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 21, TF_FLIP_Y, LOGIC_RING, SPECIAL_DUAL_SPRITE, 21 },

    /* 16 RING - Java: fillRect + drawImage(tileImages[19]) + add2HoopList(tileImages[20])
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_DUAL_SPRITE, 21, TF_FLIP_X },
       tileImages[20] = manipulateImage(tileImages[18], 0) = FLIP_X */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 21, TF_FLIP_XY, LOGIC_RING, SPECIAL_DUAL_SPRITE, 21 },

    /* 17-28 - остальные кольца (разные размеры и цвета) */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 20, TF_NONE, LOGIC_RING, SPECIAL_DUAL_SPRITE, 20 },      // большое кольцо
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 20, TF_FLIP_X, LOGIC_RING, SPECIAL_DUAL_SPRITE, 20 },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 22, TF_NONE, LOGIC_RING, SPECIAL_DUAL_SPRITE, 22 },     // большое кольцо ✓
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 22, TF_FLIP_X, LOGIC_RING, SPECIAL_DUAL_SPRITE, 22 },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 23, TF_NONE, LOGIC_RING, SPECIAL_DUAL_SPRITE, 23 },     // обычное кольцо ✓  
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 23, TF_FLIP_X, LOGIC_RING, SPECIAL_DUAL_SPRITE, 23 },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 21, TF_NONE, LOGIC_RING, SPECIAL_DUAL_SPRITE, 21 },     // обычное кольцо
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 21, TF_FLIP_X, LOGIC_RING, SPECIAL_DUAL_SPRITE, 21 },   
    
    // Декоративные тайлы
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 15, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },           // хрустальный шар
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },            // ускоритель
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 10, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },           // неизвестно
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },           // неизвестно
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },

    /* 30-37 RAMPS - рампы с флагом 0x40 для переключения каменная(0)/резиновая(8) */
    /* 30 RAMP_FLOOR_TL - Java: bool ? tileImages[61] : tileImages[57] 
       tileImages[57] = manipulateImage(tileImages[55], 4) = ROT_180
       tileImages[55] = extractImageBG(image, 0, 0, светлый) = атлас[0] */
    { TILETYPE_RAMP_FLOOR, ORIENT_TL, MASK_TRI, N_TL, 0, TF_ROT_180, LOGIC_NONE, SPECIAL_FLAG_0x40, 8 },

    /* 31 RAMP_FLOOR_TR - Java: bool ? tileImages[60] : tileImages[56] */
    { TILETYPE_RAMP_FLOOR, ORIENT_TR, MASK_TRI, N_TR, 0, TF_ROT_270, LOGIC_NONE, SPECIAL_FLAG_0x40, 8 },

    /* 32 RAMP_FLOOR_BR - Java: bool ? tileImages[59] : tileImages[55] */
    { TILETYPE_RAMP_FLOOR, ORIENT_BR, MASK_TRI, N_BR, 0, TF_NONE, LOGIC_NONE, SPECIAL_FLAG_0x40, 8 },

    /* 33 RAMP_FLOOR_BL - Java: bool ? tileImages[62] : tileImages[58] */
    { TILETYPE_RAMP_FLOOR, ORIENT_BL, MASK_TRI, N_BL, 0, TF_ROT_90, LOGIC_NONE, SPECIAL_FLAG_0x40, 8 },

    /* 34-37 RAMP_CEIL - рампы потолок (резиновые, базовый спрайт 8) */
    { TILETYPE_RAMP_CEIL, ORIENT_TL, MASK_TRI, N_TL, 8, TF_ROT_180, LOGIC_RUBBER, SPECIAL_NONE, 0 },
    { TILETYPE_RAMP_CEIL, ORIENT_TR, MASK_TRI, N_TR, 8, TF_ROT_270, LOGIC_RUBBER, SPECIAL_NONE, 0 },
    { TILETYPE_RAMP_CEIL, ORIENT_BR, MASK_TRI, N_BR, 8, TF_NONE, LOGIC_RUBBER, SPECIAL_NONE, 0 },
    { TILETYPE_RAMP_CEIL, ORIENT_BL, MASK_TRI, N_BL, 8, TF_ROT_90, LOGIC_RUBBER, SPECIAL_NONE, 0 },

    /* 38 - декоративный */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_FLIP_X, LOGIC_NONE, SPECIAL_NONE, 0 },

    /* 39-42 SHRINK_TILE - tileImages[50] = extractImage(image, 3, 1) = атлас[7] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 7, TF_NONE, LOGIC_SHRINK, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 7, TF_ROT_90, LOGIC_SHRINK, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 7, TF_ROT_180, LOGIC_SHRINK, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 7, TF_ROT_270, LOGIC_SHRINK, SPECIAL_NONE, 0 },

    /* 43-46 GROW_TILE - tileImages[51] = extractImage(image, 2, 4) = атлас[18] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 18, TF_NONE, LOGIC_GROW, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 18, TF_ROT_90, LOGIC_GROW, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 18, TF_ROT_180, LOGIC_GROW, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 18, TF_ROT_270, LOGIC_GROW, SPECIAL_NONE, 0 },

    /* 47-54 - декоративные тайлы из tileImages[52,53,54] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },     // [52]
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_ROT_90, LOGIC_NONE, SPECIAL_NONE, 0 },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_ROT_180, LOGIC_NONE, SPECIAL_NONE, 0 },  
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_ROT_270, LOGIC_NONE, SPECIAL_NONE, 0 },  
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_ROT_90, LOGIC_NONE, SPECIAL_NONE, 0 },    // [53] 
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_ROT_180, LOGIC_NONE, SPECIAL_NONE, 0 },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_ROT_270, LOGIC_NONE, SPECIAL_NONE, 0 },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 10, TF_ROT_90, LOGIC_NONE, SPECIAL_NONE, 0 },   // [54]

    /* 55-66 - заполнители/неиспользуемые */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0 }
};

// Функции доступа
const TileMeta* tile_meta_db(void) {
    return TILE_DB;
}

uint32_t tile_meta_count(void) {
    return 67;
}

int tile_meta_has_unspecified(void) {
    return 0;
}

// Вспомогательные функции
const char* tile_transform_name(TileTransform transform) {
    switch (transform) {
        case TF_NONE: return "NONE";
        case TF_FLIP_X: return "FLIP_X";
        case TF_FLIP_Y: return "FLIP_Y";
        case TF_FLIP_XY: return "FLIP_XY";
        case TF_ROT_90: return "ROT_90";
        case TF_ROT_180: return "ROT_180";
        case TF_ROT_270: return "ROT_270";
        default: return "UNKNOWN";
    }
}

int tile_needs_alt_sprite(const TileMeta* tile, int tile_flags) {
    return (tile->special_flags & SPECIAL_FLAG_0x40) && (tile_flags & 0x40);
}