#ifndef TILE_TABLE_H
#define TILE_TABLE_H

#include <psptypes.h>

// Размер тайла в пикселях
#define TILE_SIZE 12

// Фиксированная точка Q15 для нормалей поверхностей
typedef s16 q15_t;

// Типы тайлов (физические свойства)
typedef enum {
    TILETYPE_EMPTY = 0,        // Пустой тайл (проходимый)
    TILETYPE_SOLID,            // Твердый блок
    TILETYPE_RAMP_FLOOR,       // Рампа (наклонный пол)
    TILETYPE_RAMP_CEIL         // Рампа (наклонный потолок)
} TileType;

// Ориентация тайла
typedef enum {
    ORIENT_NONE = 0,           // Без ориентации
    ORIENT_TL,                 // Top-Left (верхний левый угол)
    ORIENT_TR,                 // Top-Right (верхний правый угол)
    ORIENT_BL,                 // Bottom-Left (нижний левый угол)
    ORIENT_BR                  // Bottom-Right (нижний правый угол)
} TileOrientation;

// Маска коллизии
typedef enum {
    MASK_NONE = 0,             // Без маски
    MASK_TRI                   // Треугольная маска для рамп
} TileMask;

// Трансформации спрайтов (на основе Java manipulateImage)
typedef enum {
    TF_NONE = 0,               // Без трансформации
    TF_FLIP_X = 1,             // Отражение по X (manipulateImage case 0)
    TF_FLIP_Y = 2,             // Отражение по Y (manipulateImage case 1) 
    TF_FLIP_XY = 3,            // Отражение по X и Y (manipulateImage case 2)
    TF_ROT_90 = 4,             // Поворот на 90° (manipulateImage case 3)
    TF_ROT_180 = 5,            // Поворот на 180° (manipulateImage case 4)
    TF_ROT_270 = 6             // Поворот на 270° (manipulateImage case 5)
} TileTransform;

// Логика поведения тайла
typedef enum {
    LOGIC_NONE = 0,            // Нет специальной логики
    LOGIC_HAZARD,              // Опасность (шипы)
    LOGIC_RING,                // Кольцо для сбора
    LOGIC_EXIT,                // Выход из уровня
    LOGIC_SHRINK,              // Уменьшение мяча
    LOGIC_GROW,                // Увеличение мяча
    LOGIC_RUBBER               // Резиновая поверхность
} TileLogic;

// Специальные флаги для составных тайлов
typedef enum {
    SPECIAL_NONE = 0,          // Обычный тайл
    SPECIAL_COMPOSITE = 1,     // Составной тайл (EXIT, движущиеся шипы)
    SPECIAL_DUAL_SPRITE = 2,   // Тайл с двумя спрайтами (кольца)
    SPECIAL_FLAG_0x40 = 4      // Тайл переключается флагом 0x40
} TileSpecialFlags;


// Дополнительные флаги для комбинированных трансформаций (поверх transform/alt_transform)
#define SPECIAL_FLIP_X  0x40
#define SPECIAL_FLIP_Y  0x80
// Основная структура метаданных тайла
typedef struct {
    TileType type;             // Тип тайла (физика)
    TileOrientation orientation; // Ориентация
    TileMask mask;             // Маска коллизии
    q15_t normal_x, normal_y;  // Нормаль поверхности (Q15)
    uint16_t base_sprite_index;  // Базовый спрайт в атласе (0-23)
    TileTransform transform;   // Трансформация базового спрайта
    TileLogic logic;           // Логика поведения
    uint8_t special_flags;     // Специальные флаги
    uint8_t alt_sprite_index;  // Альтернативный спрайт (для флага 0x40)
    TileTransform  alt_transform;     // Трансформация альтернативного спрайта
} TileMeta;

// Функции доступа к таблице тайлов
const TileMeta* tile_meta_db(void);
uint32_t tile_meta_count(void);
int tile_meta_has_unspecified(void);

// Вспомогательные функции для работы с трансформациями
const char* tile_transform_name(TileTransform transform);
int tile_needs_alt_sprite(const TileMeta* tile, int tile_flags);

#endif // TILE_TABLE_H