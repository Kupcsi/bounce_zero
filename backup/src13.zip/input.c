#include "input.h"
#include <string.h>

static SceCtrlData pad = {0};
static SceCtrlData old_pad = {0};

void input_init(void) {
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
}

void input_update(void) {
    old_pad = pad;
    
    // Обработка ошибок чтения контроллера для предотвращения залипания кнопок
    if (sceCtrlReadBufferPositive(&pad, 1) <= 0) {
        pad = old_pad; // сохранить предыдущее состояние при ошибке
    }
}

int input_pressed(unsigned int button) {
    return (pad.Buttons & button) && !(old_pad.Buttons & button);
}

int input_held(unsigned int button) {
    return (pad.Buttons & button);
}