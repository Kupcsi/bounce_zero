#ifndef TYPES_H
#define TYPES_H

#include <stdbool.h>
#include <stdint.h>
#include "tile_table.h"

#ifdef __cplusplus
extern "C" {
#endif

// Состояния игры
typedef enum {
    STATE_MENU,
    STATE_LEVEL_SELECT,  // Выбор уровня
    STATE_GAME,
    STATE_ABOUT,
    STATE_EXIT
} GameState;

// Размеры спрайтов (в пикселях, из BounceConst.java)
#define NORMAL_SIZE 12      // Обычный размер мяча
#define HALF_NORMAL_SIZE 6
#define ENLARGED_SIZE 16    // Увеличенный размер мяча
#define HALF_ENLARGED_SIZE 8
#define POPPED_SIZE 12      // Размер лопнувшего мяча (совпадает с обычным по дизайну)
#define HALF_POPPED_SIZE 6

// Состояния размера мяча
typedef enum {
    SMALL_SIZE_STATE = 0,    // Маленький мяч: 12px спрайт, обычная физика
    LARGE_SIZE_STATE = 1     // Большой мяч: 16px спрайт, увеличенная сила прыжка
} BallSizeState;

// Состояния мяча
typedef enum {
    BALL_STATE_NORMAL = 0,   // Обычное состояние: активная физика, реагирует на ввод
    BALL_STATE_DEAD = 1,     // Мяч уничтожен: нужно респавнить в стартовой точке
    BALL_STATE_POPPED = 2    // Мяч лопнул: временная анимация, затем DEAD
} BallState;

// Битовые флаги направления движения (из BounceConst.java)
typedef enum {
    MOVE_LEFT = 1,     // Движение влево
    MOVE_RIGHT = 2,    // Движение вправо
    MOVE_DOWN = 4,     // Движение вниз
    MOVE_UP = 8        // Прыжок/движение вверх
} MoveDirection;

// Маска направлений движения (битовая комбинация MoveDirection)
typedef uint8_t MoveMask;

// Размеры игрового поля
#define SCREEN_WIDTH 480
#define SCREEN_HEIGHT 272

// Структура игрока (адаптированная из Ball.java)
typedef struct {
    // Позиция в экранных координатах (пиксели)
    int16_t xPos, yPos;
    
    // Скорость в единицах x0.1 пикселя/кадр для точности расчетов
    int16_t xSpeed, ySpeed;
    
    // Битовые флаги направления движения (комбинация MoveDirection)
    MoveMask direction;
    
    // Размер спрайта мяча в пикселях (12 или 16)
    int ballSize;
    int mHalfBallSize;        // Половина размера для расчета коллизий
    
    // Смещение спрайта при прыжке для анимационного эффекта
    int jumpOffset;
    
    // Состояние мяча (BALL_STATE_*)
    BallState ballState;
    // Размер мяча (SMALL_SIZE_STATE или LARGE_SIZE_STATE)
    BallSizeState sizeState;
    
    // Флаги физического состояния
    bool mGroundedFlag;        // true если мяч касается земли/платформы
    bool mCDRubberFlag;        // true если коллизия с резиновой поверхностью
    
    // Счетчики временных эффектов (в кадрах)
    int16_t speedBonusCntr;       // Остаток времени бонуса скорости
    int16_t gravBonusCntr;        // Остаток времени бонуса гравитации  
    int16_t jumpBonusCntr;        // Остаток времени бонуса прыжка
    
    // Счетчик скольжения по поверхности
    int16_t slideCntr;
    
    // Флаг нахождения в воде (тайл с флагом 0x40)
    bool isInWater;
} Player;

// Глобальное состояние игры
typedef struct {
    GameState state;          // Текущее состояние игры
    int menu_selection;       // Выбранный пункт меню
    int selected_level;       // Выбранный уровень (1-11)
    Player player;            // Состояние игрока
    
    // Буфер нажатий прыжка между тиками физики
    // Хранится в Game, а не в Player, для разделения ввода и физики
    int buffered_jump;
} Game;

extern Game g_game;

// Функции физики игрока (реализованы в отдельном файле физики)
void player_init(Player* p, int x, int y, BallSizeState sizeState);
void player_update(Player* p);
int check_collision_at(Player* p, int x, int y);
void set_direction(Player* p, MoveDirection dir);
void release_direction(Player* p, MoveDirection dir);

// Функции изменения размера мяча (для будущих бонусов)
void enlarge_ball(Player* p);
void shrink_ball(Player* p);
void pop_ball(Player* p);

#ifdef __cplusplus
}
#endif

#endif