#include "menu.h"
#include "graphics.h"
#include "input.h"
#include "types.h"
#include "level.h"
#include "png.h"
#include <pspctrl.h>
#include <pspgu.h>

// Нужен доступ к глобальному состоянию игры
extern Game g_game;

// Текстура для About окна (переместили из game.c)
static texture_t* g_about_texture = NULL;

void menu_init(void) {
    // Загружаем текстуру для About экрана
    if (!g_about_texture) {
        g_about_texture = png_load_texture("icons/bouncesplash.png");
    }
}

void menu_update(void) {
    // Навигация по меню (4 пункта: 0,1,2,3)
    if(input_pressed(PSP_CTRL_UP) && g_game.menu_selection > 0) {
        g_game.menu_selection--;
    }
    if(input_pressed(PSP_CTRL_DOWN) && g_game.menu_selection < 3) {
        g_game.menu_selection++;
    }
    
    // Выбор пункта меню
    if(input_pressed(PSP_CTRL_CROSS)) {
        if(g_game.menu_selection == 0) {
            // 0 = START
            g_game.state = STATE_GAME;
            level_load_by_number(g_game.selected_level);
            
            // Сброс счётчиков при старте уровня (как в Java BounceCanvas.startLevel)
            g_game.numRings = 0;
            g_game.score = 0; 
            g_game.exitOpen = false;
            
            player_init(&g_game.player, g_level.startPosX, g_level.startPosY, 
                       g_level.ballSize == 0 ? SMALL_SIZE_STATE : LARGE_SIZE_STATE);
        } else if(g_game.menu_selection == 1) {
            // 1 = SELECT LEVEL
            g_game.state = STATE_LEVEL_SELECT;
        } else if(g_game.menu_selection == 2) {
            // 2 = ABOUT
            g_game.state = STATE_ABOUT;
        } else if(g_game.menu_selection == 3) {
            // 3 = EXIT
            g_game.state = STATE_EXIT;
        }
    }
    
}

void menu_render(void) {
    
    // UI без текстурной модуляции
    sceGuDisable(GU_TEXTURE_2D);
const float center_x = 240.0f;
    const float title_y  = 50.0f;
    const float scale    = 2.0f;
    const int   bg_height = 25;
    
    // Заголовок (по центру)
    {
        const char* title = "Bounce";
        float w = graphics_measure_text(title, scale);
        float x = center_x - w * 0.5f;
        graphics_draw_text_scaled(x, title_y, title, 0xFF2135FF, scale);
    }
    
    // Данные пунктов меню
    struct Item { const char* label; float y; u32 color_unselected; };
    struct Item items[4] = {
        { "START",         110.0f, 0xFF000000 },
        { "SELECT LEVEL",  140.0f, 0xFF000000 },
        { "ABOUT",         170.0f, 0xFF000000 },
        { "EXIT",          200.0f, 0xFF000000 },
    };
    
    for (int i = 0; i < 4; ++i) {
        const int selected = (g_game.menu_selection == i);
        const u32 color = selected ? 0xFFFFFFFF : items[i].color_unselected;
        float w = graphics_measure_text(items[i].label, scale);
        float x = center_x - w * 0.5f;
        float y = items[i].y;
        
        // Фон под выбранным пунктом — строго по ширине текста с одинаковыми полями
        if (selected) {
            const float padding_x = 5.0f;
            const float padding_y = 5.0f;
            graphics_draw_rect(x - padding_x, y - padding_y, w + 2*padding_x, bg_height, 0xFF2135FF);
        }
        
        // Текст пункта
        graphics_draw_text_scaled(x, y, items[i].label, color, scale);
    }
    
}

void level_select_update(void) {
    // Навигация по уровням (сетка 5x3: 1-5, 6-10, 11)
    if(input_pressed(PSP_CTRL_LEFT) && g_game.selected_level > 1) {
        g_game.selected_level--;
    }
    if(input_pressed(PSP_CTRL_RIGHT) && g_game.selected_level < 11) {
        g_game.selected_level++;
    }
    if(input_pressed(PSP_CTRL_UP)) {
        if(g_game.selected_level > 5) {
            g_game.selected_level -= 5;
        }
    }
    if(input_pressed(PSP_CTRL_DOWN)) {
        if(g_game.selected_level <= 5) {
            g_game.selected_level += 5;
        } else if(g_game.selected_level <= 10 && g_game.selected_level != 11) {
            g_game.selected_level = 11;
        }
    }
    
    // Ограничиваем диапазон 1-11
    if(g_game.selected_level < 1) g_game.selected_level = 1;
    if(g_game.selected_level > 11) g_game.selected_level = 11;
    
    // Выбор уровня
    if(input_pressed(PSP_CTRL_CROSS)) {
        g_game.state = STATE_GAME;
        level_load_by_number(g_game.selected_level);
        
        // Сброс счётчиков при старте уровня (как в Java BounceCanvas.startLevel)
        g_game.numRings = 0;
        g_game.score = 0; 
        g_game.exitOpen = false;
        
        player_init(&g_game.player, g_level.startPosX, g_level.startPosY, 
                   g_level.ballSize == 0 ? SMALL_SIZE_STATE : LARGE_SIZE_STATE);
    }
    
    // Возврат в меню
    if(input_pressed(PSP_CTRL_CIRCLE)) {
        g_game.state = STATE_MENU;
    }
}

void level_select_render(void) {
    const float center_x = 240.0f;
    
    // UI цифры из битмапа — без текстурной модуляции
    sceGuDisable(GU_TEXTURE_2D);
// Заголовок
    {
        const char* title = "SELECT LEVEL";
        float w = graphics_measure_text(title, 2.0f);
        float x = center_x - w * 0.5f;
        graphics_draw_text_scaled(x, 30.0f, title, 0xFF000000, 2.0f);
    }
    
    // Размеры для сетки уровней
    int start_x = 140;
    int start_y = 80;
    int cell_width = 40;
    int cell_height = 30;
    int spacing_x = 50;
    int spacing_y = 40;
    
    // Рисуем уровни 1-10 в сетке 5x2
    for(int row = 0; row < 2; row++) {
        for(int col = 0; col < 5; col++) {
            int level = row * 5 + col + 1; // 1-10
            int x = start_x + col * spacing_x;
            int y = start_y + row * spacing_y;
            
            // Цветной фон для выбранного уровня (красный как в "Bounce")
            if(level == g_game.selected_level) {
                graphics_draw_rect((float)(x - 5), (float)(y - 5), (float)cell_width, (float)cell_height, 0xFF2135FF);
            }
            
            // Номер уровня
            char level_text[4];
            if(level < 10) {
                level_text[0] = (char)('0' + level);
                level_text[1] = '\0';
            } else {
                level_text[0] = '1';
                level_text[1] = '0';
                level_text[2] = '\0';
            }
            
            u32 color = (level == g_game.selected_level) ? 0xFFFFFFFF : 0xFF000000;
            graphics_draw_text_scaled((float)x, (float)y, level_text, color, 2.0f);
        }
    }
    
    // Уровень 11 отдельно по центру
    int x11 = start_x + 2 * spacing_x; // центр
    int y11 = start_y + 2 * spacing_y;
    
    if(g_game.selected_level == 11) {
        graphics_draw_rect((float)(x11 - 5), (float)(y11 - 5), (float)cell_width, (float)cell_height, 0xFF2135FF);
    }
    
    u32 color11 = (g_game.selected_level == 11) ? 0xFFFFFFFF : 0xFF000000;
    graphics_draw_text_scaled((float)x11, (float)y11, "11", color11, 2.0f);
    
    // Инструкции в одну строку внизу экрана
    const char* help_text = "ARROWS - navigate, X - select, O - back to menu";
    float text_width = graphics_measure_text(help_text, 1.0f);
    graphics_draw_text(center_x - text_width * 0.5f, 250.0f, help_text, 0xFF333333);
}
void about_update(void) {
    // Возврат в меню любой основной кнопкой
    if(input_pressed(PSP_CTRL_CROSS) || 
       input_pressed(PSP_CTRL_CIRCLE) || 
       input_pressed(PSP_CTRL_START) ||
       input_pressed(PSP_CTRL_TRIANGLE)) {
        g_game.state = STATE_MENU;
    }
}

void about_render(void) {
    // Отдельный фон для About экрана
    graphics_clear(ABOUT_BACKGROUND_COLOUR);
    
    // Рисуем bouncesplash.png в центре если загружена
    if (g_about_texture) {
        // Включаем текстурирование для PNG
        sceGuEnable(GU_TEXTURE_2D);
        sceGuEnable(GU_BLEND);
        sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
        
        sprite_rect_t full_sprite = png_create_sprite_rect(g_about_texture, 0, 0, 128, 128);
        float img_x = (480 - 128) / 2.0f;
        float img_y = (272 - 128) / 2.0f;
        png_draw_sprite(g_about_texture, &full_sprite, img_x, img_y, 128, 128);
        
        // Отключаем текстурирование для рендеринга текста
        sceGuDisable(GU_TEXTURE_2D);
    }
    
}

void menu_cleanup(void) {
    if (g_about_texture) {
        png_free_texture(g_about_texture);
        g_about_texture = NULL;
    }
}