#include "graphics.h"
#include "font8.h"
#include "types.h"  // Для SCREEN_WIDTH/SCREEN_HEIGHT
#include "png.h"    // Для texture_t
#include <pspgu.h>
#include <pspdisplay.h>
#include <pspkernel.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

// Используем константы из graphics.h для VRAM буферов
// (локальные #define заменены на глобальные константы)

// Размеры буферов (байты на пиксель)
#define FRAMEBUFFER_BPP 4  // GU_PSM_8888 = 4 байта на пиксель

// Увеличенный буфер команд GU для более сложной отрисовки
#define GU_CMD_LIST_SIZE (256 * 1024)  // 256KB буфер команд GU (защита от переполнения)
static char list[GU_CMD_LIST_SIZE] __attribute__((aligned(64)));


// VRAM буферы - вычисляются динамически
static void* draw_buffer;
static void* disp_buffer;

// Единое управление состоянием текстур
// ИНВАРИАНТ: кадр начинается в plain-режиме (текстуры выключены)
static int s_texturing_enabled = 0;

// Pause screenshot система  
static texture_t* g_pause_screenshot_texture = NULL;

// Sprite batching система (по образцу pspsdk/samples/gu/sprite)
#define MAX_SPRITES_PER_BATCH 128
typedef struct {
    float u, v;
    float x, y, z;
} BatchVertex;

typedef struct {
    BatchVertex vertices[MAX_SPRITES_PER_BATCH * 2]; // GU_SPRITES = 2 вершины на спрайт
    texture_t* current_texture;
    int count;
} SpriteBatch;

static SpriteBatch s_batch;

// Forward declarations
static void batch_init(void);

// Простые примитивы без текстур
typedef struct {
    short x, y, z;
} Vertex2D;

void graphics_init(void) {
    // Размеры буферов
    const size_t framebuffer_size = VRAM_BUFFER_WIDTH * VRAM_BUFFER_HEIGHT * FRAMEBUFFER_BPP;
    
    // Буферы как смещения в VRAM (не абсолютные адреса!)
    draw_buffer = (void*)0;                    // смещение 0
    disp_buffer = (void*)framebuffer_size;     // смещение после первого FB
    
    sceGuInit();

    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, draw_buffer, VRAM_BUFFER_WIDTH);
    sceGuDispBuffer(SCREEN_WIDTH, SCREEN_HEIGHT, disp_buffer, VRAM_BUFFER_WIDTH);
    // Depth buffer не выделяем - не нужен для 2D рендера

    sceGuOffset(2048 - (SCREEN_WIDTH / 2), 2048 - (SCREEN_HEIGHT / 2));
    sceGuViewport(2048, 2048, SCREEN_WIDTH, SCREEN_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuScissor(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    // Включаем альфа-блендинг внутри активного списка
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);

    // Очистить буферы перед показом (избежать мусора)
    // Цвет уже в ABGR формате, передаём напрямую
    sceGuClearColor(0);
    sceGuClear(GU_COLOR_BUFFER_BIT);
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
    
    // Инвариант: начинаем кадр в plain-режиме (текстуры выключены)
    s_texturing_enabled = 0;
    
    // Инициализация batch системы
    batch_init();
}

void graphics_start_frame(void) {
    sceGuStart(GU_DIRECT, list);
}

void graphics_clear(u32 color) {
    // Сбрасываем scissor на полный экран перед очисткой (безопасность)
    sceGuScissor(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    sceGuClearColor(color);
    sceGuClear(GU_COLOR_BUFFER_BIT);
}

void graphics_draw_rect(float x, float y, float w, float h, u32 color) {
    // Не трогаем GU_TEXTURE_2D / GU_BLEND — вариант B
    Vertex2D* v = (Vertex2D*)sceGuGetMemory(2 * sizeof(Vertex2D));

    v[0].x = (short)x;
    v[0].y = (short)y;
    v[0].z = 0;

    v[1].x = (short)(x + w);
    v[1].y = (short)(y + h);
    v[1].z = 0;

    // sceGuColor принимает цвет в том же ABGR формате что и graphics_clear()
    sceGuColor(color);
    sceGuDrawArray(GU_SPRITES, GU_VERTEX_16BIT | GU_TRANSFORM_2D, 2, 0, v);
}

void graphics_draw_char_scaled(float x, float y, uint8_t c, u32 color, float scale) {
    const Glyph8* glyph = font8_get_glyph(c);

    for (int row = 0; row < 8; row++) {
        for (int col = 0; col < glyph->width; col++) {
            if (glyph->row[row] & (1 << (7 - col))) {
                graphics_draw_rect(x + col * scale, y + row * scale, scale, scale, color);
            }
        }
    }
}

void graphics_draw_text_scaled(float x, float y, const char* text, u32 color, float scale) {
    if (!text) return;
    float cur_x = x;
    for (int i = 0; text[i] != '\0'; i++) {
        const Glyph8* glyph = font8_get_glyph((uint8_t)text[i]);
        graphics_draw_char_scaled(cur_x, y, (uint8_t)text[i], color, scale);
        cur_x += (glyph->width + FONT8_SPACING) * scale;
    }
}

void graphics_draw_text(float x, float y, const char* text, u32 color) {
    graphics_draw_text_scaled(x, y, text, color, 1.0f);
}

float graphics_measure_text(const char* text, float scale) {
    if (!text) return 0.0f;
    float width = 0.0f;
    for (int i = 0; text[i] != '\0'; i++) {
        const Glyph8* glyph = font8_get_glyph((uint8_t)text[i]);
        width += glyph->width * scale;
        // Добавить spacing только между символами (не после последнего)
        if (text[i + 1] != '\0') {
            width += FONT8_SPACING * scale;
        }
    }
    return width;
}

// Единое управление состоянием текстур
void graphics_set_texturing(int enabled) {
    if (enabled && !s_texturing_enabled) {
        sceGuEnable(GU_TEXTURE_2D);
        s_texturing_enabled = 1;
    } else if (!enabled && s_texturing_enabled) {
        sceGuDisable(GU_TEXTURE_2D);
        s_texturing_enabled = 0;
    }
}

void graphics_begin_plain(void) {
    graphics_flush_batch(); // Завершить накопленные спрайты перед переключением в plain
    graphics_set_texturing(0);
    // Блендинг уже включён в graphics_init(); ничего менять не нужно
}

void graphics_begin_textured(void) {
    graphics_set_texturing(1);                 // включает GU_TEXTURE_2D при необходимости
    sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA); // отключаем модуляцию цветом вершины
    sceGuColor(0xFFFFFFFF);                    // сброс цвета в белый (на случай локальных смен)
}

// Получить текущее состояние текстур (для оптимизации в level.c)
int graphics_get_texturing_state(void) {
    return s_texturing_enabled; // 0=plain, 1=textured
}

void graphics_end_frame(void) {
    graphics_flush_batch(); // Завершить все накопленные спрайты перед концом кадра
    sceGuFinish();
    sceGuSync(GU_SYNC_FINISH, GU_SYNC_WHAT_DONE);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

void graphics_shutdown(void) {
    graphics_flush_batch(); // Убедимся что все спрайты отрисованы перед завершением
    
    // Освободить текстуру снимка если выделена
    if (g_pause_screenshot_texture) {
        if (g_pause_screenshot_texture->data) free(g_pause_screenshot_texture->data);
        free(g_pause_screenshot_texture);
        g_pause_screenshot_texture = NULL;
    }
    
    sceGuDisplay(GU_FALSE);
    sceGuTerm();
}

// =================== SPRITE BATCHING СИСТЕМА ===================

// Инициализация batch системы
static void batch_init(void) {
    s_batch.current_texture = NULL;
    s_batch.count = 0;
}

// Отправить накопленные спрайты на рендер
void graphics_flush_batch(void) {
    if (s_batch.count <= 0) return;
    
    graphics_begin_textured(); // на случай, если режим был plain
    if (s_batch.current_texture) {
        graphics_bind_texture(s_batch.current_texture);
        // НЕ дублируем TexScale/Offset — они уже выставляются внутри graphics_bind_texture()
    }
    
    // «Железобезопасная» альтернатива - копируем в GE память
    const int vcount = s_batch.count * 2;
    BatchVertex* vtx = (BatchVertex*)sceGuGetMemory(vcount * sizeof(BatchVertex));
    if (!vtx) { 
        s_batch.count = 0; 
        return; 
    }
    memcpy(vtx, s_batch.vertices, vcount * sizeof(BatchVertex));
    
    // Отрисовать всю пачку одним вызовом
    sceGuDrawArray(GU_SPRITES, 
                   GU_TEXTURE_32BITF|GU_VERTEX_32BITF|GU_TRANSFORM_2D, 
                   vcount, 0, vtx);
    
    s_batch.count = 0; // Очистить batch для новых спрайтов
}

// Привязать текстуру для batch'а (flush если текстура изменилась)
void graphics_bind_texture(texture_t* tex) {
    if (!tex) return;
    
    // Если текстура изменилась - flush накопленные спрайты
    if (s_batch.current_texture != tex) {
        graphics_flush_batch();
        
        s_batch.current_texture = tex;
        
        // Привязать новую текстуру (как в pspsdk/samples/gu/sprite)
        sceGuTexMode(tex->format, 0, 0, 0);
        sceGuTexImage(0, tex->width, tex->height, tex->width, tex->data);
        sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA);
        sceGuTexFilter(GU_NEAREST, GU_NEAREST);
        sceGuTexWrap(GU_CLAMP, GU_CLAMP);
        
        // Исправляем масштаб UV для реального железа PSP
        // Мы подаем UV в пикселях, нужно нормализовать
        sceGuTexScale(1.0f / tex->width, 1.0f / tex->height);
        sceGuTexOffset(0.0f, 0.0f);
    }
}

// Добавить спрайт в batch (не отрисовывает сразу!)
void graphics_batch_sprite(float u1, float v1, float u2, float v2, 
                          float x, float y, float w, float h) {
    // Flush если batch переполнен
    if (s_batch.count >= MAX_SPRITES_PER_BATCH) {
        graphics_flush_batch();
    }
    
    int idx = s_batch.count * 2; // 2 вершины на спрайт
    
    // Первая вершина (левый верхний угол)
    s_batch.vertices[idx].u = u1;
    s_batch.vertices[idx].v = v1;
    s_batch.vertices[idx].x = x;
    s_batch.vertices[idx].y = y;
    s_batch.vertices[idx].z = 0.0f;
    
    // Вторая вершина (правый нижний угол)
    s_batch.vertices[idx + 1].u = u2;
    s_batch.vertices[idx + 1].v = v2;
    s_batch.vertices[idx + 1].x = x + w;
    s_batch.vertices[idx + 1].y = y + h;
    s_batch.vertices[idx + 1].z = 0.0f;
    
    s_batch.count++;
}

// =================== PAUSE SCREENSHOT СИСТЕМА ===================

// Сохранить текущий кадр как текстуру для паузы
void graphics_take_pause_screenshot(void) {
    // Освободить старую текстуру если есть
    if (g_pause_screenshot_texture) {
        if (g_pause_screenshot_texture->data) free(g_pause_screenshot_texture->data);
        free(g_pause_screenshot_texture);
        g_pause_screenshot_texture = NULL;
    }
    
    // Получить реальный активный буфер от дисплея
    void* framebuf_addr;
    int buffer_width;
    int pixel_format;
    sceDisplayGetFrameBuf(&framebuf_addr, &buffer_width, &pixel_format, 0);
    
    // Создать новую текстуру
    g_pause_screenshot_texture = (texture_t*)malloc(sizeof(texture_t));
    if (!g_pause_screenshot_texture) return;
    
    // PSP требует размеры текстур степенью двойки
    int tex_width = 512;  // ближайшая степень 2 больше 480
    int tex_height = 512; // ближайшая степень 2 больше 272
    
    // Выделить данные для текстуры под правильный размер
    g_pause_screenshot_texture->data = malloc(tex_width * tex_height * 4);
    if (!g_pause_screenshot_texture->data) {
        free(g_pause_screenshot_texture);
        g_pause_screenshot_texture = NULL;
        return;
    }
    
    // Настроить параметры текстуры
    g_pause_screenshot_texture->width = tex_width;
    g_pause_screenshot_texture->height = tex_height;
    g_pause_screenshot_texture->format = GU_PSM_8888;
    
    // Очистить текстуру черным цветом
    u32* dst = (u32*)g_pause_screenshot_texture->data;
    for (int i = 0; i < tex_width * tex_height; i++) {
        dst[i] = 0xFF000000; // черный с альфой
    }
    
    if (pixel_format == PSP_DISPLAY_PIXEL_FORMAT_8888) {
        // 32-битный framebuffer - прямое копирование
        u32* src = (u32*)framebuf_addr;
        for (int y = 0; y < SCREEN_HEIGHT; y++) {
            for (int x = 0; x < SCREEN_WIDTH; x++) {
                dst[y * tex_width + x] = src[y * buffer_width + x]; // используем tex_width вместо SCREEN_WIDTH
            }
        }
    } else if (pixel_format == PSP_DISPLAY_PIXEL_FORMAT_565) {
        // 16-битный framebuffer - конвертировать в 32-бит
        u16* src = (u16*)framebuf_addr;
        for (int y = 0; y < SCREEN_HEIGHT; y++) {
            for (int x = 0; x < SCREEN_WIDTH; x++) {
                u16 p = src[y * buffer_width + x];
                // Конвертация RGB565 в RGBA8888
                u8 r = (p >> 11) << 3;
                u8 g = ((p >> 5) & 0x3F) << 2;
                u8 b = (p & 0x1F) << 3;
                dst[y * tex_width + x] = 0xFF000000 | (r << 16) | (g << 8) | b; // используем tex_width
            }
        }
    }
    
    // Обеспечить видимость CPU-записей для GPU
    sceKernelDcacheWritebackRange(g_pause_screenshot_texture->data, tex_width * tex_height * 4);
}

// Отрисовать сохранённый снимок как текстуру
void graphics_draw_pause_screenshot(void) {
    if (!g_pause_screenshot_texture) return;
    
    // Переключиться в текстурный режим (как в about_render)
    graphics_begin_textured();
    
    // Создать sprite_rect для части текстуры 480x272 из 512x512
    sprite_rect_t screen_sprite = png_create_sprite_rect(g_pause_screenshot_texture, 
                                                        0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    
    // Отрисовать на весь экран 
    png_draw_sprite(g_pause_screenshot_texture, &screen_sprite, 
                   0.0f, 0.0f, (float)SCREEN_WIDTH, (float)SCREEN_HEIGHT);
}

// Отладочная визуализация коллизий колец (повторяет логику из physics.c thinCollide)  
void graphics_debug_draw_hoop_collision(int worldTileX, int worldTileY, int tileID) {
    #define TILE_SIZE 12
    
    // Переключиться в plain режим для рисования прямоугольников
    graphics_begin_plain();
    
    // Базовые координаты тайла в мировых координатах
    int tilePixelX = worldTileX * TILE_SIZE;
    int tilePixelY = worldTileY * TILE_SIZE;
    int tileRight = tilePixelX + TILE_SIZE;
    int tileBottom = tilePixelY + TILE_SIZE;
    
    // Применяем ту же логику что и в physics.c:hoopCollide()
    switch (tileID) {
        // Маленькие вертикальные кольца (Java case 13, 17)
        case 13: case 17:
            tilePixelX += 6;
            tileRight -= 6;  
            tileBottom -= 11; // m -= 11
            break;
            
        // Маленькие вертикальные кольца - нижняя часть (Java case 14, 18)
        case 14: case 18:
            tilePixelX += 6;
            tileRight -= 6;
            tilePixelY += 11; // j += 11 как в оригинальном Java
            break;
            
        // Маленькие горизонтальные кольца - левая часть (Java case 15, 19)
        case 15: case 19:
            tilePixelY += 6;  // j += 6
            tileRight -= 6;   // m -= 6  
            tileBottom -= 11; // k -= 11
            break;
            
        // Маленькие горизонтальные кольца - правая часть (Java case 16, 20)
        case 16: case 20:
            tilePixelY += 6;  // j += 6
            tileRight -= 6;   // m -= 6
            tilePixelX += 11; // i += 11
            break;
            
        // Большие кольца (21-24) - такая же логика но без блокировки большого мяча
        case 21: case 25:
            tilePixelX += 6;
            tileRight -= 6;  
            tileBottom -= 11;
            break;
        case 22: case 26:
            tilePixelX += 6;
            tileRight -= 6;
            tilePixelY += 11;
            break;
        case 23: case 27:
            tilePixelY += 6;
            tileRight -= 6;   
            tileBottom -= 11;
            break;
        case 24: case 28:
            tilePixelY += 6;
            tileRight -= 6;
            tilePixelX += 11;
            break;
            
        default:
            return; // Неподдерживаемый тайл
    }
    
    // Рисуем полупрозрачный красный прямоугольник области коллизии
    int width = tileRight - tilePixelX;
    int height = tileBottom - tilePixelY;
    
    // Цвет: полупрозрачный красный (ABGR формат: 0x80FF0000 = A=128, B=0, G=0, R=255)
    graphics_draw_rect((float)tilePixelX, (float)tilePixelY, (float)width, (float)height, 0x80FF0000);
}

