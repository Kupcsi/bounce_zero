#ifndef TYPES_H
#define TYPES_H

#include <psptypes.h>
#include "tile_table.h"

#ifdef __cplusplus
extern "C" {
#endif

// Состояния игры
typedef enum {
    STATE_MENU,
    STATE_LEVEL_SELECT,  // Выбор уровня
    STATE_GAME,
    STATE_ABOUT,
    STATE_EXIT
} GameState;

// Размеры спрайтов (в пикселях, из BounceConst.java)
#define NORMAL_SIZE 12      // Обычный размер мяча
#define HALF_NORMAL_SIZE 6
#define ENLARGED_SIZE 16    // Увеличенный размер мяча
#define HALF_ENLARGED_SIZE 8
#define POPPED_SIZE 12      // Размер лопнувшего мяча (совпадает с обычным по дизайну)
#define HALF_POPPED_SIZE 6

// Состояния размера мяча
#define SMALL_SIZE_STATE 0    // использует NORMAL_SIZE (12 пикселей)
#define LARGE_SIZE_STATE 1    // использует ENLARGED_SIZE (16 пикселей)

// Состояния мяча
#define BALL_STATE_NORMAL 0   // Обычное состояние
#define BALL_STATE_DEAD 1     // Мяч уничтожен (нужно респавнить)
#define BALL_STATE_POPPED 2   // Мяч лопнул (временное состояние)

// Битовые флаги направления движения (из BounceConst.java)
#define MOVE_UP 8      // Прыжок/движение вверх
#define MOVE_DOWN 4    // Движение вниз
#define MOVE_RIGHT 2   // Движение вправо
#define MOVE_LEFT 1    // Движение влево

// Размеры игрового поля
#define SCREEN_WIDTH 480
#define SCREEN_HEIGHT 272

// Структура игрока (адаптированная из Ball.java)
typedef struct {
    // Позиция в экранных координатах (пиксели)
    int xPos, yPos;
    
    // Скорость в единицах x0.1 пикселя/кадр для точности расчетов
    int xSpeed, ySpeed;
    
    // Битовые флаги направления движения (комбинация MOVE_*)
    int direction;
    
    // Размер спрайта мяча в пикселях (12 или 16)
    int ballSize;
    int mHalfBallSize;        // Половина размера для расчета коллизий
    
    // Смещение спрайта при прыжке для анимационного эффекта
    int jumpOffset;
    
    // Состояние мяча (BALL_STATE_*)
    int ballState;
    // Размер мяча (SMALL_SIZE_STATE или LARGE_SIZE_STATE)
    int sizeState;
    
    // Флаги физического состояния
    int mGroundedFlag;        // 1 если мяч касается земли/платформы
    int mCDRubberFlag;        // 1 если коллизия с резиновой поверхностью
    int mCDRampFlag;          // 1 если коллизия с наклонной поверхностью
    
    // Счетчики временных эффектов (в кадрах)
    int speedBonusCntr;       // Остаток времени бонуса скорости
    int gravBonusCntr;        // Остаток времени бонуса гравитации  
    int jumpBonusCntr;        // Остаток времени бонуса прыжка
    
    // Счетчик скольжения по поверхности
    int slideCntr;
    
    // Флаг нахождения в воде (тайл с флагом 0x40)
    int isInWater;
} Player;

// Глобальное состояние игры
typedef struct {
    GameState state;          // Текущее состояние игры
    int menu_selection;       // Выбранный пункт меню
    int selected_level;       // Выбранный уровень (1-11)
    Player player;            // Состояние игрока
    
    // Буфер нажатий прыжка между тиками физики
    // Хранится в Game, а не в Player, для разделения ввода и физики
    int buffered_jump;
} Game;

extern Game g_game;

// Функции физики игрока (реализованы в отдельном файле физики)
void player_init(Player* p, int x, int y, int sizeState);
void player_update(Player* p);
int check_collision_at(Player* p, int x, int y);
void set_direction(Player* p, int dir);
void release_direction(Player* p, int dir);

// Функции изменения размера мяча (для будущих бонусов)
void enlarge_ball(Player* p);
void shrink_ball(Player* p);
void pop_ball(Player* p);

#ifdef __cplusplus
}
#endif

#endif