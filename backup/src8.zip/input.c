#include "input.h"
#include <string.h>

static SceCtrlData pad;
static SceCtrlData old_pad;

void input_init(void) {
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    
    // Явная инициализация структур для читаемости кода
    memset(&pad, 0, sizeof(pad));
    memset(&old_pad, 0, sizeof(old_pad));
}

void input_update(void) {
    old_pad = pad;
    
    // Обработка ошибок чтения контроллера для предотвращения залипания кнопок
    if (sceCtrlReadBufferPositive(&pad, 1) < 0) {
        pad = old_pad; // сохранить предыдущее состояние при ошибке
    }
}

int input_pressed(int button) {
    return (pad.Buttons & button) && !(old_pad.Buttons & button);
}

int input_held(int button) {
    return (pad.Buttons & button);
}