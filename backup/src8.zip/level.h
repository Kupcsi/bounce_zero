// level.h - Парсер оригинальных уровней Bounce
#ifndef LEVEL_H
#define LEVEL_H

#include <psptypes.h>
#include "tile_table.h"
#include "png.h"  // Включаем png.h для полного определения texture_t

// Константы тайлов (из оригинального TileCanvas.java)

/* --- Tile flags --- */
#ifndef TILE_FLAG_VARIANT
// Ring foreground control (for proper draw order)
void level_set_ring_fg_defer(int on);
void level_flush_ring_foreground(void);

#endif
#ifndef TILE_FLAG_DIRTY
#endif

/* --- Background colors for ramp tiles (temporary placeholders).
   TODO: заменить на точные значения из Java (11591920 и 1073328) --- */
#ifndef TILE_LIGHT_BG
#endif
#ifndef TILE_DARK_BG
#endif

// Кольца для сбора (13-28 в оригинале)

// Размеры
#define MAX_LEVEL_WIDTH 255
#define MAX_LEVEL_HEIGHT 255

// Структура уровня
typedef struct {
    int width;              // Ширина карты в тайлах
    int height;             // Высота карты в тайлах
    int startPosX;          // Стартовая позиция игрока X (в пикселях)
    int startPosY;          // Стартовая позиция игрока Y (в пикселях)
    int ballSize;           // Размер мяча (0=маленький, 1=большой)
    int exitPosX;           // Позиция выхода X (в тайлах)
    int exitPosY;           // Позиция выхода Y (в тайлах)
    int totalRings;         // Общее количество колец для сбора
    
    // Карта тайлов
    short tileMap[MAX_LEVEL_HEIGHT][MAX_LEVEL_WIDTH];
} Level;

// Глобальный уровень
extern Level g_level;

// Глобальные переменные для атласа (используются в game.c)
extern texture_t* g_tileset;
extern int g_tiles_per_row;

// Функции
int level_load_from_memory(const char* levelData, int dataSize);
int level_load_from_file(const char* filename);
int level_load_by_number(int levelNumber);
int level_create_test_level(void);
int level_get_tile_at(int tileX, int tileY);
int level_is_tile_solid(int tile);
int level_check_collision_at_pixel(int pixelX, int pixelY, int width, int height);
void level_render_visible_area(int cameraX, int cameraY, int screenWidth, int screenHeight);

// PNG тест
void level_test_png_rendering(void);

#endif