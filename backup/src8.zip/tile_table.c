#include "tile_table.h"

// Константы для нормалей поверхностей в Q15
static const q15_t Q15_NEG_ONE = -32767, Q15_ZERO = 0, Q15_INV_SQRT2 = 23170;

// Макросы для нормалей
#define N_NONE Q15_ZERO, Q15_ZERO
#define N_SOLID Q15_ZERO, Q15_NEG_ONE
#define N_BR Q15_INV_SQRT2, -Q15_INV_SQRT2
#define N_BL -Q15_INV_SQRT2, -Q15_INV_SQRT2
#define N_TR Q15_INV_SQRT2, Q15_INV_SQRT2
#define N_TL -Q15_INV_SQRT2, Q15_INV_SQRT2

// ПРАВИЛЬНАЯ таблица тайлов на основе точного анализа Java кода
__attribute__((aligned(64)))
static const TileMeta TILE_DB[67] = {
    /* 00 EMPTY - пустой тайл, фон заливается цветом */
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 01 BLOCK - tileImages[0] = extractImage(image, 1, 0) = атлас[1] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 1, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 02 RUBBER_BLOCK - tileImages[1] = extractImage(image, 1, 2) = атлас[9] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 9, TF_NONE, LOGIC_RUBBER, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 03 SPIKES - Java case 3: bool ? tileImages[6] : tileImages[2]
       Оба из extractImageBG(image, 0, 3, цвет) = позиция (0,3) = атлас[12]
       Без трансформаций - просто базовый спрайт факел */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 12, TF_NONE, LOGIC_HAZARD, SPECIAL_FLAG_0x40, 12 , TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 04 SPIKES - tileImages[4] = manipulateImage(tileImages[2], 3) = атлас[12] + ROT_90 */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 12, TF_ROT_90, LOGIC_HAZARD, SPECIAL_FLAG_0x40, 12 , TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 05 SPIKES - tileImages[5] = manipulateImage(tileImages[2], 5) = атлас[12] + ROT_270 */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 12, TF_ROT_270, LOGIC_HAZARD, SPECIAL_FLAG_0x40, 12 , TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 06 SPIKES - tileImages[2] = extractImageBG(image, 0, 3, светлый) = атлас[12] без трансформации */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 12, TF_NONE, LOGIC_HAZARD, SPECIAL_FLAG_0x40, 12 , TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 07 CHECKPOINT - tileImages[10] = extractImage(image, 0, 4) = атлас[16] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 16, TF_NONE, LOGIC_RING, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 08 BLOCK - tileImages[11] = extractImage(image, 3, 4) = атлас[19] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 19, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 09 EXIT - составной тайл из tileImages[12] = createExitImage(атлас[14]) */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 14, TF_NONE, LOGIC_EXIT, SPECIAL_COMPOSITE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 10 MOVING_SPIKES - составной из tileImages[46] = атлас[13] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 13, TF_NONE, LOGIC_HAZARD, SPECIAL_COMPOSITE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 11-12 - неиспользуемые слоты */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 13 RING - Java: фон tileImages[35] = manipulateImage(tileImages[33], 0) = (ROT_270)+FLIP_X, переднее tileImages[33] = manipulateImage(tileImages[18], 5) = ROT_270 */
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 21, TF_ROT_270_FLIP_X, 21, TF_ROT_270 },
    /* 14 RING - Java: фон tileImages[36] = manipulateImage(tileImages[34], 0) = (ROT_270+FLIP_Y)+FLIP_X, переднее tileImages[34] = manipulateImage(tileImages[33], 1) = (ROT_270)+FLIP_Y */
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 21, TF_ROT_270_FLIP_XY, 21, TF_ROT_270_FLIP_X },
    /* 15 RING - тайл 15 в Java: фон tileImages[17] (атлас[21]+FLIP_Y), переднее tileImages[18] (атлас[21]) */
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 21, TF_FLIP_Y, 21, TF_NONE },
    /* 16 RING - тайл 16 в Java: фон tileImages[19] (атлас[21]+FLIP_XY), переднее tileImages[20] (атлас[21]+FLIP_X) */
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 21, TF_FLIP_XY, 21, TF_FLIP_X },
    // Тайл 17: фон tileImages[43] (атлас[23]+FLIP_XY), переднее tileImages[41] (атлас[23]+ROT_270) 
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 23, TF_FLIP_XY, 23, TF_ROT_270 },
    // Тайл 18: фон tileImages[44] (атлас[23]+FLIP_X), переднее tileImages[42] (атлас[23]+ROT_270+FLIP_Y)
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 23, TF_FLIP_X, 23, TF_ROT_270 },
    // Тайл 19: фон tileImages[25] (атлас[23]+FLIP_Y), переднее tileImages[26] (атлас[23])
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 23, TF_FLIP_Y, 23, TF_NONE },
    // Тайл 20: фон tileImages[27] (атлас[23]+FLIP_XY), переднее tileImages[28] (атлас[23]+FLIP_X)
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 23, TF_FLIP_XY, 23, TF_FLIP_X },
    // Тайл 21: фон tileImages[31] (атлас[20]+FLIP_XY), переднее tileImages[29] (атлас[20]+ROT_270) 
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 20, TF_FLIP_XY, 20, TF_ROT_270 },
    // Тайл 22: фон tileImages[32] (атлас[20]+FLIP_X), переднее tileImages[30] (атлас[20]+ROT_270+FLIP_Y)
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 20, TF_FLIP_X, 20, TF_ROT_270 },
    // Тайл 23: фон tileImages[13] (атлас[20]+FLIP_Y), переднее tileImages[14] (атлас[20])
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 20, TF_FLIP_Y, 20, TF_NONE },
    // Тайл 24: фон tileImages[15] (атлас[20]+FLIP_XY), переднее tileImages[16] (атлас[20]+FLIP_X)
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 20, TF_FLIP_XY, 20, TF_FLIP_X },
    // Тайл 25: фон tileImages[39] (атлас[22]+FLIP_XY), переднее tileImages[37] (атлас[22]+FLIP_X)
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 22, TF_FLIP_XY, 22, TF_FLIP_X },
    // Тайл 26: фон tileImages[40] (атлас[22]+ROT_180), переднее tileImages[38] (атлас[22]+FLIP_Y)
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 22, TF_ROT_180, 22, TF_FLIP_Y },
    // Тайл 27: фон tileImages[21] (атлас[22]+FLIP_Y), переднее tileImages[22] (атлас[22])
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 22, TF_FLIP_Y, 22, TF_NONE },
    // Тайл 28: фон tileImages[23] (атлас[22]+FLIP_XY), переднее tileImages[24] (атлас[22]+FLIP_X)
    { TILETYPE_EMPTY, ORIENT_NONE, MASK_NONE, N_NONE, 255, TF_NONE, LOGIC_RING, SPECIAL_QUAD_RING, 0, TF_NONE, 22, TF_FLIP_XY, 22, TF_FLIP_X },   
    
    /* 29 - тайл 29 в Java: tileImages[45] = extractImage(image, 3, 3) = атлас[15] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 15, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 30-37 RAMPS - рампы с флагом 0x40 для переключения каменная(0)/резиновая(8) */
    /* 30 RAMP_FLOOR_TL - Java: bool ? tileImages[61] : tileImages[57] 
       tileImages[57] = manipulateImage(tileImages[55], 4) = ROT_180
       tileImages[55] = extractImageBG(image, 0, 0, светлый) = атлас[0] */
    { TILETYPE_RAMP_FLOOR, ORIENT_TL, MASK_TRI, N_TL, 0, TF_ROT_180, LOGIC_NONE, SPECIAL_FLAG_0x40, 8 , TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 31 RAMP_FLOOR_TR - Java: bool ? tileImages[60] : tileImages[56] */
    { TILETYPE_RAMP_FLOOR, ORIENT_TR, MASK_TRI, N_TR, 0, TF_ROT_270, LOGIC_NONE, SPECIAL_FLAG_0x40, 8 , TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 32 RAMP_FLOOR_BR - Java: bool ? tileImages[59] : tileImages[55] */
    { TILETYPE_RAMP_FLOOR, ORIENT_BR, MASK_TRI, N_BR, 0, TF_NONE, LOGIC_NONE, SPECIAL_FLAG_0x40, 8 , TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 33 RAMP_FLOOR_BL - Java: bool ? tileImages[62] : tileImages[58] */
    { TILETYPE_RAMP_FLOOR, ORIENT_BL, MASK_TRI, N_BL, 0, TF_ROT_90, LOGIC_NONE, SPECIAL_FLAG_0x40, 8 , TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 34-37 RAMP_CEIL - рампы потолок (резиновые, базовый спрайт 8) */
    { TILETYPE_RAMP_CEIL, ORIENT_TL, MASK_TRI, N_TL, 8, TF_ROT_180, LOGIC_RUBBER, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_RAMP_CEIL, ORIENT_TR, MASK_TRI, N_TR, 8, TF_ROT_270, LOGIC_RUBBER, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_RAMP_CEIL, ORIENT_BR, MASK_TRI, N_BR, 8, TF_NONE, LOGIC_RUBBER, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_RAMP_CEIL, ORIENT_BL, MASK_TRI, N_BL, 8, TF_ROT_90, LOGIC_RUBBER, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 38 - декоративный */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_FLIP_X, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 39-42 SHRINK_TILE - tileImages[50] = extractImage(image, 3, 1) = атлас[7] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 7, TF_NONE, LOGIC_SHRINK, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 7, TF_ROT_90, LOGIC_SHRINK, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 7, TF_ROT_180, LOGIC_SHRINK, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 7, TF_ROT_270, LOGIC_SHRINK, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 43-46 GROW_TILE - tileImages[51] = extractImage(image, 2, 4) = атлас[18] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 18, TF_NONE, LOGIC_GROW, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 18, TF_ROT_90, LOGIC_GROW, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 18, TF_ROT_180, LOGIC_GROW, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 18, TF_ROT_270, LOGIC_GROW, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },

    /* 47-54 - декоративные тайлы из tileImages[52,53,54] */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },     // [52]
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_ROT_90, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_ROT_180, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },  
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 11, TF_ROT_270, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },  
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_ROT_90, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },    // [53] 
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_ROT_180, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 5, TF_ROT_270, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },   
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 10, TF_ROT_90, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },   // [54]

    /* 55-66 - заполнители/неиспользуемые */
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE },
    { TILETYPE_SOLID, ORIENT_NONE, MASK_NONE, N_SOLID, 255, TF_NONE, LOGIC_NONE, SPECIAL_NONE, 0, TF_NONE, 0, TF_NONE, 0, TF_NONE }
};

// Функции доступа
const TileMeta* tile_meta_db(void) {
    return TILE_DB;
}

uint32_t tile_meta_count(void) {
    return 67;
}

int tile_meta_has_unspecified(void) {
    return 0;
}

// Вспомогательные функции
const char* tile_transform_name(TileTransform transform) {
    switch (transform) {
        case TF_NONE: return "NONE";
        case TF_FLIP_X: return "FLIP_X";
        case TF_FLIP_Y: return "FLIP_Y";
        case TF_FLIP_XY: return "FLIP_XY";
        case TF_ROT_90: return "ROT_90";
        case TF_ROT_180: return "ROT_180";
        case TF_ROT_270: return "ROT_270";
        default: return "UNKNOWN";
    }
}

int tile_needs_alt_sprite(const TileMeta* tile, int tile_flags) {
    return (tile->special_flags & SPECIAL_FLAG_0x40) && (tile_flags & 0x40);
};
