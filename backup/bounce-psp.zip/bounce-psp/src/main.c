#include <pspkernel.h>
#include <pspgu.h>
#include <pspdisplay.h>
#include <pspctrl.h>
#include <pspaudiolib.h>
#include <pspaudio.h>
#include <pspdebug.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>  // ДОБАВЛЕНО: для malloc/free

#include "fs.h"
#include "bounce_const.h"
#include "png.h"
#include "tile_canvas.h"
#include "level.h"

PSP_MODULE_INFO("shape", 0, 1, 0);
PSP_MAIN_THREAD_ATTR(THREAD_ATTR_VFPU | THREAD_ATTR_USER);

/* Экран (используем константы из bounce_const.h) */
#ifndef BUFFER_WIDTH
#define BUFFER_WIDTH PSP_BUFFER_WIDTH
#endif
#ifndef BUFFER_HEIGHT
#define BUFFER_HEIGHT SCREEN_HEIGHT
#endif

#define RECT_WIDTH   34
#define RECT_HEIGHT  64

static char list[0x20000] __attribute__((aligned(64)));
static int running = 0;

/* ======== DISPLAY MODES ======== */
typedef enum {
    MODE_GAME = 0,        // Обычная игра/тест тайлов
    MODE_DEBUG_INFO = 1,  // Отладочная информация FS
    MODE_LEVEL_TEST = 2   // Тест загрузки уровней D1
} DisplayMode;

static DisplayMode display_mode = MODE_GAME;
static DisplayMode prev_display_mode = MODE_GAME;

/* ======== AUDIO ======== */
#define AUDIO_SAMPLE_RATE 44100
#define AUDIO_SAMPLES     1024

static int   audio_playing = 0;
static float tone_freq = 0.0f;
static int   tone_samples_left = 0;
static float tone_phase = 0.0f;

static void audio_callback(void *buf, unsigned int reqn, void *pdata) {
    short *output = (short*)buf;
    unsigned int produced = 0;
    if (!audio_playing || tone_samples_left <= 0) {
        for (unsigned int i = 0; i < reqn * 2; ++i) output[i] = 0;
        if (tone_samples_left <= 0) audio_playing = 0;
        return;
    }
    for (produced = 0; produced < reqn && tone_samples_left > 0; ++produced) {
        short s = (short)(sinf(tone_phase) * 16000.0f);
        output[produced * 2 + 0] = s;
        output[produced * 2 + 1] = s;
        tone_phase += 2.0f * (float)M_PI * tone_freq / (float)AUDIO_SAMPLE_RATE;
        if (tone_phase >= 2.0f * (float)M_PI) tone_phase -= 2.0f * (float)M_PI;
        --tone_samples_left;
    }
    for (unsigned int i = produced * 2; i < reqn * 2; ++i) output[i] = 0;
}

static void initAudio(void) {
    pspAudioInit();
    pspAudioSetChannelCallback(0, audio_callback, NULL);
}

static void playTone(float freq_hz, int duration_ms) {
    tone_freq = freq_hz;
    tone_samples_left = (AUDIO_SAMPLE_RATE * duration_ms) / 1000;
    tone_phase = 0.0f;
    audio_playing = 1;
}

static void endAudio(void) {
    pspAudioEnd();
}

/* ======== BASIC DRAWING ======== */
typedef struct { short x, y, z; } Vertex;
static void drawRect(float x, float y, float w, float h) {
    Vertex* v = (Vertex*)sceGuGetMemory(2 * sizeof(Vertex));
    v[0].x = (short)x;       v[0].y = (short)y;       v[0].z = 0;
    v[1].x = (short)(x + w); v[1].y = (short)(y + h); v[1].z = 0;
    sceGuDrawArray(GU_SPRITES, GU_VERTEX_16BIT | GU_TRANSFORM_2D, 2, 0, v);
}

/* ======== EXIT CALLBACKS ======== */
static int exit_callback(int, int, void*) { running = 0; return 0; }
static int callback_thread(SceSize, void*) {
    int cbid = sceKernelCreateCallback("Exit Callback", exit_callback, NULL);
    sceKernelRegisterExitCallback(cbid);
    sceKernelSleepThreadCB();
    return 0;
}
static int setup_callbacks(void) {
    int thid = sceKernelCreateThread("update_thread", callback_thread, 0x11, 0xFA0, 0, 0);
    if (thid >= 0) sceKernelStartThread(thid, 0, 0);
    return thid;
}

/* ======== FS TEST ======== */
typedef struct {
    int icons_found;
    int levels_found;
    int icon_size;
    int level_size;
    int png_valid;
    int c5_level_created;
} fs_test_results_t;
static fs_test_results_t fs_results = {0};

static void testFileSystem(void) {
    printf("\n=== A5 File System Test ===\n");
    fs_results.icons_found  = res_exists("/icons/objects_nm.png");
    fs_results.levels_found = res_exists("/levels/J2MElvl.001");

    res_handle_t icon_file = res_open("/icons/objects_nm.png");
    if (icon_file >= 0) {
        fs_results.icon_size = res_size(icon_file);
        printf("Icon file size: %d bytes\n", fs_results.icon_size);
        unsigned char header[16];
        int n = res_read(icon_file, header, sizeof(header));
        if (n > 0) {
            printf("First %d bytes (hex): ", n);
            for (int i = 0; i < n; ++i) printf("%02X ", header[i]);
            printf("\n");
            if (n >= 8 &&
                header[0] == 0x89 && header[1] == 0x50 && header[2] == 0x4E && header[3] == 0x47 &&
                header[4] == 0x0D && header[5] == 0x0A && header[6] == 0x1A && header[7] == 0x0A) {
                printf("✓ Valid PNG signature detected!\n");
                fs_results.png_valid = 1;
            } else {
                printf("✗ Not a valid PNG file\n");
                fs_results.png_valid = 0;
            }
        }
        res_close(icon_file);
    }

    res_handle_t level_file = res_open("/levels/J2MElvl.001");
    if (level_file >= 0) {
        fs_results.level_size = res_size(level_file);
        printf("Level file size: %d bytes\n", fs_results.level_size);
        unsigned char header[16];
        int n = res_read(level_file, header, sizeof(header));
        if (n > 0) {
            printf("First %d bytes (hex): ", n);
            for (int i = 0; i < n; ++i) printf("%02X ", header[i]);
            printf("\n");
        }
        res_close(level_file);
    }

    printf("=== A5 Test Complete ===\n\n");
}

/* ======== C5 TEST: Level rendering ======== */
static int** test_level = NULL;
static int test_level_width = 0;
static int test_level_height = 0;
static int simulated_ball_x = 6;

static void initTestLevel(void) {
    test_level = tc_create_test_level(&test_level_width, &test_level_height);
    if (test_level) {
        printf("C5 Test: Created level %dx%d\n", test_level_width, test_level_height);
        fs_results.c5_level_created = 1;
    } else {
        printf("C5 Test: Failed to create level\n");
        fs_results.c5_level_created = 0;
    }
}

static void cleanupTestLevel(void) {
    if (test_level) {
        tc_free_test_level(test_level, test_level_height);
        test_level = NULL;
    }
}

/* ======== D1 TEST: Real level loading ======== */
static Level* real_level = NULL;
static int current_level_num = 1;
static char level_status[512] = {0};
static int level_load_success = 0;

static void initRealLevel(void) {
    real_level = level_create();
    if (!real_level) {
        printf("D1 Test: Failed to create level structure\n");
        return;
    }
    printf("D1 Test: Level structure created\n");
}

static void loadRealLevel(int level_num) {
    if (!real_level) {
        snprintf(level_status, sizeof(level_status), "ERROR: Level structure not initialized");
        level_load_success = 0;
        return;
    }
    
    printf("D1 Test: Loading level %d\n", level_num);
    int result = level_load_from_file(real_level, level_num);
    
    if (result == LEVEL_OK) {
        level_get_debug_stats(real_level, level_status);
        level_load_success = 1;
        current_level_num = level_num;
        printf("D1 Test: Successfully loaded level %d\n", level_num);
    } else {
        snprintf(level_status, sizeof(level_status), 
                "FAILED to load level %d (error %d)", level_num, result);
        level_load_success = 0;
        printf("D1 Test: Failed to load level %d (error %d)\n", level_num, result);
    }
}

static void cleanupRealLevel(void) {
    if (real_level) {
        level_destroy(real_level);
        real_level = NULL;
    }
}

/* ======== DISPLAY FUNCTIONS ======== */
static void drawDebugInfo(void) {
    pspDebugScreenSetXY(2, 2);
    pspDebugScreenPrintf("=== DEBUG INFO (Mode 1/3) ===");
    pspDebugScreenSetXY(2, 4);
    pspDebugScreenPrintf("Icons found: %s",   fs_results.icons_found ? "YES" : "NO");
    pspDebugScreenSetXY(2, 5);
    pspDebugScreenPrintf("Levels found: %s",  fs_results.levels_found ? "YES" : "NO");
    if (fs_results.icon_size > 0) {
        pspDebugScreenSetXY(2, 6);
        pspDebugScreenPrintf("Icon size: %d bytes", fs_results.icon_size);
        pspDebugScreenSetXY(2, 7);
        pspDebugScreenPrintf("PNG valid: %s", fs_results.png_valid ? "YES" : "NO");
    }
    if (fs_results.level_size > 0) {
        pspDebugScreenSetXY(2, 8);
        pspDebugScreenPrintf("Level size: %d bytes", fs_results.level_size);
    }
    
    // C5 тест результаты
    pspDebugScreenSetXY(2, 9);
    pspDebugScreenPrintf("C5 Level: %s", fs_results.c5_level_created ? "CREATED" : "FAILED");
    if (test_level) {
        pspDebugScreenSetXY(2, 10);
        pspDebugScreenPrintf("Level size: %dx%d tiles", test_level_width, test_level_height);
        
        int camera_x = tc_camera_follow_ball(simulated_ball_x, test_level_width);
        int ball_screen_x = (simulated_ball_x - camera_x) * TILE_SIZE + TILE_SIZE/2;
        
        pspDebugScreenSetXY(2, 11);
        pspDebugScreenPrintf("Ball: world=%d cam=%d screen=%d", simulated_ball_x, camera_x, ball_screen_x);
    }
    
    pspDebugScreenSetXY(2, 13);
    pspDebugScreenPrintf("Controls:");
    pspDebugScreenSetXY(2, 14);
    pspDebugScreenPrintf("SELECT: Next mode (1->2->0)");
    pspDebugScreenSetXY(2, 15);
    pspDebugScreenPrintf("D-Pad: Move square");
    pspDebugScreenSetXY(2, 16);
    pspDebugScreenPrintf("L/R: Move ball (test camera)");
    pspDebugScreenSetXY(2, 17);
    pspDebugScreenPrintf("X: Change color");
    pspDebugScreenSetXY(2, 18);
    pspDebugScreenPrintf("O/Triangle/Square: Audio test");
    pspDebugScreenSetXY(2, 19);
    pspDebugScreenPrintf("Start+Select: Exit");
}

static void drawLevelTestInfo(void) {
    pspDebugScreenSetXY(2, 2);
    pspDebugScreenPrintf("=== D1 LEVEL TEST (Mode 2/3) ===");
    
    pspDebugScreenSetXY(2, 4);
    pspDebugScreenPrintf("Current Level: %d/11", current_level_num);
    
    pspDebugScreenSetXY(2, 6);
    pspDebugScreenPrintf("Load Status: %s", level_load_success ? "SUCCESS" : "FAILED");
    
    pspDebugScreenSetXY(2, 8);
    pspDebugScreenPrintf("Details:");
    
    // Разбиваем длинную строку на несколько строк (безопасно)
    if (strlen(level_status) > 0) {
        char line1[60], line2[60], line3[60];
        
        // Безопасное копирование с гарантированным завершением строк
        snprintf(line1, sizeof(line1), "%.55s", level_status);
        
        line2[0] = '\0';  // Инициализируем пустой строкой
        if (strlen(level_status) > 55) {
            snprintf(line2, sizeof(line2), "%.55s", level_status + 55);
        }
        
        line3[0] = '\0';  // Инициализируем пустой строкой  
        if (strlen(level_status) > 110) {
            snprintf(line3, sizeof(line3), "%.55s", level_status + 110);
        }
        
        pspDebugScreenSetXY(2, 9);
        pspDebugScreenPrintf("%s", line1);
        if (line2[0] != '\0') {
            pspDebugScreenSetXY(2, 10);
            pspDebugScreenPrintf("%s", line2);
        }
        if (line3[0] != '\0') {
            pspDebugScreenSetXY(2, 11);
            pspDebugScreenPrintf("%s", line3);
        }
    }
    
    // Показать несколько тайлов из карты для отладки
    if (level_load_success && real_level && real_level->tile_map) {
        pspDebugScreenSetXY(2, 13);
        pspDebugScreenPrintf("First 10 tiles:");
        pspDebugScreenSetXY(2, 14);
        for (int i = 0; i < 10 && i < real_level->width * real_level->height; i++) {
            pspDebugScreenPrintf("%02X ", (unsigned char)real_level->tile_map[i]);
        }
    }
    
    pspDebugScreenSetXY(2, 16);
    pspDebugScreenPrintf("Controls:");
    pspDebugScreenSetXY(2, 17);
    pspDebugScreenPrintf("SELECT: Next mode (2->0->1)");
    pspDebugScreenSetXY(2, 18);
    pspDebugScreenPrintf("L/R: Change level (1-11)");
    pspDebugScreenSetXY(2, 19);
    pspDebugScreenPrintf("X: Reload current level");
    pspDebugScreenSetXY(2, 20);
    pspDebugScreenPrintf("Triangle: Show tile details");
    pspDebugScreenSetXY(2, 21);
    pspDebugScreenPrintf("Start+Select: Exit");
}

/* ======== TILE GRID (fallback if C5 test fails) ======== */
static void draw_sample_tiles(texture_t* atlas) {
    if (!atlas) return;

    static const int ids[] = {
        IMG_BRICKS_RED_NORMAL, IMG_BRICKS_BLUE_RUBBER, IMG_SPIKES_UPWARD, IMG_SPIKES_DOWNWARD, IMG_SPIKES_LEFT, IMG_SPIKES_RIGHT, IMG_RESPAWN_GEM,
        IMG_SPIKES_WET_UPWARD, IMG_SPIKES_WET_DOWNWARD, IMG_SPIKES_WET_LEFT, IMG_SPIKES_WET_RIGHT, IMG_RESPAWN_INDICATOR, IMG_EXIT, IMG_EXTRA_LIFE,
        IMG_HOOP_ACTIVE_HORIZ_TOP_LEFT_LARGE, IMG_HOOP_ACTIVE_HORIZ_BOT_LEFT_LARGE, IMG_HOOP_ACTIVE_HORIZ_TOP_RIGHT_LARGE, IMG_HOOP_ACTIVE_HORIZ_BOT_RIGHT_LARGE,
        IMG_HOOP_ACTIVE_HORIZ_TOP_LEFT_SMALL, IMG_HOOP_ACTIVE_HORIZ_BOT_LEFT_SMALL, IMG_HOOP_ACTIVE_HORIZ_TOP_RIGHT_SMALL, IMG_HOOP_ACTIVE_HORIZ_BOT_RIGHT_SMALL,
        IMG_DEFLATOR, IMG_INFLATOR, IMG_GRAVITY, IMG_SPEED, IMG_JUMP,
        IMG_SMALL_BALL, IMG_POPPED_BALL, IMG_LARGE_BALL
    };
    const int count = sizeof(ids)/sizeof(ids[0]);
    const int cols = 7;
    const int ts   = TILE_SIZE;
    const int pad  = 2;
    const int step = ts + pad;
    const int x0   = 20;
    const int y0   = 40;

    for (int i = 0; i < count; ++i) {
        int id = ids[i];
        sprite_rect_t* r = tc_get_tile_sprite(id);
        if (!r) continue;
        int cx = i % cols;
        int cy = i / cols;
        float x = x0 + cx * step;
        float y = y0 + cy * step;
        png_draw_sprite(atlas, r, x, y, ts, ts);
    }
}

/* ======== GU ======== */
static void initGu(void){
    sceGuInit();
    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, (void*)0, BUFFER_WIDTH);
    sceGuDispBuffer(SCREEN_WIDTH, SCREEN_HEIGHT, (void*)0x88000, BUFFER_WIDTH);
    sceGuDepthBuffer((void*)0x110000, BUFFER_WIDTH);
    sceGuOffset(2048 - (SCREEN_WIDTH / 2), 2048 - (SCREEN_HEIGHT / 2));
    sceGuViewport(2048, 2048, SCREEN_WIDTH, SCREEN_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuScissor(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    sceGuDepthRange(65535, 0);
    sceGuDepthFunc(GU_GEQUAL);
    sceGuFinish();
    sceGuDisplay(GU_TRUE);
}
static void endGu(void){
    sceGuDisplay(GU_FALSE);
    sceGuTerm();
}
static void startFrame(void){
    sceGuStart(GU_DIRECT, list);
    sceGuClearColor(0xFFE3D3A2);  // Черный фон экрана как в Java
    sceGuClear(GU_COLOR_BUFFER_BIT);
}
static void endFrame(void){
    sceGuFinish();
    sceGuSync(0, 0);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

int main(void) {
    setup_callbacks();
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
    initGu();
    initAudio();

    /* Tiles */
    if (tc_load_tile_images() == 0) {
        printf("A6: PNG via fs OK\n");
    }

    /* File system test */
    testFileSystem();
    
    /* C5 test */
    initTestLevel();
    
    /* D1 test */
    initRealLevel();
    loadRealLevel(1);  // Загружаем первый уровень по умолчанию

    running = 1;
    int gu_active = 1;

    float rectX = 216.0f, rectY = 96.0f;
    int colorIndex = 0;
    static const unsigned int colors[4] = {
        0xFF0000FF, 0xFF00FF00, 0xFFFF0000, 0xFF00FFFF
    };

    unsigned int lastButtons = 0;

    while (running) {
        SceCtrlData pad;
        sceCtrlPeekBufferPositive(&pad, 1);

        if ((pad.Buttons & PSP_CTRL_START) && (pad.Buttons & PSP_CTRL_SELECT)) {
            running = 0;
        }

        /* Переключение режимов отображения */
        if ((pad.Buttons & PSP_CTRL_SELECT) && !(lastButtons & PSP_CTRL_SELECT)) {
            display_mode = (DisplayMode)((display_mode + 1) % 3);
            printf("Switched to display mode %d\n", display_mode);
        }

        /* Управление в зависимости от режима */
        if (display_mode == MODE_GAME) {
            // Движение прямоугольника
            if (pad.Buttons & PSP_CTRL_LEFT)  rectX -= 2.0f;
            if (pad.Buttons & PSP_CTRL_RIGHT) rectX += 2.0f;
            if (pad.Buttons & PSP_CTRL_UP)    rectY -= 2.0f;
            if (pad.Buttons & PSP_CTRL_DOWN)  rectY += 2.0f;

            // C5: Движение "мяча" для тестирования камеры
            if ((pad.Buttons & PSP_CTRL_LTRIGGER) && !(lastButtons & PSP_CTRL_LTRIGGER)) {
                simulated_ball_x--;
                if (simulated_ball_x < 0) simulated_ball_x = 0;
            }
            if ((pad.Buttons & PSP_CTRL_RTRIGGER) && !(lastButtons & PSP_CTRL_RTRIGGER)) {
                simulated_ball_x++;
                if (test_level && simulated_ball_x >= test_level_width) {
                    simulated_ball_x = test_level_width - 1;
                }
            }
            
            // Непрерывное движение при удержании кнопок
            static int move_counter = 0;
            if (pad.Buttons & (PSP_CTRL_LTRIGGER | PSP_CTRL_RTRIGGER)) {
                move_counter++;
                if (move_counter > 10) { 
                    if ((move_counter % 3) == 0) { 
                        if (pad.Buttons & PSP_CTRL_LTRIGGER) {
                            simulated_ball_x--;
                            if (simulated_ball_x < 0) simulated_ball_x = 0;
                        }
                        if (pad.Buttons & PSP_CTRL_RTRIGGER) {
                            simulated_ball_x++;
                            if (test_level && simulated_ball_x >= test_level_width) {
                                simulated_ball_x = test_level_width - 1;
                            }
                        }
                    }
                }
            } else {
                move_counter = 0;
            }

            if ((pad.Buttons & PSP_CTRL_CROSS) && !(lastButtons & PSP_CTRL_CROSS)) {
                colorIndex = (colorIndex + 1) % 4;
            }
        }
        else if (display_mode == MODE_LEVEL_TEST) {
            // Управление тестом уровней
            if ((pad.Buttons & PSP_CTRL_LTRIGGER) && !(lastButtons & PSP_CTRL_LTRIGGER)) {
                int new_level = current_level_num - 1;
                if (new_level < 1) new_level = MAX_LEVEL;
                loadRealLevel(new_level);
            }
            if ((pad.Buttons & PSP_CTRL_RTRIGGER) && !(lastButtons & PSP_CTRL_RTRIGGER)) {
                int new_level = current_level_num + 1;
                if (new_level > MAX_LEVEL) new_level = 1;
                loadRealLevel(new_level);
            }
            
            if ((pad.Buttons & PSP_CTRL_CROSS) && !(lastButtons & PSP_CTRL_CROSS)) {
                loadRealLevel(current_level_num);  // Перезагрузить текущий уровень
            }
        }

        /* Аудио-тесты (во всех режимах) */
        if ((pad.Buttons & PSP_CTRL_CIRCLE)   && !(lastButtons & PSP_CTRL_CIRCLE))   { playTone(1000.0f, 500); }
        if ((pad.Buttons & PSP_CTRL_TRIANGLE) && !(lastButtons & PSP_CTRL_TRIANGLE)) { playTone(500.0f, 300); }
        if ((pad.Buttons & PSP_CTRL_SQUARE)   && !(lastButtons & PSP_CTRL_SQUARE))   { playTone(2000.0f, 200); }

        /* Переключение между GU и debug screen */
        if (display_mode != MODE_GAME && prev_display_mode == MODE_GAME) {
            if (gu_active) { sceGuSync(0, 0); endGu(); gu_active = 0; }
            pspDebugScreenInit();
            pspDebugScreenClear();
            pspDebugScreenSetBackColor(0x00000000);
            pspDebugScreenSetTextColor(0xFFFFFFFF);
        }
        if (display_mode == MODE_GAME && prev_display_mode != MODE_GAME) {
            sceDisplayWaitVblankStart();
            if (!gu_active) { initGu(); gu_active = 1; }
        }
        prev_display_mode = display_mode;
        lastButtons = pad.Buttons;

        /* Ограничения для прямоугольника */
        if (rectX < 0) rectX = 0;
        if (rectX > SCREEN_WIDTH - RECT_WIDTH)  rectX = SCREEN_WIDTH - RECT_WIDTH;
        if (rectY < 0) rectY = 0;
        if (rectY > SCREEN_HEIGHT - RECT_HEIGHT) rectY = SCREEN_HEIGHT - RECT_HEIGHT;

        /* Рендер в зависимости от режима */
        if (display_mode == MODE_DEBUG_INFO) {
            drawDebugInfo();
            sceDisplayWaitVblankStart();
        } 
        else if (display_mode == MODE_LEVEL_TEST) {
            drawLevelTestInfo();
            sceDisplayWaitVblankStart();
        }
        else { // MODE_GAME
            startFrame();
            sceGuColor(colors[colorIndex]);
            drawRect(rectX, rectY, RECT_WIDTH, RECT_HEIGHT);

            /* Рендер уровня: приоритет реальному уровню, fallback к тестовому */
            if (level_load_success && real_level && real_level->tile_map) {
                // D1 Test: Рендер реального уровня
                texture_t* atlas = tc_get_tile_atlas();
                if (atlas) {
                    // ОТЛАДКА: Создаем временный 2D массив для tc_render_level
                    int** temp_map = (int**)malloc(real_level->height * sizeof(int*));
                    for (int y = 0; y < real_level->height; y++) {
                        temp_map[y] = (int*)malloc(real_level->width * sizeof(int));
                        for (int x = 0; x < real_level->width; x++) {
                            temp_map[y][x] = (int)TILE_AT(real_level, x, y);
                        }
                    }
                    
                    // Простая камера для демонстрации - показываем левый верхний угол
                    int camera_x = 0;
                    int camera_y = 0;
                    
                    // ОТЛАДКА: Выводим первые несколько тайлов для проверки
                    static int debug_counter = 0;
                    if (debug_counter % 120 == 0) { // Каждые 4 секунды
                        printf("D1 DEBUG: Level %dx%d, first 8 tiles: ", real_level->width, real_level->height);
                        for (int i = 0; i < 8 && i < real_level->width * real_level->height; i++) {
                            printf("%d ", real_level->tile_map[i]);
                        }
                        printf("\n");
                        
                        // ОТЛАДКА: Найдем все кольца в уровне
                        printf("D1 DEBUG: Ring tiles found: ");
                        int ring_count = 0;
                        for (int i = 0; i < real_level->width * real_level->height && ring_count < 10; i++) {
                            int tile_id = real_level->tile_map[i];
                            if (tile_id >= 13 && tile_id <= 28) { // Все типы колец
                                printf("ID_%d ", tile_id);
                                ring_count++;
                            }
                        }
                        if (ring_count == 0) printf("NONE");
                        printf("\n");
                    }
                    debug_counter++;
                    
                    // Рендерим реальный уровень через наш tile engine
                    tc_render_level(atlas, temp_map, real_level->width, real_level->height, camera_x, camera_y);
                    
                    // ОТЛАДКА НА ЭКРАНЕ: Показываем ID колец
                    static int ring_ids[10] = {-1};
                    static int ring_count = 0;
                    static int scan_done = 0;
                    
                    if (!scan_done) {
                        // Сканируем уровень один раз, ищем кольца
                        ring_count = 0;
                        for (int i = 0; i < real_level->width * real_level->height && ring_count < 10; i++) {
                            int tile_id = real_level->tile_map[i];
                            if (tile_id >= 13 && tile_id <= 28) { // Диапазон колец
                                ring_ids[ring_count] = tile_id;
                                ring_count++;
                            }
                        }
                        scan_done = 1;
                    }
                    
                    // Показываем найденные кольца в углу экрана (белый текст поверх игры)
                    sceGuDisable(GU_TEXTURE_2D);
                    for (int i = 0; i < ring_count && i < 5; i++) {
                        // Простые белые прямоугольники как "пиксельные цифры"
                        int x = 10 + i * 30;
                        int y = 10;
                        sceGuColor(0xFFFFFFFF); // Белый
                        
                        // Рисуем ID кольца как набор прямоугольников
                        int id = ring_ids[i];
                        int tens = id / 10;
                        int ones = id % 10;
                        
                        // Десятки
                        if (tens > 0) {
                            for (int j = 0; j < tens; j++) {
                                drawRect(x + j * 3, y, 2, 8);
                            }
                        }
                        
                        // Единицы (ниже)
                        for (int j = 0; j < ones; j++) {
                            drawRect(x + j * 3, y + 10, 2, 8);
                        }
                    }
                    
                    // Освобождаем временный массив
                    for (int y = 0; y < real_level->height; y++) {
                        free(temp_map[y]);
                    }
                    free(temp_map);
                    
                    // Показываем позицию старта как красную точку
                    int start_screen_x = real_level->start_pos_x * TILE_SIZE;
                    int start_screen_y = real_level->start_pos_y * TILE_SIZE;
                    if (start_screen_x < SCREEN_WIDTH && start_screen_y < SCREEN_HEIGHT) {
                        sceGuColor(0xFF0000FF); // Красный старт
                        drawRect(start_screen_x - 3, start_screen_y - 3, 6, 6);
                    }
                    
                    // Показываем позицию выхода как зеленую точку
                    int exit_screen_x = real_level->exit_pos_x * TILE_SIZE;
                    int exit_screen_y = real_level->exit_pos_y * TILE_SIZE;
                    if (exit_screen_x < SCREEN_WIDTH && exit_screen_y < SCREEN_HEIGHT) {
                        sceGuColor(0xFF00FF00); // Зеленый выход
                        drawRect(exit_screen_x - 3, exit_screen_y - 3, 6, 6);
                    }
                }
            }
            else if (test_level) {
                // C5 Test: Fallback к тестовому уровню
                texture_t* atlas = tc_get_tile_atlas();
                if (atlas) {
                    // Вычисляем позицию камеры следуя за "мячом"
                    int camera_x = tc_camera_follow_ball(simulated_ball_x, test_level_width);
                    int camera_y = 0;  // Камера не двигается по Y пока
                    
                    // Рендерим тестовый уровень
                    tc_render_level(atlas, test_level, test_level_width, test_level_height, camera_x, camera_y);
                    
                    // Правильное позиционирование кубика
                    int ball_screen_x = (simulated_ball_x - camera_x) * TILE_SIZE + TILE_SIZE/2;
                    int ball_screen_y = 100;  // Фиксированная высота для теста
                    
                    // Отладочная информация 
                    if (simulated_ball_x % 5 == 0) {  // Печатаем каждые 5 позиций
                        printf("Ball X=%d, Camera=%d, Screen=%d\n", simulated_ball_x, camera_x, ball_screen_x);
                    }
                    
                    // Рисуем кубик только если он виден на экране
                    if (ball_screen_x >= 0 && ball_screen_x < SCREEN_WIDTH) {
                        sceGuColor(0xFF0000FF); // Красный "мяч"
                        drawRect(ball_screen_x - 3, ball_screen_y - 3, 6, 6);
                    }
                }
            } else {
                // Fallback - старая сетка тайлов если ни один уровень не загрузился
                texture_t* atlas = tc_get_tile_atlas();
                if (atlas) {
                    draw_sample_tiles(atlas);
                }
            }

            endFrame();
        }
    }

    cleanupTestLevel();
    cleanupRealLevel();
    tc_cleanup_tiles();
    endAudio();
    endGu();
    return 0;
}

