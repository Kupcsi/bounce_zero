#ifndef TILE_CANVAS_H
#define TILE_CANVAS_H

#include "png.h"
#include "bounce_const.h"

/**
 * Load PNG file into GU texture (аналог TileCanvas.loadImage)
 * @param path Resource path to PNG file 
 * @return Pointer to texture_t, or NULL on failure
 */
texture_t* tc_load_image(const char* path);

/**
 * Create sprite rectangle from texture atlas (аналог TileCanvas.extractImage)
 * @param tex Source texture
 * @param tile_x, tile_y Tile coordinates (0,0 = top-left tile)
 * @return Sprite rectangle with UV coordinates for 12x12 tile
 */
sprite_rect_t tc_extract_image(texture_t* tex, int tile_x, int tile_y);

/**
 * Create sprite with background color (аналог TileCanvas.extractImageBG)
 * @param tex Source texture
 * @param tile_x, tile_y Tile coordinates (0,0 = top-left tile)
 * @param bg_color Background color (currently unused - for future)
 * @return Sprite rectangle with UV coordinates for 12x12 tile
 */
sprite_rect_t tc_extract_image_bg(texture_t* tex, int tile_x, int tile_y, uint32_t bg_color);

/**
 * Load all tile images from atlas (аналог TileCanvas.loadTileImages)
 * @return 0 on success, negative on failure
 */
int tc_load_tile_images(void);

/**
 * Get sprite rectangle for tile by index (аналог TileCanvas.getImage)
 * @param tile_id Tile ID (0-66)
 * @return Pointer to sprite rectangle, or NULL if invalid
 */
sprite_rect_t* tc_get_tile_sprite(int tile_id);

/**
 * Free all loaded tile resources
 */
void tc_cleanup_tiles(void);

/**
 * Get tile atlas texture
 * @return Pointer to loaded atlas texture
 */
texture_t* tc_get_tile_atlas(void);

/**
 * Draw single tile or composite tile
 * @param atlas Atlas texture
 * @param tile_id ID of tile to draw
 * @param x, y Screen position in pixels
 * @param size Size of tile in pixels
 */
void tc_draw_tile(texture_t* atlas, int tile_id, int x, int y, int size);

/* ========== C5: Level rendering functions ========== */

/**
 * Calculate camera position following ball (аналог BounceCanvas.createBufferFocused)
 * @param ball_tile_x Ball position in tile coordinates
 * @param map_width Level width in tiles
 * @return Camera X position (left edge of visible area)
 */
int tc_camera_follow_ball(int ball_tile_x, int map_width);

/**
 * Render visible portion of level to screen (аналог TileCanvas.createNewBuffer)
 * @param atlas Tile atlas texture
 * @param level_map 2D array of tile IDs [height][width]
 * @param map_width Level width in tiles
 * @param map_height Level height in tiles  
 * @param camera_x Camera position X (tiles)
 * @param camera_y Camera position Y (tiles)
 */
void tc_render_level(texture_t* atlas, int** level_map, int map_width, int map_height,
                     int camera_x, int camera_y);

/**
 * Create a simple test level for C5 testing
 * @param width Level width in tiles (output)
 * @param height Level height in tiles (output)
 * @return 2D array of tile IDs, or NULL on failure
 */
int** tc_create_test_level(int* width, int* height);

/**
 * Free test level created by tc_create_test_level
 * @param level_map Level map to free
 * @param height Level height
 */
void tc_free_test_level(int** level_map, int height);

#endif // TILE_CANVAS_H
