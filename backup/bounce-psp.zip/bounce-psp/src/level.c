#include "level.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

Level* level_create(void) {
    Level* level = (Level*)malloc(sizeof(Level));
    if (!level) {
        printf("level_create: malloc failed\n");
        return NULL;
    }
    
    memset(level, 0, sizeof(Level));
    printf("level_create: Level structure created\n");
    return level;
}

int level_load_from_file(Level* level, int level_num) {
    if (!level) {
        printf("level_load_from_file: NULL level\n");
        return LEVEL_ERROR_INVALID_LEVEL;
    }
    
    // Clear previous data
    if (level->tile_map) {
        free(level->tile_map);
        level->tile_map = NULL;
    }
    if (level->moving_objects) {
        free(level->moving_objects);
        level->moving_objects = NULL;
    }
    level->num_moving_objects = 0;
    
    // Build filename
    char filename[64];
    snprintf(filename, sizeof(filename), "/levels/J2MElvl.%03d", level_num);
    
    printf("level_load_from_file: Loading %s\n", filename);
    
    // Open file
    res_handle_t handle = res_open(filename);
    if (handle < 0) {
        printf("level_load_from_file: Failed to open %s\n", filename);
        return LEVEL_ERROR_FILE_NOT_FOUND;
    }
    
    // Read level header (7 bytes)
    unsigned char header[7];
    int bytes_read = res_read(handle, header, 7);
    if (bytes_read != 7) {
        printf("level_load_from_file: Failed to read header (got %d/7 bytes)\n", bytes_read);
        res_close(handle);
        return LEVEL_ERROR_FILE_READ;
    }
    
    // Parse header
    level->start_pos_x = header[0];
    level->start_pos_y = header[1];
    level->ball_size = header[2];
    level->exit_pos_x = header[3];
    level->exit_pos_y = header[4];
    level->total_rings = header[5];
    level->width = header[6];
    
    // Read height
    unsigned char height_byte;
    bytes_read = res_read(handle, &height_byte, 1);
    if (bytes_read != 1) {
        printf("level_load_from_file: Failed to read height\n");
        res_close(handle);
        return LEVEL_ERROR_FILE_READ;
    }
    level->height = height_byte;
    
    printf("level_load_from_file: Level %dx%d, start=(%d,%d), exit=(%d,%d), rings=%d, ball=%s\n",
           level->width, level->height, level->start_pos_x, level->start_pos_y,
           level->exit_pos_x, level->exit_pos_y, level->total_rings,
           level->ball_size == 0 ? "small" : "large");
    
    // Validate dimensions
    if (level->width <= 0 || level->height <= 0 || 
        level->width > 1000 || level->height > 1000) {
        printf("level_load_from_file: Invalid dimensions %dx%d\n", level->width, level->height);
        res_close(handle);
        return LEVEL_ERROR_INVALID_DATA;
    }
    
    // Allocate tile map
    int map_size = level->width * level->height;
    level->tile_map = (int16_t*)malloc(map_size * sizeof(int16_t));
    if (!level->tile_map) {
        printf("level_load_from_file: Failed to allocate tile map\n");
        res_close(handle);
        return LEVEL_ERROR_MEMORY;
    }
    
    // Read tile map
    unsigned char* temp_map = (unsigned char*)malloc(map_size);
    if (!temp_map) {
        printf("level_load_from_file: Failed to allocate temp buffer\n");
        free(level->tile_map);
        level->tile_map = NULL;
        res_close(handle);
        return LEVEL_ERROR_MEMORY;
    }
    
    bytes_read = res_read(handle, temp_map, map_size);
    if (bytes_read != map_size) {
        printf("level_load_from_file: Failed to read tile map (got %d/%d bytes)\n", 
               bytes_read, map_size);
        free(temp_map);
        free(level->tile_map);
        level->tile_map = NULL;
        res_close(handle);
        return LEVEL_ERROR_FILE_READ;
    }
    
    // Convert to int16_t
    for (int i = 0; i < map_size; i++) {
        level->tile_map[i] = (int16_t)temp_map[i];
    }
    free(temp_map);
    
    // D2: Load moving objects (добавить после загрузки tile map)
    printf("level_load_from_file: Loading moving objects...\n");
    int mo_result = level_load_moving_objects(level, handle);
    if (mo_result != LEVEL_OK) {
        printf("level_load_from_file: Failed to load moving objects: %d\n", mo_result);
        // Не критичная ошибка - продолжаем без движущихся объектов
        level->num_moving_objects = 0;
        level->moving_objects = NULL;
    }
    
    res_close(handle);
    
    printf("level_load_from_file: Successfully loaded level %d\n", level_num);
    return LEVEL_OK;
}

/**
 * D2: Load moving objects from level file stream
 * Аналог TileCanvas.createMovingObj() (строки 287-356)
 */
int level_load_moving_objects(Level* level, res_handle_t handle) {
    if (!level) {
        printf("level_load_moving_objects: NULL level\n");
        return LEVEL_ERROR_INVALID_LEVEL;
    }
    
    if (handle < 0) {
        printf("level_load_moving_objects: invalid file handle\n");
        return LEVEL_ERROR_FILE_READ;
    }
    
    printf("level_load_moving_objects: Reading moving objects data\n");
    
    // Читаем количество движущихся объектов (1 байт)
    unsigned char num_move_obj;
    int bytes_read = res_read(handle, &num_move_obj, 1);
    if (bytes_read != 1) {
        printf("level_load_moving_objects: Failed to read numMoveObj\n");
        return LEVEL_ERROR_FILE_READ;
    }
    
    level->num_moving_objects = (int)num_move_obj;
    printf("level_load_moving_objects: numMoveObj = %d\n", level->num_moving_objects);
    
    // Валидация: разумное количество объектов
    if (level->num_moving_objects > MAX_MOVING_OBJECTS) {
        printf("level_load_moving_objects: Too many moving objects %d > %d\n", 
               level->num_moving_objects, MAX_MOVING_OBJECTS);
        return LEVEL_ERROR_INVALID_DATA;
    }
    
    // Если нет движущихся объектов - успешное завершение
    if (level->num_moving_objects == 0) {
        printf("level_load_moving_objects: No moving objects in level\n");
        return LEVEL_OK;
    }
    
    // Выделяем память для движущихся объектов
    if (level->moving_objects) {
        free(level->moving_objects);
    }
    level->moving_objects = (MovingObj*)malloc(level->num_moving_objects * sizeof(MovingObj));
    if (!level->moving_objects) {
        printf("level_load_moving_objects: Failed to allocate memory for %d objects\n", 
               level->num_moving_objects);
        level->num_moving_objects = 0;
        return LEVEL_ERROR_MEMORY;
    }
    
    // Читаем данные каждого движущегося объекта
    // Формат: topLeftX, topLeftY, botRightX, botRightY, directionX, directionY, offsetX, offsetY
    for (int i = 0; i < level->num_moving_objects; i++) {
        MovingObj* obj = &level->moving_objects[i];
        unsigned char data[8];  // 8 байт на объект
        
        bytes_read = res_read(handle, data, 8);
        if (bytes_read != 8) {
            printf("level_load_moving_objects: Failed to read object %d data (got %d/8 bytes)\n", 
                   i, bytes_read);
            free(level->moving_objects);
            level->moving_objects = NULL;
            level->num_moving_objects = 0;
            return LEVEL_ERROR_FILE_READ;
        }
        
        // Парсинг согласно TileCanvas.createMovingObj():
        obj->top_left[0] = (int16_t)data[0];    // topLeftX
        obj->top_left[1] = (int16_t)data[1];    // topLeftY
        obj->bot_right[0] = (int16_t)data[2];   // botRightX  
        obj->bot_right[1] = (int16_t)data[3];   // botRightY
        obj->direction[0] = (int16_t)data[4];   // directionX
        obj->direction[1] = (int16_t)data[5];   // directionY
        obj->offset[0] = (int16_t)data[6];      // offsetX
        obj->offset[1] = (int16_t)data[7];      // offsetY
        
        // Валидация границ объекта
        if (obj->top_left[0] < 0 || obj->top_left[1] < 0 ||
            obj->bot_right[0] >= level->width || obj->bot_right[1] >= level->height) {
            printf("level_load_moving_objects: Object %d has invalid bounds: "
                   "topLeft=(%d,%d) botRight=(%d,%d) vs levelSize=(%d,%d)\n",
                   i, obj->top_left[0], obj->top_left[1], 
                   obj->bot_right[0], obj->bot_right[1], level->width, level->height);
            // Продолжаем, но отмечаем проблему
        }
        
        // Валидация направления (должно быть -1, 0, или 1)
        if ((obj->direction[0] != -1 && obj->direction[0] != 0 && obj->direction[0] != 1) ||
            (obj->direction[1] != -1 && obj->direction[1] != 0 && obj->direction[1] != 1)) {
            printf("level_load_moving_objects: Object %d has invalid direction: (%d,%d)\n",
                   i, obj->direction[0], obj->direction[1]);
            // Продолжаем, но отмечаем проблему
        }
        
        printf("level_load_moving_objects: Object %d: topLeft=(%d,%d) botRight=(%d,%d) "
               "direction=(%d,%d) offset=(%d,%d)\n",
               i, obj->top_left[0], obj->top_left[1], obj->bot_right[0], obj->bot_right[1],
               obj->direction[0], obj->direction[1], obj->offset[0], obj->offset[1]);
    }
    
    printf("level_load_moving_objects: Successfully loaded %d moving objects\n", 
           level->num_moving_objects);
    return LEVEL_OK;
}

void level_destroy(Level* level) {
    if (!level) return;
    
    if (level->tile_map) {
        free(level->tile_map);
        level->tile_map = NULL;
    }
    
    // D2: Освобождение движущихся объектов
    if (level->moving_objects) {
        free(level->moving_objects);
        level->moving_objects = NULL;
    }
    level->num_moving_objects = 0;
    
    free(level);
    printf("level_destroy: Level destroyed\n");
}

void level_get_debug_stats(Level* level, char* buffer) {
    if (!level || !buffer) return;
    
    char mo_info[256];
    level_get_moving_objects_debug(level, mo_info, sizeof(mo_info));
    
    snprintf(buffer, 512, 
        "Level %dx%d | Start=(%d,%d) Exit=(%d,%d) Ball=%s | Rings=%d | %s",
        level->width, level->height,
        level->start_pos_x, level->start_pos_y, 
        level->exit_pos_x, level->exit_pos_y,
        level->ball_size == 0 ? "SMALL" : "LARGE",
        level->total_rings,
        mo_info);
}

/**
 * D2: Get debug info about moving objects
 */
void level_get_moving_objects_debug(Level* level, char* buffer, int buffer_size) {
    if (!level || !buffer || buffer_size <= 0) {
        return;
    }
    
    if (level->num_moving_objects == 0) {
        snprintf(buffer, buffer_size, "Moving objects: NONE");
        return;
    }
    
    int pos = 0;
    pos += snprintf(buffer + pos, buffer_size - pos, 
                   "Moving objects: %d | ", level->num_moving_objects);
    
    for (int i = 0; i < level->num_moving_objects && pos < buffer_size - 50; i++) {
        MovingObj* obj = &level->moving_objects[i];
        pos += snprintf(buffer + pos, buffer_size - pos,
                       "MO%d[%d,%d->%d,%d dir=%d,%d] ", 
                       i, obj->top_left[0], obj->top_left[1], 
                       obj->bot_right[0], obj->bot_right[1],
                       obj->direction[0], obj->direction[1]);
    }
}
