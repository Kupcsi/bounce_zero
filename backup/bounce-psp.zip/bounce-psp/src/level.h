#ifndef LEVEL_H
#define LEVEL_H

#include "fs.h"
#include <stdint.h>

// Error codes
#define LEVEL_OK 0
#define LEVEL_ERROR_FILE_NOT_FOUND -1
#define LEVEL_ERROR_FILE_READ -2
#define LEVEL_ERROR_INVALID_DATA -3
#define LEVEL_ERROR_MEMORY -4
#define LEVEL_ERROR_INVALID_LEVEL -5

// D2: Constants
#define MAX_MOVING_OBJECTS 16  // Разумный лимит для движущихся объектов

// D2: Движущийся объект (аналог mMO* массивов из TileCanvas.java)
typedef struct {
    int16_t top_left[2];    // mMOTopLeft[i][X/Y] - левый верхний угол области
    int16_t bot_right[2];   // mMOBotRight[i][X/Y] - правый нижний угол области  
    int16_t direction[2];   // mMODirection[i][X/Y] - направление движения (-1, 0, 1)
    int16_t offset[2];      // mMOOffset[i][X/Y] - текущее смещение в пикселях
} MovingObj;

// Level structure
typedef struct {
    int width, height;          // Размеры карты в тайлах
    int start_pos_x, start_pos_y; // Позиция старта
    int ball_size;              // Размер мяча (0=маленький, 1=большой)
    int exit_pos_x, exit_pos_y; // Позиция выхода
    int total_rings;            // Общее количество колец
    
    int16_t* tile_map;          // Карта тайлов [height * width]
    
    // D2: Движущиеся объекты
    int num_moving_objects;      // mNumMoveObj
    MovingObj* moving_objects;   // Массив движущихся объектов
} Level;

// Macro for safe tile access
#define TILE_AT(level, x, y) ((level)->tile_map[(y) * (level)->width + (x)])

/**
 * Create empty level structure
 * @return Pointer to Level or NULL on failure
 */
Level* level_create(void);

/**
 * Load level from file
 * @param level Level structure to populate
 * @param level_num Level number (1-11)
 * @return LEVEL_OK on success, error code on failure
 */
int level_load_from_file(Level* level, int level_num);

/**
 * D2: Load moving objects from level file stream
 * @param level Level structure to populate (must have tile map already loaded)
 * @param handle Open file handle positioned after tile map data
 * @return LEVEL_OK on success, error code on failure
 */
int level_load_moving_objects(Level* level, res_handle_t handle);

/**
 * Free level resources
 * @param level Level to destroy
 */
void level_destroy(Level* level);

/**
 * Get debug statistics about loaded level
 * @param level Level structure
 * @param buffer Output buffer (should be at least 512 bytes)
 */
void level_get_debug_stats(Level* level, char* buffer);

/**
 * D2: Get debug info about moving objects
 * @param level Level structure
 * @param buffer Output buffer for debug string
 * @param buffer_size Size of output buffer
 */
void level_get_moving_objects_debug(Level* level, char* buffer, int buffer_size);

#endif // LEVEL_H
