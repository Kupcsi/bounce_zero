#include "fs.h"
#include <pspiofilemgr.h>
#include <stdio.h>
#include <string.h>

/**
 * Build full path from resource path
 * Converts "/icons/objects_nm.png" to "<RES_PATH_PREFIX>/icons/objects_nm.png"
 */
static void build_full_path(const char* res_path, char* full_path) {
    const char* clean_path = (res_path && res_path[0] == '/') ? res_path + 1 : res_path;
    snprintf(full_path, MAX_PATH_LEN, "%s/%s", RES_PATH_PREFIX, clean_path ? clean_path : "");
}

res_handle_t res_open(const char* path) {
    if (!path) {
        printf("res_open: NULL path\n");
        return RES_ERROR_INVALID_HANDLE;
    }
    char full_path[MAX_PATH_LEN];
    build_full_path(path, full_path);
    SceUID fd = sceIoOpen(full_path, PSP_O_RDONLY, 0);
    if (fd < 0) {
        printf("res_open: open failed %s (err=0x%08X)\n", full_path, fd);
        return RES_ERROR_NOT_FOUND;
    }
    return fd;
}

int res_read(res_handle_t handle, void* buffer, int size) {
    if (handle < 0) return RES_ERROR_INVALID_HANDLE;
    if (!buffer || size <= 0) return RES_ERROR_READ;
    int bytes_read = sceIoRead(handle, buffer, size);
    if (bytes_read < 0) return RES_ERROR_READ;
    return bytes_read;
}

int res_read_all(res_handle_t handle, void* buffer, int size) {
    if (handle < 0) return RES_ERROR_INVALID_HANDLE;
    if (!buffer || size < 0) return RES_ERROR_READ;
    int total = 0;
    while (total < size) {
        int n = sceIoRead(handle, (char*)buffer + total, size - total);
        if (n < 0) return RES_ERROR_READ;
        if (n == 0) break; // EOF
        total += n;
    }
    return total;
}

int res_size(res_handle_t handle) {
    if (handle < 0) return RES_ERROR_INVALID_HANDLE;
    int cur = sceIoLseek32(handle, 0, PSP_SEEK_CUR);
    if (cur < 0) return RES_ERROR_READ;
    int end = sceIoLseek32(handle, 0, PSP_SEEK_END);
    if (end < 0) return RES_ERROR_READ;
    int rc = sceIoLseek32(handle, cur, PSP_SEEK_SET);
    if (rc < 0) return RES_ERROR_READ;
    return end;
}

int res_seek(res_handle_t handle, int offset) {
    if (handle < 0) return RES_ERROR_INVALID_HANDLE;
    int pos = sceIoLseek32(handle, offset, PSP_SEEK_SET);
    return (pos < 0) ? RES_ERROR_READ : pos;
}

void res_close(res_handle_t handle) {
    if (handle < 0) return;
    sceIoClose(handle);
}

int res_exists(const char* path) {
    if (!path) return 0;
    char full_path[MAX_PATH_LEN];
    build_full_path(path, full_path);
    SceIoStat st;
    int rc = sceIoGetstat(full_path, &st);
    return rc >= 0;
}

