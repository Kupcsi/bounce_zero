#ifndef FS_H
#define FS_H

#include <pspiofilemgr.h>

// File system layer for PSP resource loading
// Maps J2ME getResourceAsStream() to PSP sceIo* functions

#ifndef RES_PATH_PREFIX
#define RES_PATH_PREFIX "./assets"
#endif
#define MAX_PATH_LEN 256

// File handle type (PSP file descriptor)
typedef SceUID res_handle_t;

// Error codes
#define RES_OK 0
#define RES_ERROR_NOT_FOUND -1
#define RES_ERROR_READ -2
#define RES_ERROR_INVALID_HANDLE -3

/**
 * Open a resource file
 * @param path Resource path (e.g. "/icons/objects_nm.png")
 * @return File handle (>=0) on success, negative error code on failure
 */
res_handle_t res_open(const char* path);

/**
 * Read data from resource file
 * @param handle File handle from res_open()
 * @param buffer Buffer to read into
 * @param size Number of bytes to read
 * @return Number of bytes actually read, or negative error code
 */
int res_read(res_handle_t handle, void* buffer, int size);

/**
 * Read exactly 'size' bytes (or until EOF). Returns bytes read or negative error.
 * Safe wrapper that loops until done.
 */
int res_read_all(res_handle_t handle, void* buffer, int size);

/**
 * Get file size
 * @param handle File handle from res_open()
 * @return File size in bytes, or negative error code
 */
int res_size(res_handle_t handle);

/**
 * Seek to position in file
 * @param handle File handle from res_open()
 * @param offset Offset from start of file
 * @return New position, or negative error code
 */
int res_seek(res_handle_t handle, int offset);

/**
 * Close resource file
 * @param handle File handle from res_open()
 */
void res_close(res_handle_t handle);

/**
 * Check if file exists
 * @param path Resource path
 * @return 1 if exists, 0 if not found
 */
int res_exists(const char* path);

#endif // FS_H

