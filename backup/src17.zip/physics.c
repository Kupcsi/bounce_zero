// physics.c - Портированная физика из Ball.java (с подводной физикой)
#include "types.h"
#include "level.h"
#include "tile_table.h"
#include "game.h"        // Для событийного API
#include <stdlib.h>

// Битовые маски для пиксельных коллизий
#include "level_masks.inc"

// Forward declarations
static bool collisionDetection(Player* p, int testX, int testY);
static bool testTile(Player* p, int tileY, int tileX, bool canMove);
static bool squareCollide(Player* p, int tileRow, int tileCol);
static bool triangleCollide(Player* p, int tileRow, int tileCol, int tileID);
static bool thinCollide(Player* p, int tileRow, int tileCol, int tileID);
static bool edgeCollide(Player* p, int tileRow, int tileCol, int tileID);
static void redirectBall(Player* p, int tileID);

// Утилита для rect коллизий (эквивалент TileCanvas.rectCollide)
static bool rectCollide(int x1, int y1, int x2, int y2, int rx1, int ry1, int rx2, int ry2);

// Константы перенесены в types.h для централизации

// Инициализация игрока
void player_init(Player* p, int x, int y, BallSizeState sizeState) {
    p->xPos = x;
    p->yPos = y;
    p->globalBallX = 0;
    p->globalBallY = 0;
    p->xSpeed = 0;
    p->ySpeed = 0;
    p->direction = 0;
    p->jumpOffset = 0;
    p->ballState = BALL_STATE_NORMAL;
    p->sizeState = sizeState;
    
    // Установка размера в зависимости от состояния
    if (sizeState == SMALL_SIZE_STATE) {
        p->ballSize = NORMAL_SIZE;
        p->mHalfBallSize = HALF_NORMAL_SIZE;
    } else if (sizeState == LARGE_SIZE_STATE) {
        p->ballSize = ENLARGED_SIZE;
        p->mHalfBallSize = HALF_ENLARGED_SIZE;
    }
    
    p->mGroundedFlag = 0;
    p->mCDRubberFlag = 0;
    p->mCDRampFlag = 0;
    
    p->speedBonusCntr = 0;
    p->gravBonusCntr = 0;
    p->jumpBonusCntr = 0;
    p->slideCntr = 0;
    
    p->isInWater = false;
}

// Увеличение мяча (портировано из enlargeBall())
void enlarge_ball(Player* p) {
    if (p->sizeState == LARGE_SIZE_STATE) return; // Уже большой
    
    p->sizeState = LARGE_SIZE_STATE;
    p->ballSize = ENLARGED_SIZE;
    p->mHalfBallSize = HALF_ENLARGED_SIZE;
    
    // Полная логика поиска свободного места как в оригинале
    int offset = 2;
    int found_free_space = 0;
    
    while (!found_free_space) {
        found_free_space = 1;
        
        // Проверяем все 6 направлений в порядке приоритета как в Ball.java:
        if (collisionDetection(p, p->xPos, p->yPos - offset)) {
            // 1. Вверх (приоритет)
            p->yPos -= offset;
        } else if (collisionDetection(p, p->xPos - offset, p->yPos - offset)) {
            // 2. Лево-вверх
            p->xPos -= offset;
            p->yPos -= offset;
        } else if (collisionDetection(p, p->xPos + offset, p->yPos - offset)) {
            // 3. Право-вверх
            p->xPos += offset;
            p->yPos -= offset;
        } else if (collisionDetection(p, p->xPos, p->yPos + offset)) {
            // 4. Вниз
            p->yPos += offset;
        } else if (collisionDetection(p, p->xPos - offset, p->yPos + offset)) {
            // 5. Лево-вниз
            p->xPos -= offset;
            p->yPos += offset;
        } else if (collisionDetection(p, p->xPos + offset, p->yPos + offset)) {
            // 6. Право-вниз
            p->xPos += offset;
            p->yPos += offset;
        } else {
            // Не нашли свободное место - увеличиваем радиус поиска
            found_free_space = 0;
            offset++; // Java: b++
        }
    }
}

// Уменьшение мяча (портировано из shrinkBall())
void shrink_ball(Player* p) {
    if (p->sizeState == SMALL_SIZE_STATE) return; // Уже маленький
    
    p->sizeState = SMALL_SIZE_STATE;
    p->ballSize = NORMAL_SIZE;
    p->mHalfBallSize = HALF_NORMAL_SIZE;
    
    // Проверка позиции после уменьшения как в оригинале
    int offset = 2;
    if (collisionDetection(p, p->xPos, p->yPos + offset)) {
        p->yPos += offset;
    } else if (collisionDetection(p, p->xPos, p->yPos - offset)) {
        p->yPos -= offset;
    }
    // Если оба направления заняты - остаемся на месте
}

// Лопание мяча (портировано из popBall())
void pop_ball(Player* p) {
    p->ballState = BALL_STATE_POPPED;
    p->xSpeed = 0;
    p->ySpeed = 0;
    
    // Сброс бонусов
    p->speedBonusCntr = 0;
    p->gravBonusCntr = 0;
    p->jumpBonusCntr = 0;
}

// Установка направления (битовые флаги)
// MOVE_DOWN не используется - падение происходит автоматически через гравитацию
void set_direction(Player* p, MoveDirection dir) {
    if (dir == MOVE_LEFT || dir == MOVE_RIGHT || dir == MOVE_UP) {
        p->direction |= (MoveMask)dir;
    }
}

// Сброс направления
// MOVE_DOWN не используется - падение происходит автоматически через гравитацию
void release_direction(Player* p, MoveDirection dir) {
    if (dir == MOVE_LEFT || dir == MOVE_RIGHT || dir == MOVE_UP) {
        p->direction &= (MoveMask)~dir;
    }
}

// Пиксельная коллизия с квадратным тайлом (портировано из Ball.java)
static bool squareCollide(Player* p, int tileRow, int tileCol) {
    int tilePixelX = tileCol * TILE_SIZE;
    int tilePixelY = tileRow * TILE_SIZE;
    
    int relX = p->globalBallX - tilePixelX;
    int relY = p->globalBallY - tilePixelY;
    
    int ballStartX, ballEndX, ballStartY, ballEndY;
    
    if (relX >= 0) {
        ballStartX = relX;
        ballEndX = TILE_SIZE;
    } else {
        ballStartX = 0;
        ballEndX = p->ballSize + relX;
    }
    
    if (relY >= 0) {
        ballStartY = relY;
        ballEndY = TILE_SIZE;
    } else {
        ballStartY = 0;
        ballEndY = p->ballSize + relY;
    }
    
    // Пиксельная проверка коллизии в зависимости от размера мяча
    if (p->ballSize == ENLARGED_SIZE) {
        // Большой мяч 16x16
        if (ballEndX > TILE_SIZE) ballEndX = TILE_SIZE;
        if (ballEndY > TILE_SIZE) ballEndY = TILE_SIZE;
        
        for (int by = ballStartY; by < ballEndY; by++) {
            for (int bx = ballStartX; bx < ballEndX; bx++) {
                int ballY = by - relY;
                int ballX = bx - relX;
                if (ballY >= 0 && ballY < ENLARGED_SIZE && ballX >= 0 && ballX < ENLARGED_SIZE) {
                    if (LARGE_BALL_DATA[ballY][ballX] != 0) {
                        return true;
                    }
                }
            }
        }
    } else {
        // Маленький мяч
        if (ballEndX > TILE_SIZE) ballEndX = TILE_SIZE;
        if (ballEndY > TILE_SIZE) ballEndY = TILE_SIZE;
        
        for (int by = ballStartY; by < ballEndY; by++) {
            for (int bx = ballStartX; bx < ballEndX; bx++) {
                int ballY = by - relY;
                int ballX = bx - relX;
                if (ballY >= 0 && ballY < NORMAL_SIZE && ballX >= 0 && ballX < NORMAL_SIZE) {
                    if (SMALL_BALL_DATA[ballY][ballX] != 0) {
                        return true;
                    }
                }
            }
        }
    }
    
    return false;
}

// Коллизия с треугольной рампой (портировано из Ball.java)
static bool triangleCollide(Player* p, int tileRow, int tileCol, int tileID) {
    int tilePixelX = tileCol * TILE_SIZE;
    int tilePixelY = tileRow * TILE_SIZE;
    
    int relX = p->globalBallX - tilePixelX;
    int relY = p->globalBallY - tilePixelY;
    
    // Получаем метаданные тайла для определения offset
    const TileMeta* meta = &tile_meta_db()[tileID];
    int offsetX = 0, offsetY = 0;
    
    // Определяем смещения на основе ориентации из метаданных
    switch (meta->orientation) {
        case ORIENT_TL:  // Top-Left: (30,34) 
            offsetX = 11; offsetY = 11;
            break;
        case ORIENT_TR:  // Top-Right: (31,35)
            offsetX = 0; offsetY = 11;
            break;
        case ORIENT_BL:  // Bottom-Left: (33,37)
            offsetX = 11; offsetY = 0;
            break;
        case ORIENT_BR:  // Bottom-Right: (32,36) 
            offsetX = 0; offsetY = 0;
            break;
        default:
            // Для остальных ориентаций offset = (0,0)
            break;
    }
    
    int ballStartX, ballEndX, ballStartY, ballEndY;
    
    if (relX >= 0) {
        ballStartX = relX;
        ballEndX = TILE_SIZE;
    } else {
        ballStartX = 0;
        ballEndX = p->ballSize + relX;
    }
    
    if (relY >= 0) {
        ballStartY = relY;
        ballEndY = TILE_SIZE;
    } else {
        ballStartY = 0;
        ballEndY = p->ballSize + relY;
    }
    
    // Выбор данных мяча в зависимости от размера
    const uint8_t *ballData;
    int ballDataSize;
    if (p->ballSize == ENLARGED_SIZE) {
        ballData = (const uint8_t *)LARGE_BALL_DATA;
        ballDataSize = ENLARGED_SIZE;
    } else {
        ballData = (const uint8_t *)SMALL_BALL_DATA;
        ballDataSize = NORMAL_SIZE;
    }
    
    // Ограничение границ
    if (ballEndX > TILE_SIZE) ballEndX = TILE_SIZE;
    if (ballEndY > TILE_SIZE) ballEndY = TILE_SIZE;
    
    // Пиксельная проверка коллизии
    for (int by = ballStartY; by < ballEndY; by++) {
        for (int bx = ballStartX; bx < ballEndX; bx++) {
            int ballY = by - relY;
            int ballX = bx - relX;
            
            // Проверка границ массива мяча
            if (ballY >= 0 && ballY < ballDataSize && ballX >= 0 && ballX < ballDataSize) {
                // Треугольная коллизия: TRI_TILE_DATA & ballData
                int triY = abs(by - offsetY);
                int triX = abs(bx - offsetX);
                
                if (triY < 12 && triX < 12) {
                    int ballDataIndex = ballY * ballDataSize + ballX;
                    if ((TRI_TILE_DATA[triY][triX] & ballData[ballDataIndex]) != 0) {
                        if (!p->mGroundedFlag) {
                            redirectBall(p, tileID);
                        }
                        return true;
                    }
                }
            }
        }
    }
    
    return false;
}

// Перенаправление мяча при столкновении с рампой (портировано из Ball.java)
static void redirectBall(Player* p, int tileID) {
    int oldXSpeed = p->xSpeed;
    
    switch (tileID) {
        case 35:
        case 37:
            // Поворот на 90°: (x,y) -> (y,x)
            p->xSpeed = p->ySpeed;
            p->ySpeed = oldXSpeed;
            break;
            
        case 31:
        case 33:
            // Поворот на 90° с уменьшением пополам: (x,y) -> (y/2, x/2)
            p->xSpeed = p->ySpeed >> 1;
            p->ySpeed = oldXSpeed >> 1;
            break;
            
        case 34:
        case 36:
            // Отражение с поворотом: (x,y) -> (-y, -x)
            p->xSpeed = -p->ySpeed;
            p->ySpeed = -oldXSpeed;
            break;
            
        case 30:
        case 32:
            // Отражение с поворотом и уменьшением: (x,y) -> (-y/2, -x/2)
            p->xSpeed = -(p->ySpeed >> 1);
            p->ySpeed = -(oldXSpeed >> 1);
            break;
            
        default:
            // На всякий случай - если неизвестный тайл, останавливаем
            p->xSpeed = 0;
            p->ySpeed = 0;
            break;
    }
}

// Полная функция проверки коллизий (портировано из Ball.java)
static bool collisionDetection(Player* p, int testX, int testY) {
    // Временно обновляем глобальные координаты для тестирования
    int oldGlobalX = p->globalBallX;
    int oldGlobalY = p->globalBallY;
    p->globalBallX = testX;
    p->globalBallY = testY;
    
    // Проверка границ уровня
    int levelW = g_level.width * TILE_SIZE;
    int levelH = g_level.height * TILE_SIZE;
    
    if (testX < 0 || testY < 0 || testX + p->ballSize > levelW || testY + p->ballSize > levelH) {
        p->globalBallX = oldGlobalX;
        p->globalBallY = oldGlobalY;
        return false; // За границами - коллизия
    }
    
    // Определяем диапазон тайлов для проверки
    int startTileX = testX / TILE_SIZE;
    int endTileX = (testX + p->ballSize - 1) / TILE_SIZE;
    int startTileY = testY / TILE_SIZE;
    int endTileY = (testY + p->ballSize - 1) / TILE_SIZE;
    
    bool canMove = true;
    
    // Сброс флагов коллизии
    p->mCDRubberFlag = false;
    p->mCDRampFlag = false;
    
    // Проверяем все пересекающиеся тайлы
    for (int tileY = startTileY; tileY <= endTileY && canMove; tileY++) {
        for (int tileX = startTileX; tileX <= endTileX && canMove; tileX++) {
            canMove = testTile(p, tileY, tileX, canMove);
        }
    }
    
    
    // Восстанавливаем старые глобальные координаты
    p->globalBallX = oldGlobalX;
    p->globalBallY = oldGlobalY;
    
    return canMove;
}

// Проверка конкретного тайла (портировано из Ball.java testTile)
static bool testTile(Player* p, int tileY, int tileX, bool canMove) {
    if (tileY >= g_level.height || tileY < 0 || tileX >= g_level.width || tileX < 0) {
        return false;  // За пределами карты - коллизия
    }
    
    if (p->ballState == BALL_STATE_POPPED) {
        return true;  // Лопнувший мяч проходит сквозь все
    }
    
    int tile = g_level.tileMap[tileY][tileX];
    int tileID = tile & TILE_ID_MASK;  // Убираем флаги
    
    // Получаем метаданные тайла
    if ((uint32_t)tileID >= tile_meta_count()) {
        return canMove; // Неизвестный тайл - пропускаем
    }
    
    const TileMeta* tileMeta = &tile_meta_db()[tileID];
    
    p->mCDRampFlag = false;
    
    // Используем новую систему типов коллизии
    switch (tileMeta->collision_type) {
        case COLLISION_NONE: // Проходимые тайлы
            break;
            
        case COLLISION_SOLID: // Полная коллизия
            if (squareCollide(p, tileY, tileX)) {
                canMove = false;
                
                // Проверяем логику поведения для резиновых блоков
                if (tileMeta->logic == LOGIC_RUBBER) {
                    p->mCDRubberFlag = true;
                }
            }
            p->mCDRampFlag = true;
            break;
            
        case COLLISION_ORIENTED: // Ориентированная коллизия
            // Для шипов (cases 3-6), рамп (cases 30-37) и колец (cases 13-28)
            if (tileID >= 3 && tileID <= 6) {
                // Шипы - используют thinCollide с ориентацией
                if (thinCollide(p, tileY, tileX, tileID)) {
                    canMove = false;
                    // TODO: Добавить popBall() для LOGIC_HAZARD когда будет реализована система смерти
                }
            } else if (tileID == 10) {
                // Движущиеся шипы - коллизия 24x24 с движущимся объектом
                int objIndex = level_find_moving_object_at(tileX, tileY);
                if (objIndex != -1) {
                    MovingObject* obj = level_get_moving_object(objIndex);
                    if (obj) {
                        // Вычисляем реальные координаты шипов как в Java
                        int spikeX = obj->topLeft[0] * TILE_SIZE + obj->offset[0];
                        int spikeY = obj->topLeft[1] * TILE_SIZE + obj->offset[1];
                        
                        // Проверяем пересечение мяча с областью шипов 24x24
                        if (rectCollide(p->globalBallX, p->globalBallY, 
                                       p->globalBallX + p->ballSize, p->globalBallY + p->ballSize,
                                       spikeX, spikeY, spikeX + 24, spikeY + 24)) {
                            canMove = false;
                            // TODO: Добавить popBall() для LOGIC_HAZARD когда будет реализована система смерти
                        }
                    }
                }
            } else if (tileID >= 13 && tileID <= 28) {
                // Кольца - используют thinCollide с специальной логикой
                if (thinCollide(p, tileY, tileX, tileID)) {
                    // Большой мяч не может пройти через маленькие кольца
                    if ((tileID == 13 || tileID == 15 || tileID == 17 || tileID == 19) && p->ballSize == ENLARGED_SIZE) {
                        canMove = false;
                    } else {
                        if (edgeCollide(p, tileY, tileX, tileID)) {
                            canMove = false;
                        }
                        game_add_ring(); // Событие: кольцо собрано
                        // TODO: Смена тайла на "пройденное" и звук
                    }
                }
            } else if (tileID >= 30 && tileID <= 37) {
                // Рампы - используют triangleCollide
                if (triangleCollide(p, tileY, tileX, tileID)) {
                    if (tileMeta->logic == LOGIC_RUBBER) {
                        p->mCDRubberFlag = true;
                    }
                    canMove = false;
                }
                p->mCDRampFlag = true;
            }
            break;
    }
    
    // Специальная логика для specific тайлов (не зависит от коллизии)
    switch (tileID) {
            
        // Тайл бонуса скорости
        case TILE_SPEED_BONUS:
            canMove = false; // Java: paramBoolean = false
            p->speedBonusCntr = BONUS_DURATION; // Java: this.speedBonusCntr = 300
            // TODO: Добавить звук подбора
            break;
            
        // Тайлы уменьшения мяча (deflator) - блокируют движение
        case 39: case 40: case 41: case 42: // ID_DEFLATOR_*
            canMove = false; // Java: paramBoolean = false
            if (p->ballSize == ENLARGED_SIZE) { // Java: только большой мяч
                shrink_ball(p);
            }
            break;
            
        // Тайлы увеличения мяча (inflator) - блокируют движение
        case 43: case 44: case 45: case 46: // ID_INFLATOR_*
            canMove = false; // Java: paramBoolean = false  
            if (p->ballSize == NORMAL_SIZE) { // Java: только маленький мяч
                enlarge_ball(p);
            }
            break;
        
        // Чекпоинт (Java case 7: строки 633-639)
        case TILE_CHECKPOINT:
            game_set_respawn(tileX, tileY);  // Событие: чекпоинт активирован
            break;
            
        // Выход (Java case 9: не блокирует движение, но проверяется отдельно)  
        case TILE_EXIT:
            // Обычно не блокирует движение, проверка exitOpen происходит в другом месте
            break;
            
        // Дополнительная жизнь (Java case 29: строка неизвестна, но есть в TileCanvas)
        case TILE_EXTRA_LIFE:
            game_add_extra_life();  // Событие: дополнительная жизнь собрана
            break;
        
        
        // Бонусы гравитации (Java case 47-50: gravBonusCntr = 300)
        case 47: case 48: case 49: case 50:
            canMove = false; // Java: paramBoolean = false
            p->gravBonusCntr = BONUS_DURATION; // Java: this.gravBonusCntr = 300
            // TODO: Звук подбора
            break;
            
        // Бонусы прыжков (Java case 51-54: jumpBonusCntr = 300)  
        case 51: case 52: case 53: case 54:
            canMove = false; // Java: paramBoolean = false
            p->jumpBonusCntr = BONUS_DURATION; // Java: this.jumpBonusCntr = 300
            // TODO: Звук подбора
            break;
        
        default:
            // Остальные неизвестные тайлы пропускаем (как пустые)
            break;
    }
    
    return canMove;  // Возвращаем текущее состояние
}


// Полностью портированная физика из Ball.java (100% Java-совместимая)
void player_update(Player* p) {
    if (p->ballState == BALL_STATE_POPPED) return;
    
    // Обновление глобальных координат для пиксельной коллизии
    p->globalBallX = p->xPos;
    p->globalBallY = p->yPos;
    
    // Определение параметров гравитации (точно как в Java 915-937)
    int gravity, gravityStep;
    bool reverseGrav = false;
    
    // Проверка флага воды по левому верхнему углу мяча (Java 898-899: m = xPos/12, n = yPos/12)
    int tileX = p->xPos / TILE_SIZE;  // Соответствует Java m = this.xPos / 12
    int tileY = p->yPos / TILE_SIZE;  // Соответствует Java n = this.yPos / 12
    
    if (tileX >= 0 && tileX < g_level.width && tileY >= 0 && tileY < g_level.height) {
        int tile = g_level.tileMap[tileY][tileX];
        p->isInWater = (tile & TILE_FLAG_WATER) ? true : false;
    } else {
        p->isInWater = false;
    }
    
    // Установка гравитации в зависимости от воды и размера (Java 916-937)
    if (p->isInWater) {
        if (p->ballSize == ENLARGED_SIZE) {
            gravity = -30;  // k = -30 (всплывает)
            gravityStep = -2; // j = -2
            if (p->mGroundedFlag) {
                p->ySpeed = -10; // Java 921: this.ySpeed = -10;
            }
        } else {
            gravity = 42;   // k = 42
            gravityStep = 6; // j = 6
        }
    } else {
        if (p->ballSize == ENLARGED_SIZE) {
            gravity = 38;   // k = 38
            gravityStep = 3; // j = 3
        } else {
            gravity = 80;   // k = 80
            gravityStep = 4; // j = 4
        }
    }
    
    // Бонус обратной гравитации (Java 940-951)
    if (p->gravBonusCntr > 0) {
        reverseGrav = true;
        gravity *= -1;
        gravityStep *= -1;
        p->gravBonusCntr--;
        if (p->gravBonusCntr == 0) {
            reverseGrav = false;
            p->mGroundedFlag = false;
            gravity *= -1;
            gravityStep *= -1;
        }
    }
    
    // Бонус прыжка (Java 953-962)
    if (p->jumpBonusCntr > 0) {
        if (-1 * abs(p->jumpOffset) > JUMP_BONUS_STRENGTH) {
            if (reverseGrav) {
                p->jumpOffset = -JUMP_BONUS_STRENGTH;
            } else {
                p->jumpOffset = JUMP_BONUS_STRENGTH;
            }
        }
        p->jumpBonusCntr--;
    }
    
    // Счётчик скольжения (Java 964-967)
    p->slideCntr++;
    if (p->slideCntr == 3) {
        p->slideCntr = 0;
    }
    
    // Ограничение скорости (Java 969-978)
    if (p->ySpeed < -150) p->ySpeed = -150;
    else if (p->ySpeed > 150) p->ySpeed = 150;
    if (p->xSpeed < -150) p->xSpeed = -150;
    else if (p->xSpeed > 150) p->xSpeed = 150;
    
    // === ФИЗИКА ПО ОСИ Y === (Java 980-1069)
    int ySteps = abs(p->ySpeed) / 10;
    for (int i = 0; i < ySteps; i++) {
        int yStep = 0;
        if (p->ySpeed != 0) {
            yStep = (p->ySpeed < 0) ? -1 : 1;
        }
        
        // Попытка движения (Java 989)
        if (collisionDetection(p, p->xPos, p->yPos + yStep)) {
            p->yPos += yStep;
            p->mGroundedFlag = false;
            
            // Специальная логика для подводного большого мяча (Java 995-1006)
            if (gravity == -30) { // Подводный большой мяч
                // Java 996: n = this.mCanvas.tileY + this.yPos / 12
                // Пересчитывается только Y, X остаётся фиксированным (m от начала кадра)
                int currentTileY = p->yPos / TILE_SIZE;  // Java: this.yPos / 12
                
                if (currentTileY >= 0 && currentTileY < g_level.height && 
                    tileX >= 0 && tileX < g_level.width) {  // tileX от левого края мяча (как m в Java)
                    int currentTile = g_level.tileMap[currentTileY][tileX];
                    if ((currentTile & TILE_FLAG_WATER) == 0) {
                        // Вышел из воды - замедляемся
                        p->ySpeed >>= 1;
                        if (p->ySpeed <= 10 && p->ySpeed >= -10) {
                            p->ySpeed = 0;
                        }
                    }
                }
            }
        } else {
            // Коллизия - пытаемся скользить по рампе (Java 1011-1025)
            if (p->mCDRampFlag && p->xSpeed < 10 && p->slideCntr == 0) {
                int slideStep = 1;
                if (collisionDetection(p, p->xPos + slideStep, p->yPos + yStep)) {
                    p->xPos += slideStep;
                    p->yPos += yStep;
                    p->mCDRampFlag = false;
                } else if (collisionDetection(p, p->xPos - slideStep, p->yPos + yStep)) {
                    p->xPos -= slideStep;
                    p->yPos += yStep;
                    p->mCDRampFlag = false;
                }
            }
            
            // Отскок от препятствия (Java 1027-1055)
            if (yStep > 0 || (reverseGrav && yStep < 0)) {
                // Отскок от пола/препятствия
                p->ySpeed = p->ySpeed * -1 / 2; // Java: this.ySpeed * -1 / 2
                p->mGroundedFlag = true;
                
                // Резиновый отскок (Java 1032-1042)
                if (p->mCDRubberFlag && (p->direction & MOVE_UP)) {
                    p->mCDRubberFlag = false;
                    if (reverseGrav) {
                        p->jumpOffset += 10;
                    } else {
                        p->jumpOffset += -10;
                    }
                } else if (p->jumpBonusCntr == 0) {
                    p->jumpOffset = 0;
                }
                
                // Нормализация скорости отскока (Java 1046-1051)
                if (p->ySpeed < MIN_BOUNCE_SPEED && p->ySpeed > -MIN_BOUNCE_SPEED) {
                    if (reverseGrav) {
                        p->ySpeed = -MIN_BOUNCE_SPEED;
                    } else {
                        p->ySpeed = MIN_BOUNCE_SPEED;
                    }
                }
                break;
            }
            
            // Удар о потолок (Java 1057-1067)
            if (yStep < 0 || (reverseGrav && yStep > 0)) {
                if (reverseGrav) {
                    p->ySpeed = -ROOF_COLLISION_SPEED;
                } else {
                    p->ySpeed = ROOF_COLLISION_SPEED;
                }
            }
        }
    }
    
    // Применение гравитации (Java 1071-1082)
    if (reverseGrav) {
        if (gravityStep == -2 && p->ySpeed < gravity) { // Подводный большой мяч
            p->ySpeed += gravityStep;
            if (p->ySpeed > gravity) p->ySpeed = gravity;
        } else if (!p->mGroundedFlag && p->ySpeed > gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed < gravity) p->ySpeed = gravity;
        }
    } else {
        if (gravityStep == -2 && p->ySpeed > gravity) { // Подводный большой мяч
            p->ySpeed += gravityStep;
            if (p->ySpeed < gravity) p->ySpeed = gravity;
        } else if (!p->mGroundedFlag && p->ySpeed < gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed > gravity) p->ySpeed = gravity;
        }
    }
    
    // Накопление jumpOffset для большого мяча (Java 1118-1124)
    if (p->ballSize == ENLARGED_SIZE && p->jumpBonusCntr == 0) {
        if (reverseGrav) {
            p->jumpOffset += 5;
        } else {
            p->jumpOffset += -5;
        }
    }
    
    // === УПРАВЛЕНИЕ ГОРИЗОНТАЛЬНЫМ ДВИЖЕНИЕМ === (Java аналог)
    int maxSpeed = (p->speedBonusCntr > 0) ? MAX_HORZ_BONUS_SPEED : MAX_HORZ_SPEED;
    if (p->speedBonusCntr > 0) p->speedBonusCntr--;
    
    if ((p->direction & MOVE_RIGHT) && p->xSpeed < maxSpeed) {
        p->xSpeed += HORZ_ACCELL;
    } else if ((p->direction & MOVE_LEFT) && p->xSpeed > -maxSpeed) {
        p->xSpeed -= HORZ_ACCELL;
    } else if (p->xSpeed > 0) {
        p->xSpeed -= FRICTION_DECELL;
    } else if (p->xSpeed < 0) {
        p->xSpeed += FRICTION_DECELL;
    }
    
    // === ПРЫЖОК ===
    if (p->mGroundedFlag && (p->direction & MOVE_UP)) {
        if (reverseGrav) {
            p->ySpeed = -JUMP_STRENGTH + p->jumpOffset;
        } else {
            p->ySpeed = JUMP_STRENGTH + p->jumpOffset;
        }
        p->mGroundedFlag = false;
    }
    
    // === ФИЗИКА ПО ОСИ X === (Java 1135-1166)
    int xSteps = abs(p->xSpeed) / 10;
    for (int i = 0; i < xSteps; i++) {
        int xStep = 0;
        if (p->xSpeed != 0) {
            xStep = (p->xSpeed < 0) ? -1 : 1;
        }
        
        // Java 1142: обычное движение по X
        if (collisionDetection(p, p->xPos + xStep, p->yPos)) {
            p->xPos += xStep;
        } else if (p->mCDRampFlag) {
            // Java 1144-1164: диагональное скольжение по рампе
            p->mCDRampFlag = false;
            int diagonalStep = reverseGrav ? 1 : -1; // Java: bool ? 1 : -1
            
            // Пробуем диагональ 1: (xStep, diagonalStep)
            if (collisionDetection(p, p->xPos + xStep, p->yPos + diagonalStep)) {
                p->xPos += xStep;
                p->yPos += diagonalStep;
            }
            // Пробуем диагональ 2: (xStep, -diagonalStep) 
            else if (collisionDetection(p, p->xPos + xStep, p->yPos - diagonalStep)) {
                p->xPos += xStep;
                p->yPos -= diagonalStep;
            }
            // Если диагонали не сработали - отскок
            else {
                p->xSpeed = -(p->xSpeed >> 1); // Java 1163
            }
        } else {
            // Обычный отскок без рампы
            if (p->xSpeed != 0) {
                p->xSpeed = -(p->xSpeed >> 1);
            }
            break;
        }
    }
    
    // Границы уровня
    int levelW = g_level.width * TILE_SIZE;
    if (p->xPos < 0) p->xPos = 0;
    if (p->xPos > levelW - p->ballSize) p->xPos = levelW - p->ballSize;
    
    // Сброс флагов (будут установлены в следующем кадре при коллизии)
    p->mCDRubberFlag = false;
    p->mCDRampFlag = false;
}

// Утилита для прямоугольных коллизий (TileCanvas.rectCollide эквивалент)
// Включительная проверка границ как в оригинальной Java ME
static bool rectCollide(int x1, int y1, int x2, int y2, int rx1, int ry1, int rx2, int ry2) {
    return (x1 <= rx2 && x2 >= rx1 && y1 <= ry2 && y2 >= ry1);
}

// Тонкие коллизии универсальные на основе ориентации тайла (улучшенная версия Java thinCollide)
static bool thinCollide(Player* p, int tileRow, int tileCol, int tileID) {
    int tilePixelX = tileCol * TILE_SIZE;  // i в Java
    int tilePixelY = tileRow * TILE_SIZE;  // j в Java
    int tileRight = tilePixelX + TILE_SIZE;  // k в Java
    int tileBottom = tilePixelY + TILE_SIZE; // m в Java
    
    // Получаем метаданные тайла для определения ориентации
    const TileMeta* tileMeta = &tile_meta_db()[tileID];
    
    // Модификация границ на основе ориентации (улучшенная версия Java switch)
    switch (tileMeta->orientation) {
        // Шипы с горизонтально-тонкой коллизией (вверх/вниз)
        case ORIENT_SPIKE_THIN_HORIZ:
            tilePixelX += 4;  // i += 4 (Java case 3,5)
            tileRight -= 4;   // k -= 4
            break;
            
        // Шипы с вертикально-тонкой коллизией (лево/право)
        case ORIENT_SPIKE_THIN_VERT:
            tilePixelY += 4;  // j += 4 (Java case 4,6)
            tileBottom -= 4;  // m -= 4
            break;
            
        // Вертикальные кольца (верхние и нижние части)
        case ORIENT_VERT_TOP:
        case ORIENT_VERT_BOTTOM:
            tilePixelX += 4;  // i += 4
            tileRight -= 4;   // k -= 4
            break;
            
        // Горизонтальные кольца (левые и правые части)
        case ORIENT_HORIZ_LEFT:
        case ORIENT_HORIZ_RIGHT:
            tilePixelY += 4;  // j += 4  
            tileBottom -= 4;  // m -= 4
            break;
            
        // Тайлы без специальной ориентации (например, выход)
        case ORIENT_NONE:
            // Без модификации границ (для case 9 - выход)
            break;
            
        default:
            return false; // Неподдерживаемая ориентация для тонких коллизий
    }
    
    // Проверка пересечения мяча с модифицированным тайлом
    return rectCollide(p->globalBallX, p->globalBallY, 
                      p->globalBallX + p->ballSize, p->globalBallY + p->ballSize,
                      tilePixelX, tilePixelY, tileRight, tileBottom);
}

// Проверка коллизий с краями для колец (портировано из Ball.java edgeCollide) 
static bool edgeCollide(Player* p, int tileRow, int tileCol, int tileID) {
    int tilePixelX = tileCol * TILE_SIZE;
    int tilePixelY = tileRow * TILE_SIZE;
    int tileRight = tilePixelX + TILE_SIZE;
    int tileBottom = tilePixelY + TILE_SIZE;
    
    // Специальная логика для разных типов колец (Java switch 505-580)
    switch (tileID) {
        // Маленькие вертикальные кольца (Java case 13, 17)
        case 13: case 17:
            tilePixelX += 6;
            tileRight -= 6;  
            tileBottom -= 11; // m -= 11
            return rectCollide(p->globalBallX, p->globalBallY,
                              p->globalBallX + p->ballSize, p->globalBallY + p->ballSize,
                              tilePixelX, tilePixelY, tileRight, tileBottom);
            
        // Большие вертикальные кольца (Java case 21, 25)  
        case 21: case 25:
            tileBottom = tilePixelY; // m = j; j--
            tilePixelY--;
            tilePixelX += 6;
            tileRight -= 6;
            return rectCollide(p->globalBallX, p->globalBallY,
                              p->globalBallX + p->ballSize, p->globalBallY + p->ballSize,  
                              tilePixelX, tilePixelY, tileRight, tileBottom);
            
        // Остальные кольца - аналогичная логика
        default:
            return false;
    }
}