#include "game.h"
#include "graphics.h"
#include "input.h"
#include "types.h"
#include "level.h"
#include "png.h"
#include "menu.h"
#include <pspctrl.h>

Game g_game;

// Внешняя ссылка на атлас из level.c
extern texture_t* g_tileset;
extern int g_tiles_per_row;

void game_init(void) {
    g_game.state = STATE_MENU;
    g_game.menu_selection = 0;
    g_game.selected_level = 1;
    g_game.buffered_jump = 0;
    
    // Инициализация меню
    menu_init();
    
    // Попробуем загрузить уровень 1, если не получится - тестовый
    if (!level_load_by_number(1)) {
        // Если нет файла - используем тестовый уровень
        level_create_test_level();
    }
    
    // Инициализация игрока из данных уровня
    player_init(&g_game.player, g_level.startPosX, g_level.startPosY, 
                g_level.ballSize == 0 ? SMALL_SIZE_STATE : LARGE_SIZE_STATE);
}

void game_update(void) {
    switch(g_game.state) {
        case STATE_MENU:
            menu_update();
            break;
            
        case STATE_LEVEL_SELECT:
            level_select_update();
            break;
            
        case STATE_GAME: {
            // Обновление направления из инпута
            Player* p = &g_game.player;
            
            // ВАЖНО: НЕ сбрасываем направления автоматически!
            // Только устанавливаем/сбрасываем по нажатию/отпусканию
            
            // Движение ВЛЕВО
            if(input_held(PSP_CTRL_LEFT)) {
                set_direction(p, MOVE_LEFT);  
            } else {
                release_direction(p, MOVE_LEFT);  // Сбрасываем если НЕ нажато
            }
            
            // Движение ВПРАВО  
            if(input_held(PSP_CTRL_RIGHT)) {
                set_direction(p, MOVE_RIGHT);  
            } else {
                release_direction(p, MOVE_RIGHT);  // Сбрасываем если НЕ нажато
            }
            
            // ПРЫЖОК: проверяем буфер или текущее нажатие
            if(g_game.buffered_jump || input_pressed(PSP_CTRL_CROSS)) {
                set_direction(p, MOVE_UP);
            }
            
            // Обновление физики
            player_update(p);
            
            // ИСПРАВЛЕНИЕ: явно сбрасываем буфер прыжка после обработки
            g_game.buffered_jump = 0;
            
            // Возврат в меню
            if(input_pressed(PSP_CTRL_START)) {
                g_game.state = STATE_MENU;
            }
            
            // ДОБАВЛЕНО: быстрый переход в About
            if(input_pressed(PSP_CTRL_TRIANGLE)) {
                g_game.state = STATE_ABOUT;
            }
            break;
        }
            
        case STATE_ABOUT:
            about_update();
            break;
            
        case STATE_EXIT:
            // Ничего не делаем, выход обрабатывается в main.c
            break;
    }
}

void game_render(void) {
    graphics_clear(0xFFE3D3A2);
    
    switch(g_game.state) {
        case STATE_MENU:
            menu_render();
            break;
            
        case STATE_LEVEL_SELECT:
            level_select_render();
            break;
            
        case STATE_GAME: {
            Player* p = &g_game.player;
            
            // Камера следует за игроком
            int cameraX = p->xPos - SCREEN_WIDTH / 2;
            int cameraY = p->yPos - SCREEN_HEIGHT / 2;
            
            // Ограничиваем камеру границами уровня
            int maxCameraX = g_level.width * TILE_SIZE - SCREEN_WIDTH;
            int maxCameraY = g_level.height * TILE_SIZE - SCREEN_HEIGHT;
            
            if (cameraX < 0) cameraX = 0;
            if (cameraY < 0) cameraY = 0;
            if (cameraX > maxCameraX && maxCameraX > 0) cameraX = maxCameraX;
            if (cameraY > maxCameraY && maxCameraY > 0) cameraY = maxCameraY;
            
            // Рендерим уровень
            level_render_visible_area(cameraX, cameraY, SCREEN_WIDTH, SCREEN_HEIGHT);
            
            // Игрок - позиция относительно камеры
            int playerScreenX = p->xPos - cameraX;
            int playerScreenY = p->yPos - cameraY;
            
            // ИСПРАВЛЕНО: Рисуем спрайт шара вместо цветного квадрата
            if (g_tileset && g_tiles_per_row > 0) {
                int ballSpriteX, ballSpriteY;
                
                if (p->ballState == BALL_STATE_POPPED) {
                    // Лопнувший шар - tileImages[48] = extractImage(image, 0, 1)
                    ballSpriteX = 0 * TILE_SIZE;
                    ballSpriteY = 1 * TILE_SIZE;
                } else if (p->sizeState == LARGE_SIZE_STATE) {
                    // Большой шар - tileImages[49] = createLargeBallImage(extractImage(image, 3, 0))
                    ballSpriteX = 3 * TILE_SIZE;
                    ballSpriteY = 0 * TILE_SIZE;
                } else {
                    // Маленький шар - tileImages[47] = extractImage(image, 2, 0)
                    ballSpriteX = 2 * TILE_SIZE;
                    ballSpriteY = 0 * TILE_SIZE;
                }
                
                sprite_rect_t ballSprite = png_create_sprite_rect(g_tileset, ballSpriteX, ballSpriteY, TILE_SIZE, TILE_SIZE);
                png_draw_sprite(g_tileset, &ballSprite, (float)playerScreenX, (float)playerScreenY, (float)p->ballSize, (float)p->ballSize);
            } else {
                // Фолбэк на цветной квадрат если атлас не загружен
                u32 player_color = 0xFF0000AA; // Синий по умолчанию
                if (!p->mGroundedFlag) {
                    player_color = 0xFFAA0000; // Красный в воздухе
                }
                if (p->gravBonusCntr > 0) {
                    player_color = 0xFFAAAAA; // Серый при обратной гравитации
                }
                if (p->sizeState == LARGE_SIZE_STATE) {
                    player_color = 0xFF00AA00; // Зеленый если большой
                }
                
                graphics_draw_rect(playerScreenX, playerScreenY, p->ballSize, p->ballSize, player_color);
            }
            
            // Инструкции и отладка (поверх всего)
            sceGuDisable(GU_TEXTURE_2D);
    graphics_draw_text(10.0f, 10.0f, "LEFT/RIGHT - move, X - jump, START - menu", 0xFFFFFFFF);

    // Вывод размера карты (HUD) — чёрным, внизу слева
    if (g_level.width > 0 && g_level.height > 0) {
        char level_debug[50];
        level_debug[0] = 'L'; level_debug[1] = 'v'; level_debug[2] = 'l'; level_debug[3] = ':'; level_debug[4] = ' ';
        int pos = 5;
        int w = g_level.width;
        if (w >= 100) { level_debug[pos++] = '0' + (w / 100); w %= 100; }
        if (w >= 10)  { level_debug[pos++] = '0' + (w / 10);  w %= 10; }
        level_debug[pos++] = '0' + w;
        level_debug[pos++] = 'x';
        int h = g_level.height;
        if (h >= 100) { level_debug[pos++] = '0' + (h / 100); h %= 100; }
        if (h >= 10)  { level_debug[pos++] = '0' + (h / 10);  h %= 10; }
        level_debug[pos++] = '0' + h;
        level_debug[pos] = '\0';
        graphics_draw_text(10.0f, 258.0f, level_debug, 0xFF000000);
    }
            graphics_draw_text(10.0f, 30.0f, p->mGroundedFlag ? "GROUNDED" : "AIRBORNE", 0xFFFFFFFF);
            
            // Показать размер мяча
            if (p->sizeState == SMALL_SIZE_STATE) {
                graphics_draw_text(10.0f, 50.0f, "SIZE: NORMAL", 0xFFFFFFFF);
            } else {
                graphics_draw_text(10.0f, 50.0f, "SIZE: LARGE", 0xFFFFFFFF);
            }
            
            // Простая отладка
            if (g_level.width > 0) {
                graphics_draw_text(10.0f, 110.0f, "LEVEL LOADED", 0xFF00FF00);
            } else {
                graphics_draw_text(10.0f, 110.0f, "TEST LEVEL", 0xFFFFFF00);
            }
            
            // Дополнительная подсказка
            graphics_draw_text(300.0f, 250.0f, "TRIANGLE - about", 0xFFFFFFFF);
    // Вернуть режим текстур для остального
    sceGuEnable(GU_TEXTURE_2D);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);

            break;
        }
            
        case STATE_ABOUT:
            about_render();
            break;
            
        case STATE_EXIT:
            // Экран выхода
            graphics_draw_text(200.0f, 120.0f, "EXITING...", 0xFFFFFFFF);
            break;
    }
}

// Добавляем функцию cleanup для game
void game_cleanup(void) {
    menu_cleanup();
}