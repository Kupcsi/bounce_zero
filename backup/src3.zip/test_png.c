// test_png.c - Простой тест PNG модуля
#include "png.h"
#include "graphics.h"
#include <stdio.h>

void test_png_module(void) {
    printf("=== ТЕСТ PNG МОДУЛЯ ===\n");
    
    // Тест 1: Загрузка несуществующего файла (должна создать тестовую текстуру)
    texture_t* test_tex = png_load_texture("nonexistent.png");
    if (test_tex) {
        printf("✓ Тестовая текстура создана: %dx%d\n", test_tex->width, test_tex->height);
        
        // Тест отрисовки
        sprite_rect_t full_sprite = png_create_sprite_rect(test_tex, 0, 0, test_tex->width, test_tex->height);
        
        graphics_start_frame();
        graphics_clear(0xFF000000); // Черный фон
        
        // Рисуем тестовую текстуру в разных местах
        png_draw_sprite(test_tex, &full_sprite, 50, 50, 64, 64);
        png_draw_sprite(test_tex, &full_sprite, 150, 50, 32, 32);
        png_draw_sprite(test_tex, &full_sprite, 250, 50, 128, 64);
        
        // Тест частичных спрайтов
        sprite_rect_t quarter = png_create_sprite_rect(test_tex, 0, 0, test_tex->width/2, test_tex->height/2);
        png_draw_sprite(test_tex, &quarter, 350, 100, 64, 64);
        
        graphics_draw_text(50, 150, "PNG TEST: Should see checkerboard patterns", 0xFFFFFFFF);
        graphics_draw_text(50, 170, "If you see this text but no textures,", 0xFFFFFFFF);
        graphics_draw_text(50, 190, "there is a problem with texture rendering", 0xFFFFFFFF);
        
        graphics_end_frame();
        
        png_free_texture(test_tex);
        printf("✓ Тест отрисовки выполнен\n");
    } else {
        printf("✗ Ошибка создания тестовой текстуры\n");
    }
    
    // Тест 2: Попытка загрузить реальный PNG (если есть)
    texture_t* real_tex = png_load_texture("icons/objects_nm.png");
    if (real_tex) {
        printf("✓ Реальный PNG загружен: %dx%d (актуальный: %dx%d)\n", 
               real_tex->width, real_tex->height,
               real_tex->actual_width, real_tex->actual_height);
        png_free_texture(real_tex);
    } else {
        printf("! Реальный PNG не найден (это нормально для теста)\n");
    }
    
    printf("=== ТЕСТ ЗАВЕРШЕН ===\n");
}

// Вызовите эту функцию из main.c для тестирования:
// test_png_module();