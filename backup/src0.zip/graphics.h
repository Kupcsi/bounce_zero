#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <psptypes.h>

void graphics_init(void);
void graphics_shutdown(void);
void graphics_start_frame(void);
void graphics_end_frame(void);
void graphics_clear(u32 color);
void graphics_draw_rect(float x, float y, float w, float h, u32 color);
void graphics_draw_text(float x, float y, const char* text, u32 color);
void graphics_draw_text_scaled(float x, float y, const char* text, u32 color, float scale);
float graphics_measure_text(const char* text, float scale);

#endif