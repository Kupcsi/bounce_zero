// png.c - НАСТОЯЩАЯ загрузка PNG файлов
#include "png.h"
#include <pspgu.h>
#include <pspkernel.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

// Включаем stb_image для загрузки PNG
#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO  // Используем свои функции чтения файлов
#define STBI_ONLY_PNG  // Только PNG поддержка
#include "stb_image.h"

// Структура для передачи данных файла в stb_image
typedef struct {
    unsigned char* data;
    int size;
    int pos;
} MemoryBuffer;

// Функция чтения для stb_image
static int read_func(void* user, char* data, int size) {
    MemoryBuffer* buffer = (MemoryBuffer*)user;
    if (buffer->pos + size > buffer->size) {
        size = buffer->size - buffer->pos;
    }
    if (size <= 0) return 0;
    
    memcpy(data, buffer->data + buffer->pos, size);
    buffer->pos += size;
    return size;
}

// Функция пропуска для stb_image
static void skip_func(void* user, int n) {
    MemoryBuffer* buffer = (MemoryBuffer*)user;
    buffer->pos += n;
    if (buffer->pos > buffer->size) {
        buffer->pos = buffer->size;
    }
}

// Функция проверки конца файла для stb_image
static int eof_func(void* user) {
    MemoryBuffer* buffer = (MemoryBuffer*)user;
    return buffer->pos >= buffer->size;
}

texture_t* png_load_texture(const char* path) {
    // Открываем файл
    FILE* file = fopen(path, "rb");
    
    if (!file) {
        // Пробуем альтернативные пути
        char alt_path[512];
        snprintf(alt_path, sizeof(alt_path), "/%s", path);
        file = fopen(alt_path, "rb");
        
        if (!file) {
            snprintf(alt_path, sizeof(alt_path), "./%s", path);
            file = fopen(alt_path, "rb");
        }
        
        if (!file) {
            printf("PNG file not found: %s\n", path);
            return NULL;
        }
    }
    
    // Читаем весь файл в память
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    if (file_size <= 0) {
        fclose(file);
        printf("PNG file is empty: %s\n", path);
        return NULL;
    }
    
    unsigned char* file_data = (unsigned char*)malloc(file_size);
    if (!file_data) {
        fclose(file);
        printf("Failed to allocate memory for PNG file\n");
        return NULL;
    }
    
    size_t read_bytes = fread(file_data, 1, file_size, file);
    fclose(file);
    
    if (read_bytes != (size_t)file_size) {
        free(file_data);
        printf("Failed to read PNG file completely\n");
        return NULL;
    }
    
    // Настраиваем буфер для stb_image
    MemoryBuffer buffer;
    buffer.data = file_data;
    buffer.size = file_size;
    buffer.pos = 0;
    
    stbi_io_callbacks callbacks;
    callbacks.read = read_func;
    callbacks.skip = skip_func;
    callbacks.eof = eof_func;
    
    // Загружаем PNG через stb_image
    int width, height, channels;
    unsigned char* image_data = stbi_load_from_callbacks(&callbacks, &buffer, &width, &height, &channels, 4);
    
    free(file_data);
    
    if (!image_data) {
        printf("Failed to load PNG: %s (stbi error: %s)\n", path, stbi_failure_reason());
        return NULL;
    }
    
    printf("Loaded PNG: %s (%dx%d, %d channels)\n", path, width, height, channels);
    
    // Создаем текстуру
    texture_t* tex = (texture_t*)malloc(sizeof(texture_t));
    if (!tex) {
        stbi_image_free(image_data);
        return NULL;
    }
    
    // Округляем размеры до степени двойки (требование PSP)
    int tex_width = 1;
    int tex_height = 1;
    while (tex_width < width) tex_width <<= 1;
    while (tex_height < height) tex_height <<= 1;
    
    tex->width = tex_width;
    tex->height = tex_height;
    tex->actual_width = width;
    tex->actual_height = height;
    tex->format = GU_PSM_8888;
    
    // Выделяем память для текстуры
    size_t tex_size = tex_width * tex_height * 4;
    tex->data = memalign(16, tex_size);
    if (!tex->data) {
        free(tex);
        stbi_image_free(image_data);
        return NULL;
    }
    
    // Очищаем память текстуры
    memset(tex->data, 0, tex_size);
    
    // Копируем данные изображения в текстуру
    unsigned char* dest = (unsigned char*)tex->data;
    
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int src_idx = (y * width + x) * 4;
            int dst_idx = (y * tex_width + x) * 4;
            
            // Конвертируем RGBA -> ABGR (формат PSP) - ИСПРАВЛЕНО
            dest[dst_idx + 0] = image_data[src_idx + 0]; // R
            dest[dst_idx + 1] = image_data[src_idx + 1]; // G
            dest[dst_idx + 2] = image_data[src_idx + 2]; // B
            dest[dst_idx + 3] = image_data[src_idx + 3]; // A
        }
    }
    
    stbi_image_free(image_data);
    sceKernelDcacheWritebackInvalidateAll();
    
    printf("PNG texture created: %dx%d (actual: %dx%d)\n", tex_width, tex_height, width, height);
    return tex;
}

sprite_rect_t png_create_sprite_rect(texture_t* tex, int x, int y, int w, int h) {
    sprite_rect_t rect;
    if (!tex || tex->width == 0 || tex->height == 0) {
        rect.u = 0.0f;
        rect.v = 0.0f;
        rect.width = 1.0f;
        rect.height = 1.0f;
        return rect;
    }
    
    rect.u = (float)x / (float)tex->width;
    rect.v = (float)y / (float)tex->height;
    rect.width  = (float)w / (float)tex->width;
    rect.height = (float)h / (float)tex->height;
    return rect;
}

void png_draw_sprite(texture_t* tex, sprite_rect_t* sprite, float x, float y, float w, float h) {
    if (!tex || !sprite || !tex->data) return;
    if (tex->width <= 0 || tex->height <= 0) return;
    if (w <= 0 || h <= 0) return;
    
    typedef struct {
        float u, v;
        unsigned int color;
        float x, y, z;
    } TextureVertex;

    TextureVertex* vertices = (TextureVertex*)sceGuGetMemory(2 * sizeof(TextureVertex));
    if (!vertices) return;

    float u1 = sprite->u * (float)tex->width;
    float v1 = sprite->v * (float)tex->height;
    float u2 = (sprite->u + sprite->width) * (float)tex->width;
    float v2 = (sprite->v + sprite->height) * (float)tex->height;
    
    if (u1 < 0) u1 = 0;
    if (v1 < 0) v1 = 0;
    if (u2 > tex->width) u2 = tex->width;
    if (v2 > tex->height) v2 = tex->height;

    vertices[0].u = u1;
    vertices[0].v = v1;
    vertices[0].color = 0xffffffff;
    vertices[0].x = x;
    vertices[0].y = y;
    vertices[0].z = 0.0f;

    vertices[1].u = u2;
    vertices[1].v = v2;
    vertices[1].color = 0xffffffff;
    vertices[1].x = x + w;
    vertices[1].y = y + h;
    vertices[1].z = 0.0f;

    // ИСПРАВЛЕНО: Правильная настройка альфа-блендинга для прозрачности
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
    
    // Настройка текстуры
    sceGuTexMode(tex->format, 0, 0, 0);
    sceGuTexImage(0, tex->width, tex->height, tex->width, tex->data);
    sceGuTexFunc(GU_TFX_MODULATE, GU_TCC_RGBA);  // ИЗМЕНЕНО: MODULATE вместо REPLACE
    sceGuTexFilter(GU_NEAREST, GU_NEAREST);
    sceGuTexWrap(GU_CLAMP, GU_CLAMP);
    
    sceGuEnable(GU_TEXTURE_2D);
    sceGuDrawArray(GU_SPRITES, 
                   GU_TEXTURE_32BITF|GU_COLOR_8888|GU_VERTEX_32BITF|GU_TRANSFORM_2D, 
                   2, 0, vertices);
    sceGuDisable(GU_TEXTURE_2D);
    
    // ВАЖНО: НЕ отключаем блендинг здесь - оставляем для других спрайтов
}

void png_free_texture(texture_t* tex) {
    if (!tex) return;
    if (tex->data) {
        free(tex->data);
        tex->data = NULL;
    }
    free(tex);
}