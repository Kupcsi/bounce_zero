#ifndef MENU_H
#define MENU_H

#include "types.h"

// Инициализация меню (загрузка текстур и т.д.)
void menu_init(void);

// Обновление логики меню (обработка input)
void menu_update(void);

// Рендеринг меню
void menu_render(void);

// Обновление экрана выбора уровня
void level_select_update(void);

// Рендеринг экрана выбора уровня
void level_select_render(void);

// Обновление about экрана
void about_update(void);

// Рендеринг about экрана  
void about_render(void);

// Очистка ресурсов меню
void menu_cleanup(void);

#endif