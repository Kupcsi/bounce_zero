#include "input.h"

static SceCtrlData pad;
static SceCtrlData old_pad;

void input_init(void) {
    sceCtrlSetSamplingCycle(0);
    sceCtrlSetSamplingMode(PSP_CTRL_MODE_ANALOG);
}

void input_update(void) {
    old_pad = pad;
    sceCtrlReadBufferPositive(&pad, 1);
}

int input_pressed(int button) {
    return (pad.Buttons & button) && !(old_pad.Buttons & button);
}

int input_held(int button) {
    return (pad.Buttons & button);
}