#ifndef GAME_TYPES_H
#define GAME_TYPES_H

#include "bounce_const.h"
#include "png.h"
#include <stdint.h>

// Forward declarations
typedef struct Ball Ball;
typedef struct BounceCanvas BounceCanvas;
typedef struct MovingObj MovingObj;

// Тайловая карта (аналог TileCanvas полей из Java)
typedef struct {
    int16_t** tile_map;           // tileMap[row][col] - основная карта тайлов
    int tile_map_width;           // mTileMapWidth
    int tile_map_height;          // mTileMapHeight
    int total_num_rings;          // mTotalNumRings
    
    // Позиции и настройки уровня
    int start_pos_x, start_pos_y; // mStartPosX, mStartPosY
    int ball_size;                // mBallSize
    int exit_pos_x, exit_pos_y;   // mExitPosX, mExitPosY
    int level_num;                // mLevelNum
    
    // Движущиеся объекты
    int num_move_obj;             // mNumMoveObj
    MovingObj* moving_objs;       // Массив движущихся объектов
} TileMap;

// Движущиеся объекты (шипы) - аналог mMO* полей из TileCanvas.java
typedef struct MovingObj {
    int16_t top_left[2];    // mMOTopLeft[i][X/Y]
    int16_t bot_right[2];   // mMOBotRight[i][X/Y] 
    int16_t direction[2];   // mMODirection[i][X/Y]
    int16_t offset[2];      // mMOOffset[i][X/Y]
    texture_t* img_ptr;     // mMOImgPtr[i]
} MovingObj;

// Состояние мяча (аналог Ball.java полей)
typedef struct Ball {
    // Позиция и движение
    int x_pos, y_pos;             // xPos, yPos
    int global_ball_x, global_ball_y; // globalBallX, globalBallY
    int x_offset;                 // xOffset
    int x_speed, y_speed;         // xSpeed, ySpeed
    int direction;                // direction (битовая маска)
    
    // Размер и состояние
    int ball_size;                // ballSize
    int half_ball_size;           // mHalfBallSize
    int ball_state;               // ballState
    int respawn_x, respawn_y;     // respawnX, respawnY
    
    // Физика и бонусы
    int jump_offset;              // jumpOffset
    int speed_bonus_cntr;         // speedBonusCntr
    int grav_bonus_cntr;          // gravBonusCntr
    int jump_bonus_cntr;          // jumpBonusCntr
    int grounded_flag;            // mGroundedFlag (bool -> int)
    int cd_rubber_flag;           // mCDRubberFlag
    int cd_ramp_flag;             // mCDRampFlag
    int slide_cntr;               // slideCntr
    int pop_cntr;                 // popCntr (из метода popBall)
    
    // Ссылка на canvas
    BounceCanvas* canvas;         // mCanvas
    
    // Изображения
    texture_t* ball_image;        // ballImage
    texture_t* popped_image;      // poppedImage
    texture_t* large_ball_image;  // largeBallImage
    texture_t* small_ball_image;  // smallBallImage
} Ball;

// Буфер и скроллинг (аналог TileCanvas буферных полей)
typedef struct {
    // Позиции тайлов и скроллинг
    int tile_x, tile_y;           // tileX, tileY
    int div_tile_x, div_tile_y;   // divTileX, divTileY
    int divisor_line;             // divisorLine
    int right_draw_edge, left_draw_edge; // rightDrawEdge, leftDrawEdge
    int scroll_flag;              // scrollFlag (bool -> int)
    int scroll_offset;            // scrollOffset
    
    // Буферы
    texture_t* buffer;            // buffer (Image -> texture_t*)
    texture_t* full_screen_buffer; // mFullScreenBuffer
    
    // Выход
    int exit_pos;                 // mExitPos
    int open_exit_flag;           // mOpenExitFlag
    int open_flag;                // mOpenFlag
    texture_t* exit_tile_image;   // mExitTileImage
    int image_offset;             // mImageOffset
} GameBuffer;

// Основное состояние игры (аналог BounceCanvas полей)
typedef struct BounceCanvas {
    // Игровое состояние
    int num_rings;                // numRings
    int num_lives;                // numLives
    int score;                    // mScore
    int bonus_cntr_value;         // bonusCntrValue
    int level_dis_cntr;           // mLevelDisCntr
    int exit_flag;                // mExitFlag
    int paint_ui_flag;            // mPaintUIFlag
    int invincible;               // mInvincible (чит)
    
    // Сплэш
    int splash_index;             // mSplashIndex
    texture_t* splash_image;      // mSplashImage
    int splash_timer;             // mSplashTimer
    
    // Уровень и данные
    TileMap* tile_map;            // Указатель на загруженную карту
    Ball* ball;                   // Указатель на мяч
    GameBuffer* game_buffer;      // Указатель на буферы
    
    // Изображения UI
    texture_t* ui_life;           // mUILife
    texture_t* ui_ring;           // mUIRing
    texture_t* tile_images[MAX_TILE_IMAGES]; // tileImages[]
    
    // Звуки (указатели на "звуковые объекты")
    void* sound_hoop;             // mSoundHoop
    void* sound_pickup;           // mSoundPickup
    void* sound_pop;              // mSoundPop
} BounceCanvas;

#endif // GAME_TYPES_H
