#include "png.h"
#include "fs.h"
#include <pspgu.h>
#include <pspkernel.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

// Include stb_image for PNG loading
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

/* Load PNG entirely via fs + stbi_load_from_memory */
texture_t* png_load_texture(const char* path) {
    if (!path) {
        printf("png_load_texture: null path\n");
        return NULL;
    }

    // Open resource via fs
    res_handle_t h = res_open(path);
    if (h < 0) {
        printf("png_load_texture: res_open failed for %s\n", path);
        return NULL;
    }

    int fsize = res_size(h);
    if (fsize <= 0) {
        printf("png_load_texture: invalid file size for %s\n", path);
        res_close(h);
        return NULL;
    }

    // Read full file into a temporary buffer
    unsigned char* filebuf = (unsigned char*)malloc(fsize);
    if (!filebuf) {
        printf("png_load_texture: malloc(%d) failed\n", fsize);
        res_close(h);
        return NULL;
    }
    int rd = res_read_all(h, filebuf, fsize);
    res_close(h);
    if (rd != fsize) {
        printf("png_load_texture: res_read_all read %d/%d bytes\n", rd, fsize);
        free(filebuf);
        return NULL;
    }

    // Decode PNG
    texture_t* tex = (texture_t*)malloc(sizeof(texture_t));
    if (!tex) {
        printf("png_load_texture: texture alloc failed\n");
        free(filebuf);
        return NULL;
    }
    int channels = 0;
    unsigned char* rgba = stbi_load_from_memory(filebuf, fsize, &tex->width, &tex->height, &channels, STBI_rgb_alpha);
    free(filebuf);

    if (!rgba) {
        printf("png_load_texture: stbi_load_from_memory failed: %s\n", stbi_failure_reason());
        free(tex);
        return NULL;
    }

    // Allocate 16-byte aligned buffer for GU
    size_t tex_size = (size_t)tex->width * (size_t)tex->height * 4; // RGBA8
    tex->data = memalign(16, tex_size);
    if (!tex->data) {
        printf("png_load_texture: memalign failed\n");
        stbi_image_free(rgba);
        free(tex);
        return NULL;
    }
    memcpy(tex->data, rgba, tex_size);
    stbi_image_free(rgba);

    tex->actual_width  = tex->width;
    tex->actual_height = tex->height;
    tex->format        = GU_PSM_8888;

    // Ensure cache coherency
    sceKernelDcacheWritebackInvalidateAll();

    printf("png_load_texture: loaded %s (%dx%d)\n", path, tex->width, tex->height);
    return tex;
}

sprite_rect_t png_create_sprite_rect(texture_t* tex, int x, int y, int w, int h) {
    sprite_rect_t rect;
    rect.u = (float)x / (float)tex->width;
    rect.v = (float)y / (float)tex->height;
    rect.width  = (float)w / (float)tex->width;
    rect.height = (float)h / (float)tex->height;
    return rect;
}

void png_draw_sprite(texture_t* tex, sprite_rect_t* sprite, float x, float y, float w, float h) {
    if (!tex || !sprite || !tex->data) return;

    typedef struct {
        float u, v;
        unsigned int colour;
        float x, y, z;
    } TextureVertex;

    TextureVertex* v = (TextureVertex*)sceGuGetMemory(2 * sizeof(TextureVertex));

    v[0].u = (sprite->u) * tex->width;
    v[0].v = (sprite->v) * tex->height;
    v[0].colour = 0xFFFFFFFF;
    v[0].x = x;
    v[0].y = y;
    v[0].z = 0.0f;

    v[1].u = (sprite->u + sprite->width)  * tex->width;
    v[1].v = (sprite->v + sprite->height) * tex->height;
    v[1].colour = 0xFFFFFFFF;
    v[1].x = x + w;
    v[1].y = y + h;
    v[1].z = 0.0f;

    // 2D sprite states
    sceGuDisable(GU_DEPTH_TEST);
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
    sceGuTexMode(GU_PSM_8888, 0, 0, GU_FALSE);
    sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA);
    sceGuTexFilter(GU_NEAREST, GU_NEAREST);
    sceGuTexWrap(GU_CLAMP, GU_CLAMP);
    sceGuTexImage(0, tex->width, tex->height, tex->width, tex->data);
    sceGuEnable(GU_TEXTURE_2D);

    sceGuDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D, 2, 0, v);

    sceGuDisable(GU_TEXTURE_2D);
    sceGuDisable(GU_BLEND);
}

void png_free_texture(texture_t* tex) {
    if (!tex) return;
    if (tex->data) free(tex->data);
    free(tex);
}

