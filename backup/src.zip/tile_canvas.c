#include "tile_canvas.h"
#include "fs.h"
#include <stdio.h>
#include <stdlib.h>

// Global storage for tile atlas and sprites
static texture_t* tile_atlas = NULL;
static sprite_rect_t tile_sprites[MAX_TILE_IMAGES];

// Helper function for image transformations (аналог TileCanvas.manipulateImage)
sprite_rect_t tc_manipulate_image(sprite_rect_t original, int transformation) {
    sprite_rect_t result = original;
    
    // Трансформации через изменение UV координат
    // Оригинальные размеры
    float orig_u = original.u;
    float orig_v = original.v;
    float orig_w = original.width;
    float orig_h = original.height;
    
    switch(transformation) {
        case FLIP_HORIZONTAL: // 0 - отражение по горизонтали
            result.u = orig_u + orig_w;  // Начинаем с правого края
            result.width = -orig_w;      // Отрицательная ширина = отражение
            break;
            
        case FLIP_VERTICAL: // 1 - отражение по вертикали  
            result.v = orig_v + orig_h;  // Начинаем с нижнего края
            result.height = -orig_h;     // Отрицательная высота = отражение
            break;
            
        case FLIP_BOTH: // 2 - отражение по обеим осям
            result.u = orig_u + orig_w;
            result.v = orig_v + orig_h;
            result.width = -orig_w;
            result.height = -orig_h;
            break;
            
        case ROTATE_90: // 3 - поворот на 90° (по часовой стрелке)
            // Для поворота меняем u/v местами и инвертируем
            result.u = orig_v;
            result.v = orig_u + orig_w;
            result.width = orig_h;
            result.height = -orig_w;
            break;
            
        case ROTATE_180: // 4 - поворот на 180°
            result.u = orig_u + orig_w;
            result.v = orig_v + orig_h;
            result.width = -orig_w;
            result.height = -orig_h;
            break;
            
        case ROTATE_270: // 5 - поворот на 270° (против часовой)
            result.u = orig_v + orig_h;
            result.v = orig_u;
            result.width = -orig_h;
            result.height = orig_w;
            break;
            
        default:
            // Без изменений
            break;
    }
    
    return result;
}

/**
 * Load PNG file into GU texture (аналог TileCanvas.loadImage)
 */
texture_t* tc_load_image(const char* path) {
    printf("tc_load_image: Loading %s\n", path);
    
    // Use existing png_load_texture - it already handles everything correctly
    texture_t* texture = png_load_texture(path);
    
    if (texture) {
        printf("tc_load_image: Successfully loaded %dx%d texture\n", 
               texture->width, texture->height);
    } else {
        printf("tc_load_image: Failed to load %s\n", path);
    }
    
    return texture;
}

/**
 * Create sprite rectangle from texture atlas (аналог TileCanvas.extractImage)
 * ИСПРАВЛЕНО: теперь принимает ТАЙЛОВЫЕ координаты как в оригинале
 */
sprite_rect_t tc_extract_image(texture_t* tex, int tile_x, int tile_y) {
    int pixel_x = tile_x * 12;  // Конвертируем тайл в пиксели
    int pixel_y = tile_y * 12;
    return png_create_sprite_rect(tex, pixel_x, pixel_y, 12, 12);
}

/**
 * Create sprite with background color (аналог TileCanvas.extractImageBG)
 * ИСПРАВЛЕНО: теперь принимает ТАЙЛОВЫЕ координаты как в оригинале
 */
sprite_rect_t tc_extract_image_bg(texture_t* tex, int tile_x, int tile_y, uint32_t bg_color) {
    // For now, ignore bg_color - PSP handles transparency differently
    // In future this could be used for water effects (blue tint)
    return tc_extract_image(tex, tile_x, tile_y);
}

/**
 * Load all tile images from atlas (аналог TileCanvas.loadTileImages)
 * ИСПРАВЛЕНО: теперь координаты в тайлах как в Java
 */
int tc_load_tile_images(void) {
    printf("tc_load_tile_images: Loading tile atlas\n");
    
    // Load the main tile atlas
    tile_atlas = tc_load_image("/icons/objects_nm.png");
    if (!tile_atlas) {
        printf("tc_load_tile_images: Failed to load tile atlas\n");
        return -1;
    }
    
    printf("tc_load_tile_images: Creating sprite rectangles for all 67 tiles\n");
    
    // Точное соответствие TileCanvas.java:916-1027 с ТАЙЛОВЫМИ координатами
    
    // IMG_BRICKS_RED_NORMAL = 0, IMG_BRICKS_BLUE_RUBBER = 1
    tile_sprites[0] = tc_extract_image(tile_atlas, 1, 0);  // extractImage(image, 1, 0)
    tile_sprites[1] = tc_extract_image(tile_atlas, 1, 2);  // extractImage(image, 1, 2)
    
    // IMG_SPIKES_UPWARD = 2-5 + WET versions 6-9
    tile_sprites[2] = tc_extract_image_bg(tile_atlas, 0, 3, -5185296);   // extractImageBG(image, 0, 3, -5185296)
    tile_sprites[3] = tc_manipulate_image(tile_sprites[2], FLIP_VERTICAL);         // manipulateImage(tileImages[2], 1)
    tile_sprites[4] = tc_manipulate_image(tile_sprites[2], ROTATE_90);             // manipulateImage(tileImages[2], 3) 
    tile_sprites[5] = tc_manipulate_image(tile_sprites[2], ROTATE_270);            // manipulateImage(tileImages[2], 5)
    
    tile_sprites[6] = tc_extract_image_bg(tile_atlas, 0, 3, -15703888);  // extractImageBG(image, 0, 3, -15703888)
    tile_sprites[7] = tc_manipulate_image(tile_sprites[6], FLIP_VERTICAL);         // manipulateImage(tileImages[6], 1)
    tile_sprites[8] = tc_manipulate_image(tile_sprites[6], ROTATE_90);             // manipulateImage(tileImages[6], 3)
    tile_sprites[9] = tc_manipulate_image(tile_sprites[6], ROTATE_270);            // manipulateImage(tileImages[6], 5)
    
    // IMG_RESPAWN_GEM = 10, IMG_RESPAWN_INDICATOR = 11
    tile_sprites[10] = tc_extract_image(tile_atlas, 0, 4);  // extractImage(image, 0, 4)
    tile_sprites[11] = tc_extract_image(tile_atlas, 3, 4);  // extractImage(image, 3, 4)
    
    // IMG_EXIT = 12 - создается через createExitImage() - пока используем базовый
    tile_sprites[12] = tc_extract_image(tile_atlas, 2, 3);  // extractImage(image, 2, 3)
    
    // IMG_HOOP_ACTIVE_HORIZ_TOP_LEFT_LARGE = 13-16
    tile_sprites[14] = tc_extract_image(tile_atlas, 0, 5);  // extractImage(image, 0, 5)
    tile_sprites[13] = tc_manipulate_image(tile_sprites[14], FLIP_VERTICAL);       // manipulateImage(tileImages[14], 1)
    tile_sprites[15] = tc_manipulate_image(tile_sprites[13], FLIP_HORIZONTAL);     // manipulateImage(tileImages[13], 0)
    tile_sprites[16] = tc_manipulate_image(tile_sprites[14], FLIP_HORIZONTAL);     // manipulateImage(tileImages[14], 0)
    
    // IMG_HOOP_ACTIVE_HORIZ_TOP_LEFT_SMALL = 17-20
    tile_sprites[18] = tc_extract_image(tile_atlas, 1, 5);  // extractImage(image, 1, 5)
    tile_sprites[17] = tc_manipulate_image(tile_sprites[18], FLIP_VERTICAL);       // manipulateImage(tileImages[18], 1)
    tile_sprites[19] = tc_manipulate_image(tile_sprites[17], FLIP_HORIZONTAL);     // manipulateImage(tileImages[17], 0)
    tile_sprites[20] = tc_manipulate_image(tile_sprites[18], FLIP_HORIZONTAL);     // manipulateImage(tileImages[18], 0)
    
    // IMG_HOOP_INACTIVE_HORIZ_TOP_LEFT_LARGE = 21-24
    tile_sprites[22] = tc_extract_image(tile_atlas, 2, 5);  // extractImage(image, 2, 5)
    tile_sprites[21] = tc_manipulate_image(tile_sprites[22], FLIP_VERTICAL);       // manipulateImage(tileImages[22], 1)
    tile_sprites[23] = tc_manipulate_image(tile_sprites[21], FLIP_HORIZONTAL);     // manipulateImage(tileImages[21], 0)
    tile_sprites[24] = tc_manipulate_image(tile_sprites[22], FLIP_HORIZONTAL);     // manipulateImage(tileImages[22], 0)
    
    // IMG_HOOP_INACTIVE_HORIZ_TOP_LEFT_SMALL = 25-28
    tile_sprites[26] = tc_extract_image(tile_atlas, 3, 5);  // extractImage(image, 3, 5)
    tile_sprites[25] = tc_manipulate_image(tile_sprites[26], FLIP_VERTICAL);       // manipulateImage(tileImages[26], 1)
    tile_sprites[27] = tc_manipulate_image(tile_sprites[25], FLIP_HORIZONTAL);     // manipulateImage(tileImages[25], 0)
    tile_sprites[28] = tc_manipulate_image(tile_sprites[26], FLIP_HORIZONTAL);     // manipulateImage(tileImages[26], 0)
    
    // IMG_HOOP_ACTIVE_VERT_TOP_LEFT_LARGE = 29-32
    tile_sprites[29] = tc_manipulate_image(tile_sprites[14], ROTATE_270);          // manipulateImage(tileImages[14], 5)
    tile_sprites[30] = tc_manipulate_image(tile_sprites[29], FLIP_VERTICAL);       // manipulateImage(tileImages[29], 1)
    tile_sprites[31] = tc_manipulate_image(tile_sprites[29], FLIP_HORIZONTAL);     // manipulateImage(tileImages[29], 0)
    tile_sprites[32] = tc_manipulate_image(tile_sprites[30], FLIP_HORIZONTAL);     // manipulateImage(tileImages[30], 0)
    
    // IMG_HOOP_ACTIVE_VERT_TOP_LEFT_SMALL = 33-36
    tile_sprites[33] = tc_manipulate_image(tile_sprites[18], ROTATE_270);          // manipulateImage(tileImages[18], 5)
    tile_sprites[34] = tc_manipulate_image(tile_sprites[33], FLIP_VERTICAL);       // manipulateImage(tileImages[33], 1)
    tile_sprites[35] = tc_manipulate_image(tile_sprites[33], FLIP_HORIZONTAL);     // manipulateImage(tileImages[33], 0)
    tile_sprites[36] = tc_manipulate_image(tile_sprites[34], FLIP_HORIZONTAL);     // manipulateImage(tileImages[34], 0)
    
    // IMG_HOOP_INACTIVE_VERT_TOP_LEFT_LARGE = 37-40
    tile_sprites[37] = tc_manipulate_image(tile_sprites[22], ROTATE_270);          // manipulateImage(tileImages[22], 5)
    tile_sprites[38] = tc_manipulate_image(tile_sprites[37], FLIP_VERTICAL);       // manipulateImage(tileImages[37], 1)
    tile_sprites[39] = tc_manipulate_image(tile_sprites[37], FLIP_HORIZONTAL);     // manipulateImage(tileImages[37], 0)
    tile_sprites[40] = tc_manipulate_image(tile_sprites[38], FLIP_HORIZONTAL);     // manipulateImage(tileImages[38], 0)
    
    // IMG_HOOP_INACTIVE_VERT_TOP_LEFT_SMALL = 41-44  
    tile_sprites[41] = tc_manipulate_image(tile_sprites[26], ROTATE_270);          // manipulateImage(tileImages[26], 5)
    tile_sprites[42] = tc_manipulate_image(tile_sprites[41], FLIP_VERTICAL);       // manipulateImage(tileImages[41], 1)
    tile_sprites[43] = tc_manipulate_image(tile_sprites[41], FLIP_HORIZONTAL);     // manipulateImage(tileImages[41], 0)
    tile_sprites[44] = tc_manipulate_image(tile_sprites[42], FLIP_HORIZONTAL);     // manipulateImage(tileImages[42], 0)
    
    // IMG_EXTRA_LIFE = 45
    tile_sprites[45] = tc_extract_image(tile_atlas, 3, 3);  // extractImage(image, 3, 3)
    
    // IMG_MOVING_SPIKE = 46
    tile_sprites[46] = tc_extract_image(tile_atlas, 1, 3);  // extractImage(image, 1, 3)
    
    // IMG_SMALL_BALL = 47, IMG_POPPED_BALL = 48, IMG_LARGE_BALL = 49
    tile_sprites[47] = tc_extract_image(tile_atlas, 2, 0);  // extractImage(image, 2, 0)
    tile_sprites[48] = tc_extract_image(tile_atlas, 0, 1);  // extractImage(image, 0, 1) 
    // IMG_LARGE_BALL создается через createLargeBallImage() - пока базовый
    tile_sprites[49] = tc_extract_image(tile_atlas, 3, 0);  // extractImage(image, 3, 0)
    
    // IMG_DEFLATOR = 50, IMG_INFLATOR = 51, IMG_GRAVITY = 52, IMG_SPEED = 53, IMG_JUMP = 54
    tile_sprites[50] = tc_extract_image(tile_atlas, 3, 1);  // extractImage(image, 3, 1)
    tile_sprites[51] = tc_extract_image(tile_atlas, 2, 4);  // extractImage(image, 2, 4)
    tile_sprites[52] = tc_extract_image(tile_atlas, 3, 2);  // extractImage(image, 3, 2)
    tile_sprites[53] = tc_extract_image(tile_atlas, 1, 1);  // extractImage(image, 1, 1)
    tile_sprites[54] = tc_extract_image(tile_atlas, 2, 2);  // extractImage(image, 2, 2)
    
    // IMG_TRI_BOT_RIGHT = 55-58 (треугольники)
    tile_sprites[55] = tc_extract_image_bg(tile_atlas, 0, 0, -5185296);   // extractImageBG(image, 0, 0, -5185296)
    tile_sprites[56] = tc_manipulate_image(tile_sprites[55], ROTATE_90);           // manipulateImage(tileImages[55], 3)
    tile_sprites[57] = tc_manipulate_image(tile_sprites[55], ROTATE_180);          // manipulateImage(tileImages[55], 4)
    tile_sprites[58] = tc_manipulate_image(tile_sprites[55], ROTATE_270);          // manipulateImage(tileImages[55], 5)
    
    // IMG_TRI_WET_BOT_RIGHT = 59-62 (мокрые треугольники)
    tile_sprites[59] = tc_extract_image_bg(tile_atlas, 0, 0, -15703888);  // extractImageBG(image, 0, 0, -15703888)
    tile_sprites[60] = tc_manipulate_image(tile_sprites[59], ROTATE_90);           // manipulateImage(tileImages[59], 3)
    tile_sprites[61] = tc_manipulate_image(tile_sprites[59], ROTATE_180);          // manipulateImage(tileImages[59], 4)
    tile_sprites[62] = tc_manipulate_image(tile_sprites[59], ROTATE_270);          // manipulateImage(tileImages[59], 5)
    
    // IMG_TRI_RUBBER_BOT_RIGHT = 63-66 (резиновые треугольники)
    tile_sprites[63] = tc_extract_image(tile_atlas, 0, 2);  // extractImage(image, 0, 2)
    tile_sprites[64] = tc_manipulate_image(tile_sprites[63], ROTATE_90);           // manipulateImage(tileImages[63], 3)
    tile_sprites[65] = tc_manipulate_image(tile_sprites[63], ROTATE_180);          // manipulateImage(tileImages[63], 4)
    tile_sprites[66] = tc_manipulate_image(tile_sprites[63], ROTATE_270);          // manipulateImage(tileImages[63], 5)
    
    printf("tc_load_tile_images: Successfully loaded all %d tile sprites\n", MAX_TILE_IMAGES);
    return 0;
}

/**
 * Get sprite rectangle for tile by index (аналог TileCanvas.getImage)
 */
sprite_rect_t* tc_get_tile_sprite(int tile_id) {
    if (tile_id < 0 || tile_id >= MAX_TILE_IMAGES) {
        printf("tc_get_tile_sprite: Invalid tile ID %d\n", tile_id);
        return NULL;
    }
    
    return &tile_sprites[tile_id];
}

/**
 * Free all loaded tile resources
 */
void tc_cleanup_tiles(void) {
    if (tile_atlas) {
        png_free_texture(tile_atlas);
        tile_atlas = NULL;
    }
    printf("tc_cleanup_tiles: Tile resources freed\n");
}

/* === Added: accessor and draw helper consistent with original game logic === */
texture_t* tc_get_tile_atlas(void) {
    return tile_atlas; /* tile_atlas is defined in this compilation unit */
}

void tc_draw_tile(texture_t* atlas, int tile_id, int x, int y, int size) {
    if (!atlas) return;
    sprite_rect_t* base = tc_get_tile_sprite(tile_id);
    if (!base) return;

    if (tile_id == IMG_MOVING_SPIKE) {
        sprite_rect_t r0   = *base;
        sprite_rect_t r90  = tc_manipulate_image(*base, ROTATE_90);
        sprite_rect_t r180 = tc_manipulate_image(*base, ROTATE_180);
        sprite_rect_t r270 = tc_manipulate_image(*base, ROTATE_270);
        png_draw_sprite(atlas, &r0,   x + 0*size, y + 0*size, size, size);
        png_draw_sprite(atlas, &r90,  x + 1*size, y + 0*size, size, size);
        png_draw_sprite(atlas, &r180, x + 0*size, y + 1*size, size, size);
        png_draw_sprite(atlas, &r270, x + 1*size, y + 1*size, size, size);
        return;
    }

    /* default: draw single tile */
    png_draw_sprite(atlas, base, x, y, size, size);
}

/**
 * Optimized tile drawing - assumes GU states already configured
 */
void tc_draw_tile_optimized(texture_t* atlas, int tile_id, int x, int y, int size) {
    if (!atlas) return;
    sprite_rect_t* base = tc_get_tile_sprite(tile_id);
    if (!base) return;

    // ОПТИМИЗАЦИЯ: рисуем напрямую без настройки состояний GU
    typedef struct {
        float u, v;
        unsigned int colour;
        float x, y, z;
    } TextureVertex;

    TextureVertex* v = (TextureVertex*)sceGuGetMemory(2 * sizeof(TextureVertex));

    v[0].u = (base->u) * atlas->width;
    v[0].v = (base->v) * atlas->height;
    v[0].colour = 0xFFFFFFFF;
    v[0].x = x;
    v[0].y = y;
    v[0].z = 0.0f;

    v[1].u = (base->u + base->width)  * atlas->width;
    v[1].v = (base->v + base->height) * atlas->height;
    v[1].colour = 0xFFFFFFFF;
    v[1].x = x + size;
    v[1].y = y + size;
    v[1].z = 0.0f;

    sceGuDrawArray(GU_SPRITES, GU_COLOR_8888 | GU_TEXTURE_32BITF | GU_VERTEX_32BITF | GU_TRANSFORM_2D, 2, 0, v);
}

/**
 * Convert tile ID to image index (аналог TileCanvas.drawTile switch)
 * @param tile_id Tile ID from level map (ID_BRICK_RED, etc.)
 * @param is_water Water flag for wet tiles
 * @return Image index (IMG_BRICKS_RED_NORMAL, etc.) or -1 for empty space
 */
static int tile_id_to_img_index(int tile_id, int is_water) {
    // Убираем флаги из tile_id
    int clean_id = tile_id & 0xFFFFFFBF & 0xFFFFFF7F;  // убираем WATER_FLAG и DIRTY
    
    switch(clean_id) {
        case ID_EMPTY_SPACE:      return -1;  // Заливка фоном
        case ID_BRICK_RED:        return IMG_BRICKS_RED_NORMAL;    // 1 -> 0
        case ID_BRICK_BLUE:       return IMG_BRICKS_BLUE_RUBBER;   // 2 -> 1
        
        case ID_SPIKE_FLOOR:      // 3
            return is_water ? IMG_SPIKES_WET_UPWARD : IMG_SPIKES_UPWARD;  // 6 : 2
            
        case ID_SPIKE_LEFT_WALL:  // 4
            return is_water ? IMG_SPIKES_WET_RIGHT : IMG_SPIKES_RIGHT;    // 9 : 5
            
        case ID_SPIKE_CEILING:    // 5
            return is_water ? IMG_SPIKES_WET_DOWNWARD : IMG_SPIKES_DOWNWARD; // 7 : 3
            
        case ID_SPIKE_RIGHT_WALL: // 6
            return is_water ? IMG_SPIKES_WET_LEFT : IMG_SPIKES_LEFT;      // 8 : 4
            
        case ID_RESPAWN_GEM:      return IMG_RESPAWN_GEM;         // 7 -> 10
        case ID_RESPAWN_INDICATOR: return IMG_RESPAWN_INDICATOR;  // 8 -> 11
        case ID_EXIT_TILE:        return IMG_EXIT;               // 9 -> 12
        case ID_MOVING_SPIKE_TILE: return IMG_MOVING_SPIKE;      // 10 -> 46
        case ID_EXTRA_LIFE:       return IMG_EXTRA_LIFE;         // 29 -> 45
        
        // Кольца (упрощенно - полный switch огромный)
        case ID_HOOP_ACTIVE_VERT_TOP:     return IMG_HOOP_ACTIVE_VERT_TOP_LEFT_SMALL;    // 13 -> 33
        case ID_HOOP_ACTIVE_VERT_BOTTOM:  return IMG_HOOP_ACTIVE_VERT_BOT_LEFT_SMALL;    // 14 -> 34
        case ID_HOOP_ACTIVE_HORIZ_LEFT:   return IMG_HOOP_ACTIVE_HORIZ_TOP_LEFT_SMALL;   // 15 -> 17
        case ID_HOOP_ACTIVE_HORIZ_RIGHT:  return IMG_HOOP_ACTIVE_HORIZ_TOP_RIGHT_SMALL;  // 16 -> 19
        
        // Треугольники
        case ID_TRIANGLE_TOP_LEFT:     return is_water ? IMG_TRI_WET_TOP_LEFT : IMG_TRI_TOP_LEFT;         // 30
        case ID_TRIANGLE_TOP_RIGHT:    return is_water ? IMG_TRI_WET_TOP_RIGHT : IMG_TRI_TOP_RIGHT;       // 31
        case ID_TRIANGLE_BOT_RIGHT:    return is_water ? IMG_TRI_WET_BOT_RIGHT : IMG_TRI_BOT_RIGHT;       // 32
        case ID_TRIANGLE_BOT_LEFT:     return is_water ? IMG_TRI_WET_BOT_LEFT : IMG_TRI_BOT_LEFT;         // 33
        
        case ID_RUBBER_TRIANGLE_TOP_LEFT:   return IMG_TRI_RUBBER_TOP_LEFT;   // 34 -> 65
        case ID_RUBBER_TRIANGLE_TOP_RIGHT:  return IMG_TRI_RUBBER_TOP_RIGHT;  // 35 -> 64
        case ID_RUBBER_TRIANGLE_BOT_RIGHT:  return IMG_TRI_RUBBER_BOT_RIGHT;  // 36 -> 63
        case ID_RUBBER_TRIANGLE_BOT_LEFT:   return IMG_TRI_RUBBER_BOT_LEFT;   // 37 -> 66
        
        case ID_SPEED:            return IMG_SPEED;     // 38 -> 53
        case ID_DEFLATOR_FLOOR:   return IMG_DEFLATOR;  // 39 -> 50
        case ID_INFLATOR_FLOOR:   return IMG_INFLATOR;  // 43 -> 51
        case ID_GRAVITY_FLOOR:    return IMG_GRAVITY;   // 47 -> 52
        case ID_JUMP_FLOOR:       return IMG_JUMP;      // 51 -> 54
        
        default:
            printf("tile_id_to_img_index: Unknown tile ID %d\n", tile_id);
            return IMG_BRICKS_RED_NORMAL;  // Fallback
    }
}

/* ========== C5: Level rendering functions ========== */

/**
 * Calculate camera position following ball (адаптировано для PSP экрана 480px)
 */
int tc_camera_follow_ball(int ball_tile_x, int map_width) {
    // ИСПРАВЛЕНО: плавная камера как в современных играх
    int visible_width = VISIBLE_TILE_WIDTH;  // 40 тайлов на экране
    int center_zone = visible_width / 2;     // 20 тайлов - центральная зона
    
    // Проверки границ
    if (ball_tile_x < 0) ball_tile_x = 0;
    if (ball_tile_x >= map_width) ball_tile_x = map_width - 1;
    
    // Максимальная позиция камеры (чтобы не выйти за карту)
    int max_camera_x = map_width - visible_width;
    if (max_camera_x < 0) max_camera_x = 0;
    
    // Идеальная позиция камеры - мяч в центре экрана
    int ideal_camera = ball_tile_x - center_zone;
    
    // Ограничиваем камеру границами карты
    if (ideal_camera < 0) {
        return 0;  // Левый край карты
    }
    else if (ideal_camera > max_camera_x) {
        return max_camera_x;  // Правый край карты  
    }
    else {
        return ideal_camera;  // Мяч в центре экрана
    }
}

/**
 * Render visible portion of level to screen (аналог TileCanvas.createNewBuffer)
 */
void tc_render_level(texture_t* atlas, int** level_map, int map_width, int map_height,
                     int camera_x, int camera_y) {
    if (!atlas || !level_map) {
        printf("tc_render_level: Invalid parameters\n");
        return;
    }
    
    // ОПТИМИЗАЦИЯ: настраиваем GU состояния один раз для всего кадра
    sceGuDisable(GU_DEPTH_TEST);
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);
    sceGuTexMode(GU_PSM_8888, 0, 0, GU_FALSE);
    sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA);
    sceGuTexFilter(GU_NEAREST, GU_NEAREST);
    sceGuTexWrap(GU_CLAMP, GU_CLAMP);
    sceGuTexImage(0, atlas->width, atlas->height, atlas->width, atlas->data);
    sceGuEnable(GU_TEXTURE_2D);
    
    // Рендерим видимую область: 40×22 тайла
    for (int screen_x = 0; screen_x < VISIBLE_TILE_WIDTH; screen_x++) {
        for (int screen_y = 0; screen_y < VISIBLE_TILE_HEIGHT; screen_y++) {
            
            // Переводим координаты экрана в координаты карты
            int map_x = camera_x + screen_x;
            int map_y = camera_y + screen_y;
            
            // Проверяем границы карты
            int tile_id = ID_EMPTY_SPACE;  // По умолчанию пустота
            if (map_x >= 0 && map_x < map_width && map_y >= 0 && map_y < map_height) {
                tile_id = level_map[map_y][map_x];
            }
            
            // Рисуем тайл на экране
            int pixel_x = screen_x * TILE_SIZE;  // 0, 12, 24, 36...
            int pixel_y = screen_y * TILE_SIZE;  // 0, 12, 24, 36...
            
            // ИСПРАВЛЕНО: используем маппинг ID -> IMG
            int is_water = (tile_id & ID_WATER_FLAG) ? 1 : 0;
            int img_index = tile_id_to_img_index(tile_id, is_water);
            if (img_index >= 0) {
                tc_draw_tile_optimized(atlas, img_index, pixel_x, pixel_y, TILE_SIZE);
            } else {
                // ID_EMPTY_SPACE - заливка фоном
                // TODO: добавить заливку цветом фона если нужно
            }
        }
    }
    
    // Выключаем текстуры после рендера
    sceGuDisable(GU_TEXTURE_2D);
    sceGuDisable(GU_BLEND);
}

/**
 * Create a simple test level for C5 testing - ИСПРАВЛЕННАЯ ВЕРСИЯ
 */
int** tc_create_test_level(int* width, int* height) {
    *width = 80;
    *height = 30;
    
    // Выделяем память для карты
    int** level_map = (int**)malloc(*height * sizeof(int*));
    if (!level_map) {
        printf("tc_create_test_level: Failed to allocate rows\n");
        return NULL;
    }
    
    for (int y = 0; y < *height; y++) {
        level_map[y] = (int*)malloc(*width * sizeof(int));
        if (!level_map[y]) {
            printf("tc_create_test_level: Failed to allocate row %d\n", y);
            for (int i = 0; i < y; i++) {
                free(level_map[i]);
            }
            free(level_map);
            return NULL;
        }
    }
    
    // ИСПРАВЛЕННЫЙ паттерн - только известные ID тайлов
    printf("DEBUG: Creating test level with known tile IDs\n");
    
    for (int y = 0; y < *height; y++) {
        for (int x = 0; x < *width; x++) {
            
            if (x < 10) {
                // Левая полоса - пустота
                level_map[y][x] = ID_EMPTY_SPACE;  // 0
            }
            else if (x < 20) {
                // Вторая полоса - красные кирпичи  
                level_map[y][x] = ID_BRICK_RED;    // 1
            }
            else if (x < 30) {
                // Третья полоса - синие кирпичи
                level_map[y][x] = ID_BRICK_BLUE;   // 2
            }
            else if (x < 40) {
                // Четвертая полоса - пустота
                level_map[y][x] = ID_EMPTY_SPACE;  // 0
            }
            else if (x < 50) {
                // Пятая полоса - кристаллы
                level_map[y][x] = ID_RESPAWN_GEM;  // 7
            }
            else if (x < 60) {
                // Шестая полоса - шипы вверх
                level_map[y][x] = ID_SPIKE_FLOOR;  // 3
            }
            else if (x < 70) {
                // Седьмая полоса - жизни
                level_map[y][x] = ID_EXTRA_LIFE;   // 29
            }
            else {
                // Последняя полоса - снова пустота
                level_map[y][x] = ID_EMPTY_SPACE;  // 0
            }
        }
    }
    
    printf("tc_create_test_level: Created level with strips: EMPTY(0-9) RED(10-19) BLUE(20-29) EMPTY(30-39) GEM(40-49) SPIKE(50-59) LIFE(60-69) EMPTY(70-79)\n");
    return level_map;
}

/**
 * Free test level created by tc_create_test_level
 */
void tc_free_test_level(int** level_map, int height) {
    if (!level_map) return;
    
    for (int y = 0; y < height; y++) {
        if (level_map[y]) {
            free(level_map[y]);
        }
    }
    free(level_map);
    
    printf("tc_free_test_level: Test level freed\n");
}
