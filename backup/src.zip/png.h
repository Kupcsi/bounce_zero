#ifndef PNG_H
#define PNG_H

#include <pspgu.h>

// Texture structure for GU
typedef struct {
    void* data;         // Texture data (CPU memory aligned for GU upload)
    int width;          // Texture width (atlas width, pixels)
    int height;         // Texture height (atlas height, pixels)
    int actual_width;   // Actual image width
    int actual_height;  // Actual image height
    int format;         // GU pixel format (GU_PSM_8888, etc.)
} texture_t;

// Sprite rectangle for atlas textures (UV in 0..1 space)
typedef struct {
    float u, v;          // top-left UV (0..1)
    float width, height; // UV size (0..1)
} sprite_rect_t;

/**
 * Load PNG file into GU texture (reads via fs + stbi_load_from_memory)
 * @param path Resource path (e.g. "/icons/objects_nm.png")
 * @return Pointer to texture_t, or NULL on failure
 */
texture_t* png_load_texture(const char* path);

/**
 * Create sprite rectangle for atlas texture
 * @param tex Source texture
 * @param x, y Pixel coordinates in atlas
 * @param w, h Sprite size in pixels
 * @return Sprite rectangle with UV coordinates
 */
sprite_rect_t png_create_sprite_rect(texture_t* tex, int x, int y, int w, int h);

/**
 * Draw sprite from texture atlas
 * @param tex Source texture
 * @param sprite Sprite rectangle (UV coords)
 * @param x, y Screen position
 * @param w, h Draw size (can be different from sprite size)
 */
void png_draw_sprite(texture_t* tex, sprite_rect_t* sprite, float x, float y, float w, float h);

/**
 * Free texture memory
 * @param tex Texture to free
 */
void png_free_texture(texture_t* tex);

#endif // PNG_H

