// physics.c - Портированная физика из Ball.java (с подводной физикой)
#include "types.h"
#include "level.h"
#include <stdlib.h>

// RAMPS: external triangle-mask collision from level.c
int level_check_triangle_collision(int pixelX, int pixelY, int width, int height, int tileX, int tileY, int rampType);
// Применяем физику рампы: корректировка скоростей вдоль наклонной
static void apply_ramp_physics(Player* p, int rampType) {
    switch (rampType) {
        case 0: // TOP_LEFT
            if (p->ySpeed > 0) {
                p->xSpeed -= 1;
                p->ySpeed = 0;
            }
            break;
        case 1: // TOP_RIGHT
            if (p->ySpeed > 0) {
                p->xSpeed += 1;
                p->ySpeed = 0;
            }
            break;
        case 2: // BOT_LEFT
            if (p->ySpeed < 0) {
                p->xSpeed -= 1;
                p->ySpeed = 0;
            }
            break;
        case 3: // BOT_RIGHT
            if (p->ySpeed < 0) {
                p->xSpeed += 1;
                p->ySpeed = 0;
            }
            break;
    }
}


// RAMPS: precise alignment to ramp surface using mask collision (no geometric simplifications)

// Дополнительные константы физики из BounceConst.java
#define JUMP_STRENGTH -67           // было JUMP_SPEED 67
#define JUMP_STRENGTH_INC -10       // было неправильно
#define JUMP_BONUS_STRENGTH -80

#define NORMAL_GRAVITY_ACCELL 4     // было GRAVITY_NORMAL 4
#define LARGE_GRAVITY_ACCELL 3      // было GRAVITY_LARGE 3

#define NORMAL_MAX_GRAVITY 80       // было gravity = 80
#define LARGE_MAX_GRAVITY 38        // было gravity = 38

// Подводная физика из BounceConst.java (ДОБАВЛЕНО)
#define UWATER_MAX_GRAVITY 42           // Подводная гравитация маленький мяч
#define UWATER_GRAVITY_ACCELL 6         // Ускорение в воде маленький мяч
#define UWATER_LARGE_MAX_GRAVITY -30    // Подводная гравитация большой мяч (всплывает!)
#define LARGE_UWATER_GRAVITY_ACCELL -2  // Ускорение в воде большой мяч

#define MAX_TOTAL_SPEED 150         // было MAX_SPEED 150
#define HORZ_ACCELL 6              // было ACCELERATION 6  
#define FRICTION_DECELL 4          // было FRICTION 4
#define MAX_HORZ_SPEED 50          // было maxSpeed = 50
#define MAX_HORZ_BONUS_SPEED 100   // было maxSpeed = 100

#define BOUNCE_NUMERATOR -1
#define BOUNCE_DENOMINATOR 2
#define MIN_BOUNCE_SPEED 10
#define ROOF_COLLISION_SPEED 20

// Инициализация игрока (ОБНОВЛЕНО)
void player_init(Player* p, int x, int y, int sizeState) {
    p->xPos = x;
    p->yPos = y;
    p->xSpeed = 0;
    p->ySpeed = 0;
    p->direction = 0;
    p->jumpOffset = 0;
    p->ballState = BALL_STATE_NORMAL;
    p->sizeState = sizeState;
    
    // Установка размера в зависимости от состояния
    if (sizeState == SMALL_SIZE_STATE) {
        p->ballSize = NORMAL_SIZE;
        p->mHalfBallSize = HALF_NORMAL_SIZE;
    } else if (sizeState == LARGE_SIZE_STATE) {
        p->ballSize = ENLARGED_SIZE;
        p->mHalfBallSize = HALF_ENLARGED_SIZE;
    }
    
    p->mGroundedFlag = 0;
    p->mCDRubberFlag = 0;
    p->mCDRampFlag = 0;
    
    p->speedBonusCntr = 0;
    p->gravBonusCntr = 0;
    p->jumpBonusCntr = 0;
    p->slideCntr = 0;
    
    // ДОБАВЛЕНО: инициализация подводного флага
    p->isInWater = 0;
}

// Увеличение мяча (портировано из enlargeBall()) - ПОЛНОСТЬЮ ИСПРАВЛЕНО
void enlarge_ball(Player* p) {
    if (p->sizeState == LARGE_SIZE_STATE) return; // Уже большой
    
    p->sizeState = LARGE_SIZE_STATE;
    p->ballSize = ENLARGED_SIZE;
    p->mHalfBallSize = HALF_ENLARGED_SIZE;
    
    // Полная логика поиска свободного места как в оригинале
    int offset = 2;
    int found_free_space = 0;
    
    while (!found_free_space) {
        found_free_space = 1;
        
        // Проверяем все 6 направлений в порядке приоритета как в Ball.java:
        if (check_collision_at(p, p->xPos, p->yPos - offset)) {
            // 1. Вверх (приоритет)
            p->yPos -= offset;
        } else if (check_collision_at(p, p->xPos - offset, p->yPos - offset)) {
            // 2. Лево-вверх
            p->xPos -= offset;
            p->yPos -= offset;
        } else if (check_collision_at(p, p->xPos + offset, p->yPos - offset)) {
            // 3. Право-вверх
            p->xPos += offset;
            p->yPos -= offset;
        } else if (check_collision_at(p, p->xPos, p->yPos + offset)) {
            // 4. Вниз
            p->yPos += offset;
        } else if (check_collision_at(p, p->xPos - offset, p->yPos + offset)) {
            // 5. Лево-вниз
            p->xPos -= offset;
            p->yPos += offset;
        } else if (check_collision_at(p, p->xPos + offset, p->yPos + offset)) {
            // 6. Право-вниз
            p->xPos += offset;
            p->yPos += offset;
        } else {
            // Не нашли свободное место - увеличиваем радиус поиска
            found_free_space = 0;
            offset++;
            if (offset > 20) break; // Защита от бесконечного цикла
        }
    }
}

// Уменьшение мяча (портировано из shrinkBall()) - ИСПРАВЛЕНО
void shrink_ball(Player* p) {
    if (p->sizeState == SMALL_SIZE_STATE) return; // Уже маленький
    
    p->sizeState = SMALL_SIZE_STATE;
    p->ballSize = NORMAL_SIZE;
    p->mHalfBallSize = HALF_NORMAL_SIZE;
    
    // Проверка позиции после уменьшения как в оригинале
    int offset = 2;
    if (check_collision_at(p, p->xPos, p->yPos + offset)) {
        p->yPos += offset;
    } else if (check_collision_at(p, p->xPos, p->yPos - offset)) {
        p->yPos -= offset;
    }
    // Если оба направления заняты - остаемся на месте
}

// Лопание мяча (портировано из popBall())
void pop_ball(Player* p) {
    p->ballState = BALL_STATE_POPPED;
    p->xSpeed = 0;
    p->ySpeed = 0;
    
    // Сброс бонусов
    p->speedBonusCntr = 0;
    p->gravBonusCntr = 0;
    p->jumpBonusCntr = 0;
}

// Установка направления (битовые флаги)
void set_direction(Player* p, int dir) {
    if (dir == MOVE_LEFT || dir == MOVE_RIGHT || dir == MOVE_UP) {
        p->direction |= dir;
    }
}

// Сброс направления
void release_direction(Player* p, int dir) {
    if (dir == MOVE_LEFT || dir == MOVE_RIGHT || dir == MOVE_UP) {
        p->direction &= ~dir;
    }
}

// Проверка коллизий с тайловой системой (ОБНОВЛЕНО с подводной физикой и рампами)
int check_collision_at(Player* p, int x, int y) {
    // RAMPS: reset ramp flags each call
    p->mCDRampFlag = 0;
    p->mCDRubberFlag = 0;

    // RAMPS: check bottom tiles for ramp collision
    int footY  = (y + p->ballSize - 1) / TILE_SIZE;
    int footXL = x / TILE_SIZE;
    int footXR = (x + p->ballSize - 1) / TILE_SIZE;
    for (int t = 0; t < 2; ++t) {
        int tx = (t == 0) ? footXL : footXR;
        if (tx < 0 || tx >= g_level.width || footY < 0 || footY >= g_level.height) continue;
        int id = g_level.tileMap[footY][tx] & 0x3F;
        if (id >= 30 && id <= 37) {
            p->mCDRampFlag = 1;
            if (id >= 34) p->mCDRubberFlag = 1;
            break;
        }
    }

    // Границы уровня (по фактической карте)
    int levelW = g_level.width * TILE_SIZE;
    int levelH = g_level.height * TILE_SIZE;
    if (x < 0 || y < 0 || x + p->ballSize > levelW || y + p->ballSize > levelH) {
        return 0; // Коллизия с границами уровня
    }
    
    // ДОБАВЛЕНО: Проверка водного тайла под мячом
    int tileX = x / TILE_SIZE;
    int tileY = y / TILE_SIZE; 
    
    if (tileX >= 0 && tileX < g_level.width && tileY >= 0 && tileY < g_level.height) {
        int fullTile = g_level.tileMap[tileY][tileX];
        p->isInWater = (fullTile & 0x40) ? 1 : 0;  // Проверяем водный флаг
        
        // ДОБАВЛЕНО: Проверка треугольных рамп для установки флагов
        int tileID = fullTile & 0x3F;
        if ((tileID >= 30 && tileID <= 33) || (tileID >= 34 && tileID <= 37)) {
            p->mCDRampFlag = 1;  // Устанавливаем флаг наклонной поверхности
            if (tileID >= 34 && tileID <= 37) {
                p->mCDRubberFlag = 1;  // Резиновые треугольники
            }
        }
    } else {
        p->isInWater = 0;  // Вне карты - не в воде
    }
    
    // Используем новую тайловую систему (теперь с поддержкой рамп)
    return level_check_collision_at_pixel(x, y, p->ballSize, p->ballSize);
}

// Основное обновление физики (ИСПРАВЛЕННОЕ с подводной физикой)
void player_update(Player* p) {
    if (p->ballState == BALL_STATE_POPPED) return; // Если мяч лопнул
    
    int gravity, gravityStep;
    int maxSpeed;
    int reverseGrav = 0;
    
    // ИСПРАВЛЕНО: выбор гравитации с учетом воды
    if (p->isInWater) {
        // В ВОДЕ - совершенно другая физика!
        if (p->ballSize == 16) {
            gravity = UWATER_LARGE_MAX_GRAVITY;    // -30 (всплывает!)
            gravityStep = LARGE_UWATER_GRAVITY_ACCELL; // -2
            
            // Большой мяч в воде автоматически получает начальную скорость всплытия
            if (p->mGroundedFlag) {
                p->ySpeed = -10;
            }
        } else {
            gravity = UWATER_MAX_GRAVITY;       // 42 
            gravityStep = UWATER_GRAVITY_ACCELL; // 6
        }
    } else {
        // НА СУШЕ - обычная физика
        if (p->ballSize == 16) {
            gravity = LARGE_MAX_GRAVITY;        // 38
            gravityStep = LARGE_GRAVITY_ACCELL; // 3
        } else {
            gravity = NORMAL_MAX_GRAVITY;        // 80
            gravityStep = NORMAL_GRAVITY_ACCELL; // 4
        }
    }
    
    // Бонус гравитации (обратная гравитация)
    if (p->gravBonusCntr > 0) {
        reverseGrav = 1;
        gravity *= -1;
        gravityStep *= -1;
        p->gravBonusCntr--;
    }
    
    // Счётчик скольжения
    p->slideCntr++;
    if (p->slideCntr == 3) {
        p->slideCntr = 0;
    }
    
    // Ограничение скорости (ИСПРАВЛЕНО)
    if (p->ySpeed < -MAX_TOTAL_SPEED) p->ySpeed = -MAX_TOTAL_SPEED;
    else if (p->ySpeed > MAX_TOTAL_SPEED) p->ySpeed = MAX_TOTAL_SPEED;
    if (p->xSpeed < -MAX_TOTAL_SPEED) p->xSpeed = -MAX_TOTAL_SPEED;
    else if (p->xSpeed > MAX_TOTAL_SPEED) p->xSpeed = MAX_TOTAL_SPEED;
    
    // === ФИЗИКА ПО ОСИ Y ===
    int ySteps = abs(p->ySpeed) / 10;
    for (int i = 0; i < ySteps; i++) {
        int yStep = 0;
        if (p->ySpeed != 0) {
            yStep = (p->ySpeed < 0) ? -1 : 1;
        }
        
        if (check_collision_at(p, p->xPos, p->yPos + yStep)) {
            p->yPos += yStep;
            p->mGroundedFlag = 0;
        } else {
            // ДОБАВЛЕНО: Логика скольжения по наклонным поверхностям из Ball.java
            if (p->mCDRampFlag && p->xSpeed < 10 && p->slideCntr == 0) {
                // Попытка движения по диагонали при скольжении по наклону
                int slideStep = 1;
                if (check_collision_at(p, p->xPos + slideStep, p->yPos + yStep)) {
                    p->xPos += slideStep;
                    p->yPos += yStep;
                    p->mCDRampFlag = 0;
                    continue; // Успешно проскользили по наклону
                } else if (check_collision_at(p, p->xPos - slideStep, p->yPos + yStep)) {
                    p->xPos -= slideStep;
                    p->yPos += yStep;
                    p->mCDRampFlag = 0;
                    continue; // Успешно проскользили по наклону
                }
            }
            
            // Коллизия - отскок (ИСПРАВЛЕНО по оригинальным константам)
            if (yStep > 0 || (reverseGrav && yStep < 0)) {
                // Используем правильные константы отскока
                p->ySpeed = p->ySpeed * BOUNCE_NUMERATOR / BOUNCE_DENOMINATOR; // * -1 / 2
                p->mGroundedFlag = 1;
                
                // Обработка прыжка при касании земли
                if (p->mCDRubberFlag && (p->direction & MOVE_UP)) {
                    p->mCDRubberFlag = 0;
                    if (reverseGrav) {
                        p->jumpOffset += JUMP_STRENGTH_INC;  // -10
                    } else {
                        p->jumpOffset += -JUMP_STRENGTH_INC; // +10
                    }
                } else if (p->jumpBonusCntr == 0) {
                    p->jumpOffset = 0;
                }
                
                // Минимальная скорость отскока (ИСПРАВЛЕНО)
                if (p->ySpeed < MIN_BOUNCE_SPEED && p->ySpeed > -MIN_BOUNCE_SPEED) {
                    if (reverseGrav) {
                        p->ySpeed = -MIN_BOUNCE_SPEED;
                    } else {
                        p->ySpeed = MIN_BOUNCE_SPEED;
                    }
                }
                break;
            }
            
            if (yStep < 0 || (reverseGrav && yStep > 0)) {
                if (reverseGrav) {
                    p->ySpeed = -ROOF_COLLISION_SPEED;
                } else {
                    p->ySpeed = ROOF_COLLISION_SPEED;
                }
            }
        }
    }
    
    // ДОБАВЛЕНО: Особая логика для большого мяча выходящего из воды
    if (p->ballSize == 16 && gravity == -30) { // Был под водой
        // Проверяем, вышел ли из воды
        int currentTileY = p->yPos / TILE_SIZE;
        if (currentTileY >= 0 && currentTileY < g_level.height) {
            int tileX = p->xPos / TILE_SIZE;
            if (tileX >= 0 && tileX < g_level.width) {
                int currentTile = g_level.tileMap[currentTileY][tileX];
                if ((currentTile & 0x40) == 0) { // Вышел из воды!
                    p->ySpeed >>= 1; // Деление на 2
                    if (p->ySpeed <= 10 && p->ySpeed >= -10) {
                        p->ySpeed = 0;
                    }
                }
            }
        }
    }
    
    // Применение гравитации (ИСПРАВЛЕНО)
    if (reverseGrav) {
        if (gravityStep == -2 && p->ySpeed < gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed > gravity) p->ySpeed = gravity;
        } else if (!p->mGroundedFlag && p->ySpeed > gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed < gravity) p->ySpeed = gravity;
        }
    } else {
        if (gravityStep == -2 && p->ySpeed > gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed < gravity) p->ySpeed = gravity;
        } else if (!p->mGroundedFlag && p->ySpeed < gravity) {
            p->ySpeed += gravityStep;
            if (p->ySpeed > gravity) p->ySpeed = gravity;
        }
    }
    
    // === УПРАВЛЕНИЕ ГОРИЗОНТАЛЬНЫМ ДВИЖЕНИЕМ === (ИСПРАВЛЕНО)
    maxSpeed = (p->speedBonusCntr > 0) ? MAX_HORZ_BONUS_SPEED : MAX_HORZ_SPEED;
    if (p->speedBonusCntr > 0) p->speedBonusCntr--;
    
    if ((p->direction & MOVE_RIGHT) && p->xSpeed < maxSpeed) {
        p->xSpeed += HORZ_ACCELL;
    } else if ((p->direction & MOVE_LEFT) && p->xSpeed > -maxSpeed) {
        p->xSpeed -= HORZ_ACCELL;
    } else if (p->xSpeed > 0) {
        p->xSpeed -= FRICTION_DECELL;
    } else if (p->xSpeed < 0) {
        p->xSpeed += FRICTION_DECELL;
    }
    
    // === ПРЫЖОК === (ИСПРАВЛЕНО с правильными константами)
    if (p->mGroundedFlag && (p->direction & MOVE_UP)) {
        if (reverseGrav) {
            p->ySpeed = -JUMP_STRENGTH + p->jumpOffset; // 67 + offset
        } else {
            p->ySpeed = JUMP_STRENGTH + p->jumpOffset;  // -67 + offset
        }
        p->mGroundedFlag = 0;
        
        // ВАЖНО: сразу сбрасываем флаг прыжка после выполнения
        p->direction &= ~MOVE_UP;
    }
    
    // === ФИЗИКА ПО ОСИ X ===
    int xSteps = abs(p->xSpeed) / 10;
    for (int i = 0; i < xSteps; i++) {
        int xStep = 0;
        if (p->xSpeed != 0) {
            xStep = (p->xSpeed < 0) ? -1 : 1;
        }
        
        if (check_collision_at(p, p->xPos + xStep, p->yPos)) {
            p->xPos += xStep;
        } else if (p->mCDRampFlag) {
            // ДОБАВЛЕНО: Логика движения по наклону при горизонтальном движении
            p->mCDRampFlag = 0;
            int rampStep = 0;
            if (reverseGrav) {
                rampStep = 1;   // При обратной гравитации движемся вверх
            } else {
                rampStep = -1;  // При обычной гравитации движемся вниз
            } 
            
            if (check_collision_at(p, p->xPos + xStep, p->yPos + rampStep)) {
                p->xPos += xStep;
                p->yPos += rampStep;
            } else if (check_collision_at(p, p->xPos + xStep, p->yPos - rampStep)) {
                p->xPos += xStep;
                p->yPos -= rampStep;
            } else {
                // Не удалось подняться/спуститься по наклону - отскок
                if (p->xSpeed != 0) {
                    p->xSpeed = -(p->xSpeed >> 1);
                }
            }
        } else {
            // Коллизия по X - отскок (ИСПРАВЛЕНО с защитой от деления на ноль)
            if (p->xSpeed != 0) {  // ДОБАВЛЕНА защита
                p->xSpeed = -(p->xSpeed >> 1);
            }
        }
    }
    
    // Границы уровня по X
    int levelW = g_level.width * TILE_SIZE;
    if (p->xPos < 0) p->xPos = 0;
    if (p->xPos > levelW - p->ballSize) p->xPos = levelW - p->ballSize;

    
    // Если мяч стоит на рампе — применяем физику наклонной
    if (p->mCDRampFlag) {
        apply_ramp_physics(p, p->mLastRampType); // p->mLastRampType должен задаваться в level.c
    }
    // Сброс флагов коллизий
    p->mCDRubberFlag = 0;
    p->mCDRampFlag = 0;
}