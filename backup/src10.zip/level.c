// level.c - Парсер уровней + отрисовка с атласом PNG (с поддержкой трансформаций)
#include "level.h"
#include "tile_table.h"
#include "graphics.h"
#include "game.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// --- Ring foreground queue (draw after the ball) ---
typedef struct { int sprite_idx; float x, y; int transform; } hoop_fg_item_t;
static hoop_fg_item_t g_hoop_fg[512];
static int g_hoop_fg_count = 0;
static inline void hoop_fg_clear(void){ g_hoop_fg_count = 0; }

static inline void hoop_fg_push(int sprite_idx, float x, float y, int transform){
    if (g_hoop_fg_count < (int)(sizeof(g_hoop_fg)/sizeof(g_hoop_fg[0]))){
        g_hoop_fg[g_hoop_fg_count++] = (hoop_fg_item_t){ sprite_idx, x, y, transform };
    }
}

// Map TileTransform -> png_xform_t
static inline png_xform_t map_tf_to_png(int tf){
    switch (tf){
        case TF_FLIP_X:  return PNG_XFORM_FLIP_X;
        case TF_FLIP_Y:  return PNG_XFORM_FLIP_Y;
        case TF_FLIP_XY: return PNG_XFORM_ROT_180; // FLIP_X+FLIP_Y эквивалент 180°
        case TF_ROT_90:  return PNG_XFORM_ROT_90;
        case TF_ROT_180: return PNG_XFORM_ROT_180;
        case TF_ROT_270: return PNG_XFORM_ROT_270;
        case TF_ROT_270_FLIP_X: return PNG_XFORM_ROT_270_FLIP_Y;
        case TF_ROT_270_FLIP_Y: return PNG_XFORM_ROT_270_FLIP_X;

        case TF_ROT_270_FLIP_XY: return PNG_XFORM_ROT_270_FLIP_XY;
        default:         return PNG_XFORM_IDENTITY;
    }
}

static void hoop_fg_flush(void){
    if (!g_tileset || g_tiles_per_row <= 0) { g_hoop_fg_count = 0; return; }
    for (int i = 0; i < g_hoop_fg_count; ++i){
        int idx = g_hoop_fg[i].sprite_idx;
        if (idx <= 0 || idx >= 255) continue;
        int col = idx % g_tiles_per_row;
        int row = idx / g_tiles_per_row;
        int srcX = col * TILE_SIZE;
        int srcY = row * TILE_SIZE;
        sprite_rect_t r = png_create_sprite_rect(g_tileset, srcX, srcY, TILE_SIZE, TILE_SIZE);
        png_xform_t xf = map_tf_to_png(g_hoop_fg[i].transform); // alt_transform now used from queue
        if (xf == PNG_XFORM_IDENTITY){
            png_draw_sprite(g_tileset, &r, g_hoop_fg[i].x, g_hoop_fg[i].y, (float)TILE_SIZE, (float)TILE_SIZE);
        } else {
            png_draw_sprite_xform(g_tileset, &r, g_hoop_fg[i].x, g_hoop_fg[i].y, (float)TILE_SIZE, (float)TILE_SIZE, xf);
        }
    }
    g_hoop_fg_count = 0;
}

// Public control to get order: background -> ball -> ring foreground
static int g_ring_fg_defer = 0;
void level_set_ring_fg_defer(int on) { g_ring_fg_defer = on ? 1 : 0; }
void level_flush_ring_foreground(void) { hoop_fg_flush(); }


_Static_assert(TILE_SIZE == 12, "Masks assume TILE_SIZE==12");
#include "level_masks.inc"

// --- Ramp triangle masked collision (ported from Java) ---
static inline void tri_reflect_params_for_id(int tileId, int* b1, int* b2) {
    // Base TRI_TILE_DATA corresponds to BOT_RIGHT (IDs 32/36)
    switch (tileId) {
        case 30: case 34: *b1 = 11; *b2 = 11; break; // TOP_LEFT
        case 31: case 35: *b1 =  0; *b2 = 11; break; // TOP_RIGHT
        case 33: case 37: *b1 = 11; *b2 =  0; break; // BOT_LEFT
        default:          *b1 =  0; *b2 =  0; break; // BOT_RIGHT (32/36)
    }
}



Level g_level;

// --- Текстуры/атлас ---
texture_t* g_tileset = NULL;   // Убрали static для доступа из других файлов
int g_tiles_per_row = 0;       // Убрали static для доступа из других файлов

// --- Тест PNG ---
static texture_t* g_test_texture = NULL;

void level_test_png_rendering(void) {
    if (!g_test_texture) {
        g_test_texture = png_load_texture("test.png");
        if (!g_test_texture) {
            graphics_draw_rect(50, 50, 64, 64, 0xFFFF0000);
            graphics_draw_text(50, 120, "PNG FAILED", 0xFFFFFFFF);
            return;
        }
    }
    
    sprite_rect_t full_sprite = png_create_sprite_rect(g_test_texture, 0, 0, 64, 64);
    png_draw_sprite(g_test_texture, &full_sprite, 50, 50, 64, 64);
    
    sprite_rect_t quarter = png_create_sprite_rect(g_test_texture, 0, 0, 32, 32);
    png_draw_sprite(g_test_texture, &quarter, 150, 50, 64, 64);
    
    graphics_draw_text(50, 120, "PNG TEST OK", 0xFF00FF00);
}

// --- Вспомогательное: единожды загрузить атлас ---
static void level_load_tileset_once(void) {
    if (g_tileset) return;
    g_tileset = png_load_texture("icons/objects_nm.png");
    if (g_tileset && g_tileset->width > 0) {
        g_tiles_per_row = g_tileset->actual_width / TILE_SIZE; // 12 px на тайл
    } else {
        g_tiles_per_row = 0;
    }
}

// --- Загрузка уровня из файла ---
int level_load_from_file(const char* filename) {
    FILE* file = fopen(filename, "rb");
    if (!file) {
        // Фолбэк: попробуем добавить/убрать ведущий слеш
        if (filename && filename[0] == '/') {
            file = fopen(filename + 1, "rb");
        } else {
            char alt[512];
            snprintf(alt, sizeof(alt), "/%s", filename);
            file = fopen(alt, "rb");
        }
        if (!file) return 0;
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    fseek(file, 0, SEEK_SET);
    if (fileSize < 8) { fclose(file); return 0; }

    unsigned char* buffer = (unsigned char*)malloc((size_t)fileSize);
    if (!buffer) { fclose(file); return 0; }

    size_t bytesRead = fread(buffer, 1, (size_t)fileSize, file);
    fclose(file);
    if (bytesRead != (size_t)fileSize) { free(buffer); return 0; }

    int result = level_load_from_memory((const char*)buffer, (int)fileSize);
    free(buffer);
    return result;
}

// --- Загрузка уровня по номеру ---
int level_load_by_number(int levelNumber) {
    level_load_tileset_once();
    char filename[256];
    snprintf(filename, sizeof(filename), "/levels/J2MElvl.%03d", levelNumber);
    int result = level_load_from_file(filename);
    
    // Сбрасываем камеру при загрузке нового уровня
    if (result) {
        game_reset_camera();
    }
    
    return result;
}

// --- Парсер из памяти ---
int level_load_from_memory(const char* levelData, int dataSize) {
    if (!levelData || dataSize < 8) return 0;
    memset(&g_level, 0, sizeof(Level));

    const unsigned char* data = (const unsigned char*)levelData;
    int offset = 0;

    int startX_tiles   = data[offset++];
    int startY_tiles   = data[offset++];
    g_level.ballSize   = data[offset++];
    g_level.exitPosX   = data[offset++];
    g_level.exitPosY   = data[offset++];
    g_level.totalRings = data[offset++];
    g_level.width      = data[offset++];
    g_level.height     = data[offset++];

    if (g_level.width <= 0 || g_level.height <= 0 ||
        g_level.width  > MAX_LEVEL_WIDTH || g_level.height > MAX_LEVEL_HEIGHT) {
        return 0;
    }

    int mapBytes = g_level.width * g_level.height;
    if (offset + mapBytes > dataSize) return 0;

    g_level.startPosX = startX_tiles * TILE_SIZE;
    g_level.startPosY = startY_tiles * TILE_SIZE;

    for (int y = 0; y < g_level.height; ++y) {
        for (int x = 0; x < g_level.width; ++x) {
            g_level.tileMap[y][x] = data[offset++];
        }
    }

    // Опционально: хвост движущихся объектов - игнорируем
    if (dataSize - offset >= 1) {
        int numMoveObj = data[offset++];
        int tail = numMoveObj * 8;
        if (dataSize - offset >= tail) {
            // пропускаем
        }
    }

    return 1;
}

// --- Тестовый уровень ---
int level_create_test_level(void) {
    static const unsigned char testLevelData[] = {
        2,18,0,35,18,3,40,23,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
        1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1
    };
    return level_load_from_memory((const char*)testLevelData, sizeof(testLevelData));
}

// --- Доступ к тайлам ---
int level_get_tile_at(int tileX, int tileY) {
    if (tileX < 0 || tileX >= g_level.width || tileY < 0 || tileY >= g_level.height) {
        return 1; // вне карты считаем стеной
    }
    return g_level.tileMap[tileY][tileX];
}

// --- Твердость тайлов ---
int level_is_tile_solid(int tile) {
    if (tile < 0 || tile >= (int)tile_meta_count()) return 0;
    const TileMeta* t = &tile_meta_db()[tile];
    return t->type == TILETYPE_SOLID;
}

// --- Проверка коллизии с треугольной рампой ---
int level_check_triangle_collision(int pixelX, int pixelY, int width, int height, int tileX, int tileY, int rampType) {
    int ballSize = width;

    for (int by = 0; by < ballSize; ++by) {
        for (int bx = 0; bx < ballSize; ++bx) {
            int filled = 0;
            if (width == 12) {
                if (SMALL_BALL_DATA[by][bx]) filled = 1;
            } else {
                if (LARGE_BALL_DATA[by][bx]) filled = 1;
            }
            if (!filled) continue;

            int worldX = pixelX + bx;
            int worldY = pixelY + by;
            int localX = worldX - tileX * TILE_SIZE;
            int localY = worldY - tileY * TILE_SIZE;

            if (localX < 0 || localX >= TILE_SIZE || localY < 0 || localY >= TILE_SIZE)
                continue;

            if (TRI_TILE_DATA[rampType][localY] & (1 << (TILE_SIZE - 1 - localX))) {
                return 0; // есть пересечение
            }
        }
    }
    return 1; // нет пересечения
}

// --- Проверка коллизии по пикселям ---
int level_check_collision_at_pixel(int pixelX, int pixelY, int width, int height) {
    int leftTile   = pixelX / TILE_SIZE;
    int rightTile  = (pixelX + width  - 1) / TILE_SIZE;
    int topTile    = pixelY / TILE_SIZE;
    int bottomTile = (pixelY + height - 1) / TILE_SIZE;

    if (leftTile   < 0) leftTile = 0;
    if (topTile    < 0) topTile = 0;
    if (rightTile  >= g_level.width)  rightTile  = g_level.width  - 1;
    if (bottomTile >= g_level.height) bottomTile = g_level.height - 1;

    for (int y = topTile; y <= bottomTile; ++y) {
        for (int x = leftTile; x <= rightTile; ++x) {
            int tile = level_get_tile_at(x, y);
            int tileID = tile & 0x3F; // Убираем флаги
            
            if (tileID >= 0 && tileID < (int)tile_meta_count()) {
                if (tile_meta_db()[tileID].mask == MASK_TRI) {
                    // Всегда проверяем по маске шара и маске треугольного тайла
                    if (level_check_triangle_collision(pixelX, pixelY, width, height, x, y, tileID) == 0) {
                        return 0; // Столкновение с рампой
                    }
                } else if (level_is_tile_solid(tileID)) {
                    return 0; // Столкновение с обычным solid тайлом
                }
            }
        }
    }
    return 1; // Нет коллизий
}

// --- Новые функции рендеринга ---

// Рендер составного тайла (EXIT, движущиеся шипы)
static void render_composite_tile(int tile_id, float screenX, float screenY) {
    const TileMeta* t = &tile_meta_db()[tile_id];
    
    if (tile_id == 9) { // EXIT - составной из 4 кусков двери
        // Создаем 2x2 композицию из базового спрайта
        for (int dy = 0; dy < 2; dy++) {
            for (int dx = 0; dx < 2; dx++) {
                int col = t->base_sprite_index % g_tiles_per_row;
                int row = t->base_sprite_index / g_tiles_per_row;
                int srcX = col * TILE_SIZE;
                int srcY = row * TILE_SIZE;
                
                sprite_rect_t r = png_create_sprite_rect(g_tileset, srcX, srcY, TILE_SIZE, TILE_SIZE);
                
                // Различные трансформации для каждого куска
                png_xform_t xf = PNG_XFORM_IDENTITY;
                if (dx == 1) xf = PNG_XFORM_FLIP_X;
                if (dy == 1 && dx == 0) xf = PNG_XFORM_FLIP_Y;
                if (dy == 1 && dx == 1) xf = PNG_XFORM_ROT_180;
                
                float x = screenX + dx * TILE_SIZE;
                float y = screenY + dy * TILE_SIZE;
                
                if (xf == PNG_XFORM_IDENTITY) {
                    png_draw_sprite(g_tileset, &r, x, y, (float)TILE_SIZE, (float)TILE_SIZE);
                } else {
                    png_draw_sprite_xform(g_tileset, &r, x, y, (float)TILE_SIZE, (float)TILE_SIZE, xf);
                }
            }
        }
    } else if (tile_id == 10) { // Движущиеся шипы - составной из 4 кусков ежа
        for (int dy = 0; dy < 2; dy++) {
            for (int dx = 0; dx < 2; dx++) {
                int col = t->base_sprite_index % g_tiles_per_row;
                int row = t->base_sprite_index / g_tiles_per_row;
                int srcX = col * TILE_SIZE;
                int srcY = row * TILE_SIZE;
                
                sprite_rect_t r = png_create_sprite_rect(g_tileset, srcX, srcY, TILE_SIZE, TILE_SIZE);
                
                // Различные повороты для создания шипастого облика
                png_xform_t xf = PNG_XFORM_IDENTITY;
                if (dx == 1 && dy == 0) xf = PNG_XFORM_FLIP_X;
                if (dx == 0 && dy == 1) xf = PNG_XFORM_FLIP_Y;
                if (dx == 1 && dy == 1) xf = PNG_XFORM_ROT_180;
                
                float x = screenX + dx * TILE_SIZE;
                float y = screenY + dy * TILE_SIZE;
                
                png_draw_sprite_xform(g_tileset, &r, x, y, (float)TILE_SIZE, (float)TILE_SIZE, xf);
            }
        }
    } else {
        // Фоллбэк для неизвестных составных тайлов
        graphics_draw_rect(screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE, 0xFF888888);
    }
}

// Рендер тайла с двумя спрайтами (кольца) - DEPRECATED, заменен на render_quad_ring_tile
static void render_dual_sprite_tile(const TileMeta* t, float screenX, float screenY, int tile_flags) {
    // Рендер базового спрайта (фон)
    if (t->base_sprite_index < 255) {
        int col = t->base_sprite_index % g_tiles_per_row;
        int row = t->base_sprite_index / g_tiles_per_row;
        int srcX = col * TILE_SIZE;
        int srcY = row * TILE_SIZE;
        
        sprite_rect_t r = png_create_sprite_rect(g_tileset, srcX, srcY, TILE_SIZE, TILE_SIZE);
        
        // Применить трансформацию к базовому спрайту
        png_xform_t xf = PNG_XFORM_IDENTITY;
        switch (t->transform) {
            case TF_FLIP_X:  xf = PNG_XFORM_FLIP_X;  break;
            case TF_FLIP_Y:  xf = PNG_XFORM_FLIP_Y;  break;
            case TF_ROT_90:  xf = PNG_XFORM_ROT_90;  break;
            case TF_ROT_180: xf = PNG_XFORM_ROT_180; break;
            case TF_ROT_270: xf = PNG_XFORM_ROT_270; break;
            default: break;
        }
        
        if (xf == PNG_XFORM_IDENTITY) {
            png_draw_sprite(g_tileset, &r, screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE);
        } else {
            png_draw_sprite_xform(g_tileset, &r, screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE, xf);
        }
    }
    
    // Рендер альтернативного спрайта (кольцо поверх)
    if (t->alt_sprite_index > 0 && t->alt_sprite_index < 255) {
        // defer to foreground queue so the ball can pass between halves
        hoop_fg_push(t->alt_sprite_index, screenX, screenY, (int)t->alt_transform);
    }
}

// Рендер кольца из 4 спрайтов (как в Java оригинале)
static void render_quad_ring_tile(const TileMeta* t, float screenX, float screenY, int tile_flags) {
    // Убираем заливку фона - пусть спрайты колец сами определяют фон через альфа-канал
    // graphics_draw_rect(screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE, 0xFF0B0B10); // Java цвет 11591920
    
    // Рендер фоновой части кольца
    if (t->ring_bg_sprite > 0 && t->ring_bg_sprite < 255) {
        int col = t->ring_bg_sprite % g_tiles_per_row;
        int row = t->ring_bg_sprite / g_tiles_per_row;
        int srcX = col * TILE_SIZE;
        int srcY = row * TILE_SIZE;
        
        sprite_rect_t r = png_create_sprite_rect(g_tileset, srcX, srcY, TILE_SIZE, TILE_SIZE);
        
        // Применить трансформацию к фоновому спрайту
        png_xform_t xf = PNG_XFORM_IDENTITY;
        switch (t->ring_bg_transform) {
            case TF_FLIP_X:  xf = PNG_XFORM_FLIP_X;  break;
            case TF_FLIP_Y:  xf = PNG_XFORM_FLIP_Y;  break;
            case TF_FLIP_XY: xf = PNG_XFORM_ROT_180; break; // FLIP_XY = ROT_180
            case TF_ROT_90:  xf = PNG_XFORM_ROT_90;  break;
            case TF_ROT_180: xf = PNG_XFORM_ROT_180; break;
            case TF_ROT_270: xf = PNG_XFORM_ROT_270; break;
            case TF_ROT_270_FLIP_X: xf = PNG_XFORM_ROT_270_FLIP_X; break;
            case TF_ROT_270_FLIP_Y: xf = PNG_XFORM_ROT_270_FLIP_Y; break;
            case TF_ROT_270_FLIP_XY: xf = PNG_XFORM_ROT_270_FLIP_XY; break;
            default: break;
        }
        
        png_draw_sprite_xform(g_tileset, &r, screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE, xf);
    }
    
    // Передняя часть кольца в очередь (как в Java: add2HoopList)
    if (t->ring_fg_sprite > 0 && t->ring_fg_sprite < 255) {
        hoop_fg_push(t->ring_fg_sprite, screenX, screenY, t->ring_fg_transform);
    }
}

// --- Рендер видимой области (ОБНОВЛЕНО) ---
void level_render_visible_area(int cameraX, int cameraY, int screenWidth, int screenHeight) {
    hoop_fg_clear();
    if (g_level.width <= 0 || g_level.height <= 0) return;

    int startTileX = cameraX / TILE_SIZE;
    int endTileX   = (cameraX + screenWidth  - 1) / TILE_SIZE;
    int startTileY = cameraY / TILE_SIZE;
    int endTileY   = (cameraY + screenHeight - 1) / TILE_SIZE;

    if (startTileX < 0) startTileX = 0;
    if (startTileY < 0) startTileY = 0;
    if (endTileX >= g_level.width)   endTileX = g_level.width - 1;
    if (endTileY >= g_level.height)  endTileY = g_level.height - 1;

    for (int y = startTileY; y <= endTileY; ++y) {
        for (int x = startTileX; x <= endTileX; ++x) {
            int tile = g_level.tileMap[y][x];
            int tile_id = (tile & 0x3F);
            int tile_flags = tile & 0xC0; // Флаги 0x40 и 0x80
            
            if (tile_id < 0 || tile_id >= (int)tile_meta_count()) continue;

            const TileMeta* t = &tile_meta_db()[tile_id];
            
            // Пропускаем пустые тайлы
            if (t->type == TILETYPE_EMPTY && t->mask == MASK_NONE && t->logic == LOGIC_NONE) {
                continue;
            }

            float screenX = (float)(x * TILE_SIZE - cameraX);
            float screenY = (float)(y * TILE_SIZE - cameraY);

            if (g_tileset && g_tiles_per_row > 0) {
                // Обработка специальных тайлов
                if (t->special_flags & SPECIAL_COMPOSITE) {
                    render_composite_tile(tile_id, screenX, screenY);
                } else if (t->special_flags & SPECIAL_QUAD_RING) {
                    render_quad_ring_tile(t, screenX, screenY, tile_flags);
                } else if (t->special_flags & SPECIAL_DUAL_SPRITE) {
                    render_dual_sprite_tile(t, screenX, screenY, tile_flags);
                } else {
                    // Обычный тайл
                    int sprite_idx = t->base_sprite_index;
                    
                    // Проверка флага 0x40 для переключения спрайта
                    if ((t->special_flags & SPECIAL_FLAG_0x40) && (tile_flags & 0x40) && t->alt_sprite_index > 0) {
                        sprite_idx = t->alt_sprite_index;
                    }
                    
                    if (sprite_idx < 255) {
                        int col = sprite_idx % g_tiles_per_row;
                        int row = sprite_idx / g_tiles_per_row;
                        int srcX = col * TILE_SIZE;
                        int srcY = row * TILE_SIZE;

                        png_xform_t xf = PNG_XFORM_IDENTITY;
                        switch (t->transform) {
                            case TF_FLIP_X:  xf = PNG_XFORM_FLIP_X;  break;
                            case TF_FLIP_Y:  xf = PNG_XFORM_FLIP_Y;  break;
                            case TF_FLIP_XY: xf = PNG_XFORM_ROT_180; break; // FLIP_XY = ROT_180
                            case TF_ROT_90:  xf = PNG_XFORM_ROT_90;  break;
                            case TF_ROT_180: xf = PNG_XFORM_ROT_180; break;
                            case TF_ROT_270: xf = PNG_XFORM_ROT_270; break;
                            default: break;
                        }

                        sprite_rect_t r = png_create_sprite_rect(g_tileset, srcX, srcY, TILE_SIZE, TILE_SIZE);
                        if (xf == PNG_XFORM_IDENTITY) {
                            png_draw_sprite(g_tileset, &r, screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE);
                        } else {
                            png_draw_sprite_xform(g_tileset, &r, screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE, xf);
                        }
                    } else {
                        // Фоллбэк для недействительных индексов
                        graphics_draw_rect(screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE, 0xFF444444);
                    }
                }
            } else {
                // Если атлас не загружен - серые квадраты
                graphics_draw_rect(screenX, screenY, (float)TILE_SIZE, (float)TILE_SIZE, 0xFF444444);
            }
        }
    }
    if (!g_ring_fg_defer) hoop_fg_flush();
}
