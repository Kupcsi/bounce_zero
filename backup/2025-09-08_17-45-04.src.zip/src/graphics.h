#ifndef GRAPHICS_H
#define GRAPHICS_H

#include <psptypes.h>
#include "png.h"  // Для texture_t в batch функциях

// PSP VRAM буферы должны иметь ширину кратную степени двойки для оптимизации
// Экран 480px округляется до 512px - стандартное требование PSP SDK
#define VRAM_BUFFER_WIDTH  512
#define VRAM_BUFFER_HEIGHT 272

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Инициализация графической подсистемы
 */
void graphics_init(void);

/**
 * Завершение работы графической подсистемы
 */
void graphics_shutdown(void);

/**
 * Начать новый кадр
 */
void graphics_start_frame(void);

/**
 * Завершить текущий кадр и отобразить на экране
 */
void graphics_end_frame(void);

/**
 * Очистить экран указанным цветом.
 *
 * @param color Цвет в формате ABGR (A в старшем байте).
 *        ВАЖНО: Формат соответствует внутреннему формату PSP GU (GU_PSM_8888).
 *        На PSP (little-endian) это значит, что байты в памяти лежат как R,G,B,A.
 *        Пример: непрозрачный красный = 0xFF0000FF (A=FF, B=00, G=00, R=FF).
 */
void graphics_clear(u32 color);

/**
 * Нарисовать прямоугольник
 * @param x X координата левого верхнего угла
 * @param y Y координата левого верхнего угла
 * @param w Ширина прямоугольника
 * @param h Высота прямоугольника
 * @param color Цвет в формате ABGR (A в старшем байте).
 *        ВАЖНО: Тот же формат что и в graphics_clear() - PSP GU нативный.
 */
void graphics_draw_rect(float x, float y, float w, float h, u32 color);

/**
 * Нарисовать текст стандартного размера
 * @param x X координата левого верхнего угла текста
 * @param y Y координата левого верхнего угла текста
 * @param text Строка для отображения
 * @param color Цвет текста в формате ABGR (A в старшем байте)
 */
void graphics_draw_text(float x, float y, const char* text, u32 color);

/**
 * Нарисовать текст с масштабированием
 * @param x X координата левого верхнего угла текста
 * @param y Y координата левого верхнего угла текста
 * @param text Строка для отображения
 * @param color Цвет текста в формате ABGR (A в старшем байте)
 * @param scale Коэффициент масштабирования (1.0f = стандартный размер)
 */
void graphics_draw_text_scaled(float x, float y, const char* text, u32 color, float scale);

/**
 * Измерить ширину текста с учетом масштабирования
 * @param text Строка для измерения
 * @param scale Коэффициент масштабирования
 * @return Ширина текста в пикселях
 */
float graphics_measure_text(const char* text, float scale);

/**
 * Единое управление состоянием текстур
 * ВАЖНО: Вне graphics.* запрещены прямые вызовы sceGuEnable/Disable(GU_TEXTURE_2D)!
 */
void graphics_set_texturing(int enabled);  // 0=off, 1=on
void graphics_begin_plain(void);           // гарантирует выключенные текстуры (HUD фон/текст)
void graphics_begin_textured(void);        // гарантирует включенные текстуры + сброс цвета (ОБЯЗАТЕЛЬНО перед PNG!)
int graphics_get_texturing_state(void);    // получить текущее состояние (0=plain, 1=textured)

/**
 * Sprite batching система для оптимизации рендера (по образцу pspsdk/samples/gu/sprite)
 * Объединяет множественные draw вызовы в пачки для минимизации texture bind'ов
 */
void graphics_bind_texture(texture_t* tex);         // Привязать текстуру для batch'а
void graphics_batch_sprite(float u1, float v1, float u2, float v2, 
                          float x, float y, float w, float h); // Добавить спрайт в batch
void graphics_flush_batch(void);                    // Принудительно отрисовать накопленные спрайты

// Pause screenshot функции
void graphics_take_pause_screenshot(void);          // Сохранить текущий кадр для паузы
void graphics_draw_pause_screenshot(void);          // Отрисовать сохранённый снимок

// Отладочные функции
void graphics_debug_draw_hoop_collision(int tileX, int tileY, int tileID); // Визуализация коллизий колец

#ifdef __cplusplus
}
#endif

#endif