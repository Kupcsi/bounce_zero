// level.h - Парсер оригинальных уровней Bounce
#ifndef LEVEL_H
#define LEVEL_H

#include <psptypes.h>
#include "tile_table.h"
#include "png.h"  // Включаем png.h для полного определения texture_t
#include "types.h" // Для Player структуры

// Константы тайлов (из оригинального TileCanvas.java)

/* --- Ring foreground control (for proper draw order) --- */
#define RING_FG_QUEUE_MAX 128  // Максимальное количество колец для отложенного рендера (хватит для любого уровня)
void level_set_ring_fg_defer(int on);
void level_flush_ring_foreground(void);

/* --- Tile flags and masks --- */
#define TILE_FLAG_WATER    0x40  // Флаг водного тайла (как в Java)
#define TILE_FLAG_MISC     0x80  // Дополнительный флаг
#define TILE_ID_MASK       0x3F  // Маска для извлечения ID тайла (биты 0-5)
#define TILE_FLAGS_MASK    0xC0  // Маска для извлечения флагов (биты 6-7)

/* ---------------------------------------------------------------------------
   Формат PSP: ABGR = 0xAABBGGRR. Исходники из Java: RGB = 0xRRGGBB.
   Конверсия из Java RGB в PSP ABGR: ABGR = 0xFFBBGGRR (R↔B, альфа = FF).

   Принятая семантика названий в проекте:
     • 11591920 (0xB0D3B0) — «голубой»
     • 0xFFE3D3A2          — «голубой»

   Подробные соответствия:

   1) Java: 11591920 (0xB0D3B0) — голубой
      Java-каналы: R=0xB0 (176), G=0xD3 (211), B=0xB0 (176)

      PSP: 0xFFE3D3A2 — голубой
      PSP-каналы: A=0xFF (255), B=0xE3 (227), G=0xD3 (211), R=0xA2 (162)

   2) Java: 1073328 (0x106030) — синий
      Java-каналы: R=0x10 (16), G=0x60 (96), B=0x30 (48)

      PSP: 0xFFB06010 — синий
      PSP-каналы: A=0xFF (255), B=0xB0 (176), G=0x60 (96), R=0x10 (16)

   Примечание: словесные названия («голубой», «синий») соответствуют терминологии проекта.
   Источником истины остаются канальные значения и указанные форматы.
--------------------------------------------------------------------------- */
#define BACKGROUND_COLOUR     0xFFE3D3A2  // голубой
#define WATER_COLOUR          0xFFB06010  // синий
#define ABOUT_BACKGROUND_COLOUR 0xFFFBFF6C  // Особый фон для About экрана

/* --- Resource paths (following Java BounceConst pattern) --- */
#define TILESET_PATH          "icons/objects_nm.png"  // Основной атлас тайлов

// Кольца для сбора (13-28 в оригинале)

// Размеры
#define MAX_LEVEL_WIDTH 255
#define MAX_LEVEL_HEIGHT 255
#define MAX_MOVING_OBJECTS 16

// Структура движущегося объекта (шипов)
typedef struct {
    short topLeft[2];       // Верхний левый угол области движения (в тайлах)  
    short botRight[2];      // Нижний правый угол области движения (в тайлах)
    short direction[2];     // Направление движения по X,Y
    short offset[2];        // Текущее смещение внутри области (в пикселях)
} MovingObject;

// Структура уровня
typedef struct {
    int width;              // Ширина карты в тайлах
    int height;             // Высота карты в тайлах
    int startPosX;          // Стартовая позиция игрока X (в пикселях)
    int startPosY;          // Стартовая позиция игрока Y (в пикселях)
    int ballSize;           // Размер мяча (0=маленький, 1=большой)
    int exitPosX;           // Позиция выхода X (в тайлах)
    int exitPosY;           // Позиция выхода Y (в тайлах)
    int totalRings;         // Общее количество колец для сбора
    
    // Движущиеся объекты
    int numMovingObjects;   // Количество движущихся объектов
    MovingObject movingObjects[MAX_MOVING_OBJECTS];
    
    // Карта тайлов
    short tileMap[MAX_LEVEL_HEIGHT][MAX_LEVEL_WIDTH];
} Level;

// Глобальный уровень
extern Level g_level;

// Функции для доступа к тайловому атласу
texture_t* level_get_tileset(void);
int level_get_tiles_per_row(void);

// Функции
int level_load_from_memory(const char* levelData, int dataSize);
int level_load_from_file(const char* filename);
int level_load_by_number(int levelNumber);
int level_get_tile_at(int tileX, int tileY);
void level_render_visible_area(int cameraX, int cameraY, int screenWidth, int screenHeight);

// Функции для движущихся объектов
void level_update_moving_objects(void);
int level_find_moving_object_at(int tileX, int tileY);

// Операции с тайлами карты (для событийной системы)
uint8_t level_get_id(int tx, int ty);              // Получить ID тайла (без флагов)
void level_set_id(int tx, int ty, uint8_t id);     // Установить ID тайла (с флагами)
void level_mark_tile_dirty(int tx, int ty);        // Пометить тайл как dirty (|= 0x80)
void level_deactivate_old_checkpoint(void);        // Деактивировать старый чекпоинт (7->8)
void level_mark_checkpoint_active(int tx, int ty); // Активировать чекпоинт ((id&0x7F)|0x88)
void level_set_respawn(int tx, int ty);            // Установить новую точку респауна

// Cleanup
void level_cleanup(void);

#endif