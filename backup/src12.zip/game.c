#include "game.h"
#include "graphics.h"
#include "input.h"
#include "types.h"
#include "level.h"  // Содержит #include "png.h" и extern объявления
#include "tile_table.h" // Для TILE_SIZE
#include "menu.h"
#include <pspctrl.h>

Game g_game;

// УБРАЛИ дублированные extern объявления - они теперь в level.h
// extern texture_t* g_tileset;
// extern int g_tiles_per_row;

#define SCREEN_HEIGHT 272
#define CAMERA_UNINITIALIZED -999

// Статическая переменная для вертикальной камеры с мертвой зоной
static int s_currentCameraY = CAMERA_UNINITIALIZED;

// Проверка является ли уровень маленьким (нуждается в центрировании)
static inline int is_level_small(void) {
    return (g_level.height * TILE_SIZE) < SCREEN_HEIGHT;
}

// Получить правильное смещение камеры для центрирования маленького уровня
static inline int get_center_offset(void) {
    int levelPixelHeight = g_level.height * TILE_SIZE;
    return -(SCREEN_HEIGHT - levelPixelHeight) / 2;
}

void game_reset_camera(void) {
    if (is_level_small()) {
        s_currentCameraY = get_center_offset();
    } else {
        s_currentCameraY = CAMERA_UNINITIALIZED; // Будет инициализирована позицией игрока
    }
}

void game_init(void) {
    g_game.state = STATE_MENU;
    g_game.menu_selection = 0;
    g_game.selected_level = 1;
    g_game.buffered_jump = 0;
    
    // Инициализация меню
    menu_init();
    
    // Попробуем загрузить уровень 1, если не получится - тестовый
    if (!level_load_by_number(1)) {
        // Если нет файла - используем тестовый уровень
        level_create_test_level();
    }
    
    // Инициализация игрока из данных уровня
    player_init(&g_game.player, g_level.startPosX, g_level.startPosY, 
                g_level.ballSize == 0 ? SMALL_SIZE_STATE : LARGE_SIZE_STATE);
}

void game_update(void) {
    switch(g_game.state) {
        case STATE_MENU:
            menu_update();
            break;
            
        case STATE_LEVEL_SELECT:
            level_select_update();
            break;
            
        case STATE_GAME: {
            // Обновление направления из инпута
            Player* p = &g_game.player;
            
            // ВАЖНО: НЕ сбрасываем направления автоматически!
            // Только устанавливаем/сбрасываем по нажатию/отпусканию
            
            // Движение ВЛЕВО
            if(input_held(PSP_CTRL_LEFT)) {
                set_direction(p, MOVE_LEFT);  
            } else {
                release_direction(p, MOVE_LEFT);  // Сбрасываем если НЕ нажато
            }
            
            // Движение ВПРАВО  
            if(input_held(PSP_CTRL_RIGHT)) {
                set_direction(p, MOVE_RIGHT);  
            } else {
                release_direction(p, MOVE_RIGHT);  // Сбрасываем если НЕ нажато
            }
            
            // ПРЫЖОК: проверяем буфер или текущее нажатие
            if(g_game.buffered_jump || input_pressed(PSP_CTRL_CROSS)) {
                set_direction(p, MOVE_UP);
            }
            
            // Обновление физики
            player_update(p);
            
            // ИСПРАВЛЕНИЕ: явно сбрасываем буфер прыжка после обработки
            g_game.buffered_jump = 0;
            
            // Возврат в меню
            if(input_pressed(PSP_CTRL_START)) {
                g_game.state = STATE_MENU;
            }
            break;
        }
            
        case STATE_ABOUT:
            about_update();
            break;
            
        case STATE_EXIT:
            // Ничего не делаем, выход обрабатывается в main.c
            break;
    }
}

void game_render(void) {
    graphics_clear(0xFFE3D3A2);
    
    switch(g_game.state) {
        case STATE_MENU:
            menu_render();
            break;
            
        case STATE_LEVEL_SELECT:
            level_select_render();
            break;
            
        case STATE_GAME: {
            Player* p = &g_game.player;
            
            // Горизонтальная камера - следует за игроком (как раньше)
            int cameraX = p->xPos - SCREEN_WIDTH / 2;
            
            // Вертикальная камера с мертвой зоной
            if (s_currentCameraY == CAMERA_UNINITIALIZED) {
                // Первая инициализация - только для больших уровней
                s_currentCameraY = p->yPos - SCREEN_HEIGHT / 2;
            }
            
            // Размеры мертвой зоны (30% сверху и снизу)
            int deadZoneTop = (int)(SCREEN_HEIGHT * 0.3f);
            int deadZoneBottom = SCREEN_HEIGHT - deadZoneTop;
            
            // Мертвая зона работает только для больших уровней
            if (!is_level_small()) {
                int tempPlayerScreenY = p->yPos - s_currentCameraY;
                
                if (tempPlayerScreenY < deadZoneTop) {
                    // Игрок слишком высоко - двигаем камеру вверх
                    s_currentCameraY = p->yPos - deadZoneTop;
                } else if (tempPlayerScreenY > deadZoneBottom) {
                    // Игрок слишком низко - двигаем камеру вниз
                    s_currentCameraY = p->yPos - deadZoneBottom;
                }
                // Иначе камера остается на месте (мертвая зона)
            }
            
            int cameraY = s_currentCameraY;
            
            // Ограничиваем камеру границами уровня
            int maxCameraX = g_level.width * TILE_SIZE - SCREEN_WIDTH;
            int maxCameraY = g_level.height * TILE_SIZE - SCREEN_HEIGHT;
            
            if (cameraX < 0) cameraX = 0;
            if (cameraX > maxCameraX && maxCameraX > 0) cameraX = maxCameraX;
            
            if (is_level_small()) {
                // Для маленьких уровней фиксируем камеру по центру
                cameraY = get_center_offset();
            } else {
                // Обычное ограничение для больших уровней
                if (cameraY < 0) cameraY = 0;
                if (cameraY > maxCameraY && maxCameraY > 0) cameraY = maxCameraY;
            }
            
            // Обновляем позиции движущихся объектов
            level_update_moving_objects();
            
            // Рендерим уровень
            level_set_ring_fg_defer(1);
            level_render_visible_area(cameraX, cameraY, SCREEN_WIDTH, SCREEN_HEIGHT);
            
            // Игрок - позиция относительно камеры
            int playerScreenX = p->xPos - cameraX;
            int playerScreenY = p->yPos - cameraY;
            
            // ИСПРАВЛЕНО: Рисуем спрайт шара вместо цветного квадрата
            if (g_tileset && g_tiles_per_row > 0) {
                int ballSpriteX, ballSpriteY;
                
                if (p->ballState == BALL_STATE_POPPED) {
                    // Лопнувший шар - tileImages[48] = extractImage(image, 0, 1)
                    // Атлас позиция (0,1) = индекс 4
                    ballSpriteX = 0 * TILE_SIZE;
                    ballSpriteY = 1 * TILE_SIZE;
                } else if (p->sizeState == LARGE_SIZE_STATE) {
                    // Большой шар - tileImages[49] = createLargeBallImage(extractImage(image, 3, 0))
                    // Атлас позиция (3,0) = индекс 3, но это составной 2x2, используем базовый кусок
                    ballSpriteX = 3 * TILE_SIZE;
                    ballSpriteY = 0 * TILE_SIZE;
                } else {
                    // Маленький шар - tileImages[47] = extractImage(image, 2, 0)
                    // Атлас позиция (2,0) = индекс 2
                    ballSpriteX = 2 * TILE_SIZE;
                    ballSpriteY = 0 * TILE_SIZE;
                }
                
                sprite_rect_t ballSprite = png_create_sprite_rect(g_tileset, ballSpriteX, ballSpriteY, TILE_SIZE, TILE_SIZE);
                
                // Для большого мяча рендерим 2x2
                if (p->sizeState == LARGE_SIZE_STATE) {
                    // Рендерим 4 куска для большого мяча (как в Java createLargeBallImage)
                    for (int dy = 0; dy < 2; dy++) {
                        for (int dx = 0; dx < 2; dx++) {
                            png_xform_t xf = PNG_XFORM_IDENTITY;
                            if (dx == 1) xf = PNG_XFORM_FLIP_X;
                            if (dy == 1 && dx == 0) xf = PNG_XFORM_FLIP_Y;
                            if (dy == 1 && dx == 1) xf = PNG_XFORM_ROT_180;
                            
                            float x = (float)(playerScreenX + HALF_ENLARGED_SIZE - TILE_SIZE + dx * TILE_SIZE);
                            float y = (float)(playerScreenY + HALF_ENLARGED_SIZE - TILE_SIZE + dy * TILE_SIZE);
                            
                            if (xf == PNG_XFORM_IDENTITY) {
                                png_draw_sprite(g_tileset, &ballSprite, x, y, (float)TILE_SIZE, (float)TILE_SIZE);
                            } else {
                                png_draw_sprite_xform(g_tileset, &ballSprite, x, y, (float)TILE_SIZE, (float)TILE_SIZE, xf);
                            }
                        }
                    }
                } else {
                    // Обычный рендер для маленького мяча
                    png_draw_sprite(g_tileset, &ballSprite, (float)playerScreenX, (float)playerScreenY, (float)p->ballSize, (float)p->ballSize);
                }
            } else {
                // Фолбэк на цветной квадрат если атлас не загружен
                u32 player_color = 0xFF0000AA; // Синий по умолчанию
                if (!p->mGroundedFlag) {
                    player_color = 0xFFAA0000; // Красный в воздухе
                }
                if (p->gravBonusCntr > 0) {
                    player_color = 0xFFAAAAA; // Серый при обратной гравитации
                }
                if (p->sizeState == LARGE_SIZE_STATE) {
                    player_color = 0xFF00AA00; // Зеленый если большой
                }
                
                graphics_draw_rect(playerScreenX, playerScreenY, p->ballSize, p->ballSize, player_color);
            }
            
            // Инструкции и отладка (поверх всего)
            level_flush_ring_foreground();
            level_set_ring_fg_defer(0);

            sceGuDisable(GU_TEXTURE_2D);

            // Вывод размера карты (HUD) — чёрным, внизу слева
            if (g_level.width > 0 && g_level.height > 0) {
                char level_debug[50];
                level_debug[0] = 'L'; level_debug[1] = 'v'; level_debug[2] = 'l'; level_debug[3] = ':'; level_debug[4] = ' ';
                int pos = 5;
                int w = g_level.width;
                if (w >= 100) { level_debug[pos++] = '0' + (w / 100); w %= 100; }
                if (w >= 10)  { level_debug[pos++] = '0' + (w / 10);  w %= 10; }
                level_debug[pos++] = '0' + w;
                level_debug[pos++] = 'x';
                int h = g_level.height;
                if (h >= 100) { level_debug[pos++] = '0' + (h / 100); h %= 100; }
                if (h >= 10)  { level_debug[pos++] = '0' + (h / 10);  h %= 10; }
                level_debug[pos++] = '0' + h;
                level_debug[pos] = '\0';
                graphics_draw_text(10.0f, 258.0f, level_debug, 0xFF000000);
            }
            graphics_draw_text(10.0f, 30.0f, p->mGroundedFlag ? "GROUNDED" : "AIRBORNE", 0xFFFFFFFF);
            
            // Показать размер мяча
            if (p->sizeState == SMALL_SIZE_STATE) {
                graphics_draw_text(10.0f, 50.0f, "SIZE: NORMAL", 0xFFFFFFFF);
            } else {
                graphics_draw_text(10.0f, 50.0f, "SIZE: LARGE", 0xFFFFFFFF);
            }
            
            // Простая отладка
            if (g_level.width > 0) {
                graphics_draw_text(10.0f, 110.0f, "LEVEL LOADED", 0xFF00FF00);
            } else {
                graphics_draw_text(10.0f, 110.0f, "TEST LEVEL", 0xFFFFFF00);
            }
            
            
            // Вернуть режим текстур для остального
            sceGuEnable(GU_TEXTURE_2D);
            sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);

            break;
        }
            
        case STATE_ABOUT:
            about_render();
            break;
            
        case STATE_EXIT:
            // Экран выхода
            graphics_draw_text(200.0f, 120.0f, "EXITING...", 0xFFFFFFFF);
            break;
    }
}

// Добавляем функцию cleanup для game
void game_cleanup(void) {
    menu_cleanup();
}