#ifndef INPUT_H
#define INPUT_H

#include <pspctrl.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
 * Инициализация подсистемы ввода
 * Настраивает контроллер и обнуляет состояния
 */
void input_init(void);

/**
 * Обновить состояние контроллера
 * Должна вызываться каждый кадр для корректной работы input_pressed()
 */
void input_update(void);

/**
 * Проверить нажатие кнопки (срабатывает один раз за нажатие)
 * @param button Маска кнопки (PSP_CTRL_CROSS, PSP_CTRL_CIRCLE, и т.д.)
 * @return 1 если кнопка только что была нажата, иначе 0
 */
int input_pressed(int button);

/**
 * Проверить удержание кнопки
 * @param button Маска кнопки (PSP_CTRL_CROSS, PSP_CTRL_CIRCLE, и т.д.)
 * @return 1 если кнопка в данный момент удерживается, иначе 0
 */
int input_held(int button);

#ifdef __cplusplus
}
#endif

#endif