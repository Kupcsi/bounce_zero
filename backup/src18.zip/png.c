// png.c - Загрузка PNG файлов
#include "png.h"
#include "graphics.h"  // Для новой batch системы
#include <pspgu.h>
#include <pspkernel.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

// Включаем stb_image для загрузки PNG
#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO  // Используем свои функции чтения файлов
#define STBI_ONLY_PNG  // Только PNG поддержка
#include "stb_image.h"

/*
 * ПЛАТФОРМО-ЗАВИСИМЫЕ ДЕТАЛИ TEXTURE_T:
 * - Для GU_PSM_8888 данные хранятся как RGBA байты в памяти
 * - На PSP (little-endian) это соответствует ABGR словам
 * - КРИТИЧНО: после изменения tex->data требуется sceKernelDcacheWritebackRange()
 *   перед следующим sceGuTexImage() для синхронизации кэша
 */

// Структура для передачи данных файла в stb_image
typedef struct {
    unsigned char* data;
    int size;
    int pos;
} MemoryBuffer;

// Структура вершины для текстурированных примитивов
typedef struct {
    float u, v;
    float x, y, z;
} TextureVertex;

// Функция чтения для stb_image
static int read_func(void* user, char* data, int size) {
    MemoryBuffer* buffer = (MemoryBuffer*)user;
    if (buffer->pos + size > buffer->size) {
        size = buffer->size - buffer->pos;
    }
    if (size <= 0) return 0;
    
    memcpy(data, buffer->data + buffer->pos, size);
    buffer->pos += size;
    return size;
}

// Функция пропуска для stb_image
static void skip_func(void* user, int n) {
    MemoryBuffer* buffer = (MemoryBuffer*)user;
    buffer->pos += n;
    if (buffer->pos > buffer->size) {
        buffer->pos = buffer->size;
    }
}

// Функция проверки конца файла для stb_image
static int eof_func(void* user) {
    MemoryBuffer* buffer = (MemoryBuffer*)user;
    return buffer->pos >= buffer->size;
}

// Утилита для открытия файла с fallback путями
static FILE* open_with_fallback(const char* path) {
    const char* prefixes[] = { "", "/", "./" };
    char full_path[512];
    
    for (int i = 0; i < 3; i++) {
        snprintf(full_path, sizeof(full_path), "%s%s", prefixes[i], path);
        FILE* file = fopen(full_path, "rb");
        if (file) return file;
    }
    
    return NULL;
}

texture_t* png_load_texture(const char* path) {
    // Открываем файл с fallback путями
    FILE* file = open_with_fallback(path);
    
    if (!file) {
        printf("PNG file not found: %s\n", path);
        return NULL;
    }
    
    // Читаем весь файл в память
    fseek(file, 0, SEEK_END);
    long file_size = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    if (file_size <= 0) {
        fclose(file);
        printf("PNG file is empty: %s\n", path);
        return NULL;
    }
    
    unsigned char* file_data = (unsigned char*)malloc(file_size);
    if (!file_data) {
        fclose(file);
        printf("Failed to allocate memory for PNG file\n");
        return NULL;
    }
    
    size_t read_bytes = fread(file_data, 1, file_size, file);
    fclose(file);
    
    if (read_bytes != (size_t)file_size) {
        free(file_data);
        printf("Failed to read PNG file completely\n");
        return NULL;
    }
    
    // Настраиваем буфер для stb_image
    MemoryBuffer buffer;
    buffer.data = file_data;
    buffer.size = file_size;
    buffer.pos = 0;
    
    stbi_io_callbacks callbacks;
    callbacks.read = read_func;
    callbacks.skip = skip_func;
    callbacks.eof = eof_func;
    
    // Загружаем PNG через stb_image
    int width, height, channels;
    unsigned char* image_data = stbi_load_from_callbacks(&callbacks, &buffer, &width, &height, &channels, 4);
    
    free(file_data);
    
    if (!image_data) {
        printf("Failed to load PNG: %s (stbi error: %s)\n", path, stbi_failure_reason());
        return NULL;
    }
    
    printf("Loaded PNG: %s (%dx%d, %d channels)\n", path, width, height, channels);
    
    // Создаем текстуру с unified cleanup для предотвращения утечек памяти
    texture_t* tex = NULL;
    unsigned char* tex_data = NULL;
    
    tex = (texture_t*)malloc(sizeof(texture_t));
    if (!tex) {
        goto cleanup;
    }
    
    // Округляем размеры до степени двойки (требование PSP)
    int tex_width = 1;
    int tex_height = 1;
    while (tex_width < width) tex_width <<= 1;
    while (tex_height < height) tex_height <<= 1;
    
    tex->width = tex_width;
    tex->height = tex_height;
    tex->actual_width = width;
    tex->actual_height = height;
    tex->format = GU_PSM_8888;
    
    // Выделяем память для текстуры
    size_t tex_size = (size_t)tex_width * (size_t)tex_height * 4;
    tex_data = memalign(16, tex_size);
    if (!tex_data) {
        goto cleanup;
    }
    
    tex->data = tex_data;
    
    // Очищаем память текстуры
    memset(tex->data, 0, tex_size);
    
    // Копируем данные изображения в текстуру
    unsigned char* dest = (unsigned char*)tex->data;
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            int src_idx = (y * width + x) * 4;
            int dst_idx = (y * tex_width + x) * 4;
            
            // Копируем RGBA байты как есть (укладка соответствует GU_PSM_8888 на PSP)
            dest[dst_idx + 0] = image_data[src_idx + 0]; // R
            dest[dst_idx + 1] = image_data[src_idx + 1]; // G
            dest[dst_idx + 2] = image_data[src_idx + 2]; // B
            dest[dst_idx + 3] = image_data[src_idx + 3]; // A
        }
    }
    
    // Writeback кэша данных после записи в tex->data для корректной передачи в GPU
    // Invalidate не нужен - CPU только записал данные, никто их не модифицировал
    sceKernelDcacheWritebackRange(tex->data, tex_size);
    
    printf("PNG texture created: %dx%d (actual: %dx%d)\n", tex_width, tex_height, width, height);
    
    // Успешное завершение - освобождаем только image_data
    stbi_image_free(image_data);
    return tex;
    
cleanup:
    // Unified cleanup - освобождаем все ресурсы при ошибке
    if (tex_data) {
        free(tex_data);
    }
    if (tex) {
        free(tex);
    }
    if (image_data) {
        stbi_image_free(image_data);
    }
    return NULL;
}

sprite_rect_t png_create_sprite_rect(texture_t* tex, int x, int y, int w, int h) {
    sprite_rect_t rect;
    if (!tex || tex->width == 0 || tex->height == 0) {
        rect.u = 0.0f;
        rect.v = 0.0f;
        rect.width = 1.0f;
        rect.height = 1.0f;
        return rect;
    }
    
    rect.u = (float)x / (float)tex->width;
    rect.v = (float)y / (float)tex->height;
    rect.width  = (float)w / (float)tex->width;
    rect.height = (float)h / (float)tex->height;
    return rect;
}

void png_draw_sprite(texture_t* tex, sprite_rect_t* sprite, float x, float y, float w, float h) {
    if (!tex || !sprite || !tex->data) return;
    if (tex->width <= 0 || tex->height <= 0) return;
    if (w <= 0 || h <= 0) return;
    
    // Вычисляем UV координаты в пикселях (как раньше)
    float u1 = sprite->u * (float)tex->width;
    float v1 = sprite->v * (float)tex->height;
    float u2 = (sprite->u + sprite->width) * (float)tex->width;
    float v2 = (sprite->v + sprite->height) * (float)tex->height;
    
    // НОВОЕ: Используем batch систему вместо прямого рендера
    graphics_bind_texture(tex);  // Автоматически flush'нет если текстура изменилась
    graphics_batch_sprite(u1, v1, u2, v2, x, y, w, h);  // Добавляем в batch
}

void png_free_texture(texture_t* tex) {
    if (!tex) return;
    if (tex->data) {
        free(tex->data);
        tex->data = NULL;
    }
    free(tex);
}

void png_draw_sprite_uv4(texture_t* tex,
                         float u_tl, float v_tl,
                         float u_tr, float v_tr,
                         float u_bl, float v_bl,
                         float u_br, float v_br,
                         float x, float y, float w, float h)
{
    if (!tex || !tex->data) return;
    if (w <= 0 || h <= 0) return;

    TextureVertex* v = (TextureVertex*)sceGuGetMemory(4 * sizeof(TextureVertex));
    if (!v) return;

    // Clamp to texture bounds
    float tw = (float)tex->width, th = (float)tex->height;
    
if (u_tl < 0) { u_tl = 0; }
if (v_tl < 0) { v_tl = 0; }
if (u_tl > tw) { u_tl = tw; }
if (v_tl > th) { v_tl = th; }

if (u_tr < 0) { u_tr = 0; }
if (v_tr < 0) { v_tr = 0; }
if (u_tr > tw) { u_tr = tw; }
if (v_tr > th) { v_tr = th; }

if (u_bl < 0) { u_bl = 0; }
if (v_bl < 0) { v_bl = 0; }
if (u_bl > tw) { u_bl = tw; }
if (v_bl > th) { v_bl = th; }

if (u_br < 0) { u_br = 0; }
if (v_br < 0) { v_br = 0; }
if (u_br > tw) { u_br = tw; }
if (v_br > th) { v_br = th; }


    // Top-left
    v[0].u = u_tl; v[0].v = v_tl;
    v[0].x = x;    v[0].y = y;    v[0].z = 0.0f;
    // Top-right
    v[1].u = u_tr; v[1].v = v_tr;
    v[1].x = x + w; v[1].y = y;   v[1].z = 0.0f;
    // Bottom-left
    v[2].u = u_bl; v[2].v = v_bl;
    v[2].x = x;    v[2].y = y + h; v[2].z = 0.0f;
    // Bottom-right
    v[3].u = u_br; v[3].v = v_br;
    v[3].x = x + w; v[3].y = y + h; v[3].z = 0.0f;

    // Set texture state
    sceGuTexMode(tex->format, 0, 0, 0);
    sceGuTexImage(0, tex->width, tex->height, tex->width, tex->data);
    sceGuTexFunc(GU_TFX_REPLACE, GU_TCC_RGBA);
    sceGuTexFilter(GU_NEAREST, GU_NEAREST);
    sceGuTexWrap(GU_CLAMP, GU_CLAMP);

    // Draw as triangle strip: TL, TR, BL, BR
    sceGuDrawArray(GU_TRIANGLE_STRIP,
                   GU_TEXTURE_32BITF|GU_VERTEX_32BITF|GU_TRANSFORM_2D,
                   4, 0, v);
}

void png_draw_sprite_xform(texture_t* tex, sprite_rect_t* sprite,
                           float x, float y, float w, float h,
                           png_xform_t xform)
{
    if (!tex || !sprite) return;

    // Базовые границы UV в пикселях
    const float u1 = sprite->u * (float)tex->width;
    const float v1 = sprite->v * (float)tex->height;
    const float u2 = (sprite->u + sprite->width)  * (float)tex->width;
    const float v2 = (sprite->v + sprite->height) * (float)tex->height;

    // Исходные углы (TL, TR, BL, BR)
    float U[4] = { u1, u2, u1, u2 };
    float V[4] = { v1, v1, v2, v2 };

    // Раскладываем enum в (rot, fx, fy)
    int rot = 0, fx = 0, fy = 0; // rot: 0,1,2,3 (по часовой)
    switch (xform) {
        default:
        case PNG_XFORM_IDENTITY: break;
        case PNG_XFORM_ROT_90:   rot = 1; break;
        case PNG_XFORM_ROT_180:  rot = 2; break;
        case PNG_XFORM_ROT_270:  rot = 3; break;
        case PNG_XFORM_FLIP_X:   fx  = 1; break;
        case PNG_XFORM_FLIP_Y:   fy  = 1; break;
        case PNG_XFORM_ROT_270_FLIP_X:   rot = 3; fx = 1; break;
        case PNG_XFORM_ROT_270_FLIP_Y:   rot = 3; fy = 1; break;
        case PNG_XFORM_ROT_270_FLIP_XY:  rot = 3; fx = 1; fy = 1; break;
    }

    // Применяем ROT_N (перестановка углов по часовой)
    // Индексы: 0=TL, 1=TR, 2=BL, 3=BR
    int idx[4] = {0,1,2,3};
    for (int r = 0; r < rot; ++r) {
        int TL = idx[0], TR = idx[1], BL = idx[2], BR = idx[3];
        idx[0] = TR; // TL <- TR
        idx[1] = BR; // TR <- BR
        idx[2] = TL; // BL <- TL
        idx[3] = BL; // BR <- BL
    }

    // Затем FLIP_X: меняем местами TL<->TR, BL<->BR
    if (fx) {
        int t = idx[0]; idx[0] = idx[1]; idx[1] = t;
            t = idx[2]; idx[2] = idx[3]; idx[3] = t;
    }

    // Затем FLIP_Y: меняем местами TL<->BL, TR<->BR
    if (fy) {
        int t = idx[0]; idx[0] = idx[2]; idx[2] = t;
            t = idx[1]; idx[1] = idx[3]; idx[3] = t;
    }

    // Собираем конечные UV
    const float tl_u = U[idx[0]], tl_v = V[idx[0]];
    const float tr_u = U[idx[1]], tr_v = V[idx[1]];
    const float bl_u = U[idx[2]], bl_v = V[idx[2]];
    const float br_u = U[idx[3]], br_v = V[idx[3]];

    png_draw_sprite_uv4(tex, tl_u, tl_v, tr_u, tr_v, bl_u, bl_v, br_u, br_v, x, y, w, h);
}
