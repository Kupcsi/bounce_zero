#include "tile_table.h"
#include "level.h"  // Для TILE_FLAG_WATER

// Константы для нормалей поверхностей в Q15
static const q15_t Q15_NEG_ONE = -32767, Q15_ZERO = 0, Q15_INV_SQRT2 = 23170;

// Макросы для нормалей
#define N_NONE Q15_ZERO, Q15_ZERO
#define N_SOLID Q15_ZERO, Q15_NEG_ONE
#define N_BR Q15_INV_SQRT2, -Q15_INV_SQRT2
#define N_BL -Q15_INV_SQRT2, -Q15_INV_SQRT2
#define N_TR Q15_INV_SQRT2, Q15_INV_SQRT2
#define N_TL -Q15_INV_SQRT2, Q15_INV_SQRT2

// ПРАВИЛЬНАЯ таблица тайлов на основе точного анализа Java кода
__attribute__((aligned(64)))
static const TileMeta TILE_DB[67] = {
    /* case 00 - EMPTY - пустой тайл, фон заливается цветом */
    { EMPTY_SPACE, ORIENT_NONE, 0, N_NONE, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE },

    /* case 01 - BLOCK          tileImages[0] = extractImage(image, 1, 0) = атлас[1] */
    { BRICK_RED, ORIENT_NONE, 0, N_SOLID, 1, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE },

    /* case 02 - RUBBER_BLOCK   tileImages[1] = extractImage(image, 1, 2) = атлас[9] */
    { BRICK_BLUE, ORIENT_NONE, 0, N_SOLID, 9, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE },

    /* case 03 - Шипы направлены вверх (тонкие горизонтально, как Java case 3,5: i+=4, k-=4) 
       Java: bool ? tileImages[6] : tileImages[2] - оба из атласа (0,3) */
    { SPIKE_FLOOR, ORIENT_SPIKE_THIN_HORIZ, 0, N_SOLID, 12, TF_NONE, 0, SPECIAL_WATER_VARIANT, 12 , TF_NONE },

    /* 04 - Шипы направлены влево (тонкие вертикально, как Java case 4,6: j+=4, m-=4)
       Java: bool ? tileImages[9] : tileImages[5] = manipulateImage(базовый, 5) = ROT_270 */
    { SPIKE_LEFT_WALL, ORIENT_SPIKE_THIN_VERT, 0, N_SOLID, 12, TF_ROT_270, 0, SPECIAL_WATER_VARIANT, 12 , TF_ROT_270 },

    /* 05 - Шипы направлены вниз (тонкие горизонтально, как Java case 3,5: i+=4, k-=4)
       Java: bool ? tileImages[7] : tileImages[3] = manipulateImage(базовый, 1) = FLIP_Y */
    { SPIKE_CEILING, ORIENT_SPIKE_THIN_HORIZ, 0, N_SOLID, 12, TF_FLIP_Y, 0, SPECIAL_WATER_VARIANT, 12 , TF_FLIP_Y, 0 },

    /* 06 - Шипы направлены вправо (тонкие вертикально, как Java case 4,6: j+=4, m-=4)
       Java: bool ? tileImages[8] : tileImages[4] = manipulateImage(базовый, 3) = ROT_90 */
    { SPIKE_RIGHT_WALL, ORIENT_SPIKE_THIN_VERT, 0, N_SOLID, 12, TF_ROT_90, 0, SPECIAL_WATER_VARIANT, 12 , TF_ROT_90, 0 },

    /* 07 CHECKPOINT - tileImages[10] = extractImage(image, 0, 4) = атлас[16] */
    { RESPAWN_GEM, ORIENT_NONE, 0, N_NONE, 16, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* 08 АКТИВИРОВАННЫЙ ЧЕКПОИНТ - tileImages[11] = extractImage(image, 3, 4) = атлас[19] - ПРОХОДИМЫЙ */
    { RESPAWN_INDICATOR, ORIENT_NONE, 0, N_NONE, 19, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* 09 EXIT - составной тайл из tileImages[12] = createExitImage(атлас[14]) */
    { EXIT_TILE, ORIENT_NONE, 0, N_SOLID, 14, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* 10 MOVING_SPIKES - составной из tileImages[46] = атлас[13] (специальная коллизия 24x24) */
    { MOVING_SPIKE_TILE, ORIENT_NONE, 0, N_NONE, 13, TF_NONE, 0, SPECIAL_COMPOSITE, 0, TF_NONE, 0 },

    /* 11 */
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    /* 12 */
    { GENERIC_TILE, ORIENT_NONE, 0, N_NONE, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* 13 RING - ID_HOOP_ACTIVE_VERT_TOP = 13 */
    { HOOP_ACTIVE, ORIENT_VERT_TOP, 0, N_NONE, 21, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 14 RING - ID_HOOP_ACTIVE_VERT_BOTTOM = 14 */
    { HOOP_ACTIVE, ORIENT_VERT_BOTTOM, 0, N_NONE, 21, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 15 RING - ID_HOOP_ACTIVE_HORIZ_LEFT = 15 */
    { HOOP_ACTIVE, ORIENT_HORIZ_LEFT, 0, N_NONE, 21, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 16 RING - ID_HOOP_ACTIVE_HORIZ_RIGHT = 16 */
    { HOOP_ACTIVE, ORIENT_HORIZ_RIGHT, 0, N_NONE, 21, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 17 RING - ID_HOOP_INACTIVE_VERT_TOP = 17 */ 
    { HOOP_INACTIVE, ORIENT_VERT_TOP, 0, N_NONE, 23, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 18 RING - ID_HOOP_INACTIVE_VERT_BOTTOM = 18 */
    { HOOP_INACTIVE, ORIENT_VERT_BOTTOM, 0, N_NONE, 23, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 19 RING - ID_HOOP_INACTIVE_HORIZ_LEFT = 19 */
    { HOOP_INACTIVE, ORIENT_HORIZ_LEFT, 0, N_NONE, 23, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 20 RING - ID_HOOP_INACTIVE_HORIZ_RIGHT = 20 */
    { HOOP_INACTIVE, ORIENT_HORIZ_RIGHT, 0, N_NONE, 23, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 21 RING - ID_LARGE_HOOP_ACTIVE_VERT_TOP = 21 */
    { LARGE_HOOP_ACTIVE, ORIENT_VERT_TOP, 0, N_NONE, 20, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 22 RING - ID_LARGE_HOOP_ACTIVE_VERT_BOTTOM = 22 */
    { LARGE_HOOP_ACTIVE, ORIENT_VERT_BOTTOM, 0, N_NONE, 20, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 23 RING - ID_LARGE_HOOP_ACTIVE_HORIZ_LEFT = 23 */
    { LARGE_HOOP_ACTIVE, ORIENT_HORIZ_LEFT, 0, N_NONE, 20, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 24 RING - ID_LARGE_HOOP_ACTIVE_HORIZ_RIGHT = 24 */
    { LARGE_HOOP_ACTIVE, ORIENT_HORIZ_RIGHT, 0, N_NONE, 20, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 25 RING - ID_LARGE_HOOP_INACTIVE_VERT_TOP = 25 */
    { LARGE_HOOP_INACTIVE, ORIENT_VERT_TOP, 0, N_NONE, 22, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 26 RING - ID_LARGE_HOOP_INACTIVE_VERT_BOTTOM = 26 */
    { LARGE_HOOP_INACTIVE, ORIENT_VERT_BOTTOM, 0, N_NONE, 22, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 27 RING - ID_LARGE_HOOP_INACTIVE_HORIZ_LEFT = 27 */
    { LARGE_HOOP_INACTIVE, ORIENT_HORIZ_LEFT, 0, N_NONE, 22, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },
    /* 28 RING - ID_LARGE_HOOP_INACTIVE_HORIZ_RIGHT = 28 */
    { LARGE_HOOP_INACTIVE, ORIENT_HORIZ_RIGHT, 0, N_NONE, 22, TF_NONE, 0, SPECIAL_HOOP | SPECIAL_WATER_VARIANT, 0, TF_NONE },   
    
    /* 29 - тайл 29 в Java: tileImages[45] = extractImage(image, 3, 3) = атлас[15] - EXTRA LIFE (хрустальный шар) */
    { EXTRA_LIFE, ORIENT_NONE, 0, N_NONE, 15, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* case 30 - Рампа пол: скос верхний левый ◣ (поворот на 180°)
       Java: bool ? tileImages[61] : tileImages[57] = manipulateImage(базовый, 4) = ROT_180 */
    { TRIANGLE_FLOOR, ORIENT_TL, 0, N_TL, 0, TF_ROT_180, 0, SPECIAL_WATER_VARIANT, 0 , TF_NONE, 0 },

    /* case 31 - Рампа пол: скос верхний правый ◤ (поворот на 90°)
       Java: bool ? tileImages[60] : tileImages[56] = manipulateImage(базовый, 3) = ROT_90 */
    { TRIANGLE_FLOOR, ORIENT_TR, 0, N_TR, 0, TF_ROT_90, 0, SPECIAL_WATER_VARIANT, 0 , TF_NONE, 0 },

    /* case 32 - Рампа пол: скос нижний правый ◥ (базовый спрайт) Java: bool ? tileImages[59] : tileImages[55] = extractImageBG(базовый, 0, 0) */
    { TRIANGLE_FLOOR, ORIENT_BR, 0, N_BR, 0, TF_NONE, 0, SPECIAL_WATER_VARIANT, 0 , TF_NONE, 0 },

    /* case 33 - Рампа пол: скос нижний левый ◢ (поворот на 270°) Java: bool ? tileImages[62] : tileImages[58] = manipulateImage(базовый, 5) = ROT_270 */
    { TRIANGLE_FLOOR, ORIENT_BL, 0, N_BL, 0, TF_ROT_270, 0, SPECIAL_WATER_VARIANT, 0 , TF_NONE, 0 },

    /* case 34 - Рампа потолок: скос верхний левый ◣ (поворот на 180°) Java: tileImages[65] = manipulateImage(базовый, 4) = ROT_180 */
    { TRIANGLE_FLOOR, ORIENT_TL, 0, N_TL, 8, TF_ROT_180, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* case 35 - Рампа потолок: скос верхний правый ◤ (поворот на 90°) Java: tileImages[64] = manipulateImage(базовый, 3) = ROT_90 */
    { TRIANGLE_FLOOR, ORIENT_TR, 0, N_TR, 8, TF_ROT_90, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* case 36 - Рампа потолок: скос нижний правый ◥ (базовый спрайт) Java: tileImages[63] = extractImage(image, 0, 2) */
    { TRIANGLE_FLOOR, ORIENT_BR, 0, N_BR, 8, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* case 37 - Рампа потолок: скос нижний левый ◢ (поворот на 270°) Java: tileImages[66] = manipulateImage(базовый, 5) = ROT_270 */
    { TRIANGLE_FLOOR, ORIENT_BL, 0, N_BL, 8, TF_ROT_270, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* 38 - ID_SPEED = 38 - бонус скорости */
    { SPEED_BONUS, ORIENT_NONE, 0, N_SOLID, 5, TF_FLIP_X, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* 39-42 SHRINK_TILE - tileImages[50] = extractImage(image, 3, 1) = атлас[7] */
    { DEFLATOR_TILE, ORIENT_NONE, 0, N_SOLID, 7, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { DEFLATOR_TILE, ORIENT_NONE, 0, N_SOLID, 7, TF_ROT_90, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { DEFLATOR_TILE, ORIENT_NONE, 0, N_SOLID, 7, TF_ROT_180, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { DEFLATOR_TILE, ORIENT_NONE, 0, N_SOLID, 7, TF_ROT_270, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* 43-46 GROW_TILE - tileImages[51] = extractImage(image, 2, 4) = атлас[18] */
    { INFLATOR_TILE, ORIENT_NONE, 0, N_SOLID, 18, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { INFLATOR_TILE, ORIENT_NONE, 0, N_SOLID, 18, TF_ROT_90, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { INFLATOR_TILE, ORIENT_NONE, 0, N_SOLID, 18, TF_ROT_180, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { INFLATOR_TILE, ORIENT_NONE, 0, N_SOLID, 18, TF_ROT_270, 0, SPECIAL_NONE, 0, TF_NONE, 0 },

    /* 47-50 GRAVITY_BONUS - ID_GRAVITY_FLOOR/LEFT_WALL/CEILING/RIGHT_WALL = 47-50 */
    { GRAVITY_BONUS, ORIENT_NONE, 0, N_SOLID, 11, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },     // ID_GRAVITY_FLOOR
    { GRAVITY_BONUS, ORIENT_NONE, 0, N_SOLID, 11, TF_ROT_90, 0, SPECIAL_NONE, 0, TF_NONE, 0 },   // ID_GRAVITY_LEFT_WALL
    { GRAVITY_BONUS, ORIENT_NONE, 0, N_SOLID, 11, TF_ROT_180, 0, SPECIAL_NONE, 0, TF_NONE, 0 },  // ID_GRAVITY_CEILING
    { GRAVITY_BONUS, ORIENT_NONE, 0, N_SOLID, 11, TF_ROT_270, 0, SPECIAL_NONE, 0, TF_NONE, 0 },  // ID_GRAVITY_RIGHT_WALL
    /* 51-54 JUMP_BONUS - ID_JUMP_FLOOR/LEFT_WALL/CEILING/RIGHT_WALL = 51-54 */
    { JUMP_BONUS, ORIENT_NONE, 0, N_SOLID, 5, TF_ROT_90, 0, SPECIAL_NONE, 0, TF_NONE, 0 },    // ID_JUMP_FLOOR 
    { JUMP_BONUS, ORIENT_NONE, 0, N_SOLID, 5, TF_ROT_180, 0, SPECIAL_NONE, 0, TF_NONE, 0 },   // ID_JUMP_LEFT_WALL
    { JUMP_BONUS, ORIENT_NONE, 0, N_SOLID, 5, TF_ROT_270, 0, SPECIAL_NONE, 0, TF_NONE, 0 },   // ID_JUMP_CEILING
    { JUMP_BONUS, ORIENT_NONE, 0, N_SOLID, 10, TF_ROT_90, 0, SPECIAL_NONE, 0, TF_NONE, 0 },   // ID_JUMP_RIGHT_WALL

    /* 55-66 - заполнители/неиспользуемые */
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 },
    { GENERIC_TILE, ORIENT_NONE, 0, N_SOLID, 255, TF_NONE, 0, SPECIAL_NONE, 0, TF_NONE, 0 }
};

// Функции доступа
const TileMeta* tile_meta_db(void) {
    return TILE_DB;
}

uint32_t tile_meta_count(void) {
    return 67;
}


// Вспомогательные функции
const char* tile_transform_name(TileTransform transform) {
    switch (transform) {
        case TF_NONE: return "NONE";
        case TF_FLIP_X: return "FLIP_X";
        case TF_FLIP_Y: return "FLIP_Y";
        case TF_FLIP_XY: return "FLIP_XY";
        case TF_ROT_90: return "ROT_90";
        case TF_ROT_180: return "ROT_180";
        case TF_ROT_270: return "ROT_270";
        default: return "UNKNOWN";
    }
}

int tile_needs_alt_sprite(const TileMeta* tile, int tile_flags) {
    return (tile->special_flags & SPECIAL_WATER_VARIANT) && (tile_flags & TILE_FLAG_WATER);
}
