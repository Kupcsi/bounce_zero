#ifndef MENU_H
#define MENU_H

#include "types.h"

// Константы расположения элементов меню
#define SCREEN_CENTER_X     240.0f    // Центр экрана по X

// Главное меню
#define MENU_TITLE_Y        50.0f     // Позиция заголовка "Bounce"
#define MENU_START_Y        110.0f    // Позиция пункта "START"
#define MENU_LEVEL_SELECT_Y 140.0f    // Позиция пункта "SELECT LEVEL"
#define MENU_ABOUT_Y        170.0f    // Позиция пункта "ABOUT" 
#define MENU_EXIT_Y         200.0f    // Позиция пункта "EXIT"
#define MENU_PADDING_X      5.0f      // Горизонтальный отступ выделения
#define MENU_PADDING_Y      5.0f      // Вертикальный отступ выделения

// Экран выбора уровня
#define LEVEL_SELECT_TITLE_Y 30.0f    // Позиция заголовка "SELECT LEVEL"
#define LEVEL_GRID_START_X   140      // Начальная X позиция сетки уровней
#define LEVEL_GRID_START_Y   80       // Начальная Y позиция сетки уровней  
#define LEVEL_CELL_WIDTH     40       // Ширина ячейки уровня
#define LEVEL_CELL_HEIGHT    30       // Высота ячейки уровня
#define LEVEL_SPACING_X      50       // Расстояние между ячейками по X
#define LEVEL_SPACING_Y      40       // Расстояние между ячейками по Y
#define LEVEL_HELP_Y         250.0f   // Позиция текста помощи

// Инициализация меню (загрузка текстур и т.д.)
void menu_init(void);

// Обновление логики меню (обработка input)
void menu_update(void);

// Рендеринг меню
void menu_render(void);

// Обновление экрана выбора уровня
void level_select_update(void);

// Рендеринг экрана выбора уровня
void level_select_render(void);

// Обновление about экрана
void about_update(void);

// Рендеринг about экрана  
void about_render(void);

// Обновление high score экрана
void high_score_update(void);

// Рендеринг high score экрана
void high_score_render(void);

// Обновление game over экрана
void game_over_update(void);

// Рендеринг game over экрана
void game_over_render(void);

// Очистка ресурсов меню
void menu_cleanup(void);

#endif