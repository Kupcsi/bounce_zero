#include "graphics.h"
#include "font8.h"
#include "types.h"  // Для SCREEN_WIDTH/SCREEN_HEIGHT
#include <pspgu.h>
#include <pspdisplay.h>
#include <stdint.h>
#include <stddef.h>

#define BUFFER_WIDTH 512
#define BUFFER_HEIGHT 272

// Размеры буферов (байты на пиксель)
#define FRAMEBUFFER_BPP 4  // GU_PSM_8888 = 4 байта на пиксель

// Увеличенный буфер команд GU для более сложной отрисовки
static char list[0x20000] __attribute__((aligned(64))); // 128KB


// VRAM буферы - вычисляются динамически
static void* draw_buffer;
static void* disp_buffer;

// Простые примитивы без текстур
typedef struct {
    short x, y, z;
} Vertex2D;

void graphics_init(void) {
    // Размеры буферов
    const size_t framebuffer_size = BUFFER_WIDTH * BUFFER_HEIGHT * FRAMEBUFFER_BPP;
    
    // Буферы как смещения в VRAM (не абсолютные адреса!)
    draw_buffer = (void*)0;                    // смещение 0
    disp_buffer = (void*)framebuffer_size;     // смещение после первого FB
    
    sceGuInit();

    sceGuStart(GU_DIRECT, list);
    sceGuDrawBuffer(GU_PSM_8888, draw_buffer, BUFFER_WIDTH);
    sceGuDispBuffer(SCREEN_WIDTH, SCREEN_HEIGHT, disp_buffer, BUFFER_WIDTH);
    // Depth buffer не выделяем - не нужен для 2D рендера

    sceGuOffset(2048 - (SCREEN_WIDTH / 2), 2048 - (SCREEN_HEIGHT / 2));
    sceGuViewport(2048, 2048, SCREEN_WIDTH, SCREEN_HEIGHT);
    sceGuEnable(GU_SCISSOR_TEST);
    sceGuScissor(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

    // Включаем альфа-блендинг внутри активного списка
    sceGuEnable(GU_BLEND);
    sceGuBlendFunc(GU_ADD, GU_SRC_ALPHA, GU_ONE_MINUS_SRC_ALPHA, 0, 0);

    // Очистить буферы перед показом (избежать мусора)
    // Цвет уже в ABGR формате, передаём напрямую
    sceGuClearColor(0);
    sceGuClear(GU_COLOR_BUFFER_BIT);
    sceGuFinish();
    sceGuSync(GU_SYNC_FINISH, GU_SYNC_WHAT_DONE);
    sceDisplayWaitVblankStart();
    sceGuDisplay(GU_TRUE);
}

void graphics_start_frame(void) {
    sceGuStart(GU_DIRECT, list);
}

void graphics_clear(u32 color) {
    sceGuClearColor(color);
    sceGuClear(GU_COLOR_BUFFER_BIT);
}

void graphics_draw_rect(float x, float y, float w, float h, u32 color) {
    // Простые прямоугольники без текстур
    Vertex2D* v = (Vertex2D*)sceGuGetMemory(2 * sizeof(Vertex2D));

    v[0].x = (short)x;
    v[0].y = (short)y;
    v[0].z = 0;

    v[1].x = (short)(x + w);
    v[1].y = (short)(y + h);
    v[1].z = 0;

    // sceGuColor принимает цвет в том же ABGR формате что и graphics_clear()
    sceGuColor(color);
    sceGuDrawArray(GU_SPRITES, GU_VERTEX_16BIT | GU_TRANSFORM_2D, 2, 0, v);
}

void graphics_draw_char_scaled(float x, float y, uint8_t c, u32 color, float scale) {
    const Glyph8* glyph = font8_get_glyph(c);

    for (int row = 0; row < 8; row++) {
        for (int col = 0; col < glyph->width; col++) {
            if (glyph->row[row] & (1 << (7 - col))) {
                graphics_draw_rect(x + col * scale, y + row * scale, scale, scale, color);
            }
        }
    }
}

void graphics_draw_char(float x, float y, uint8_t c, u32 color) {
    graphics_draw_char_scaled(x, y, c, color, 1.0f);
}

void graphics_draw_text_scaled(float x, float y, const char* text, u32 color, float scale) {
    if (!text) return;
    float cur_x = x;
    for (int i = 0; text[i] != '\0'; i++) {
        const Glyph8* glyph = font8_get_glyph((uint8_t)text[i]);
        graphics_draw_char_scaled(cur_x, y, (uint8_t)text[i], color, scale);
        cur_x += (glyph->width + FONT8_SPACING) * scale;
    }
}

void graphics_draw_text(float x, float y, const char* text, u32 color) {
    graphics_draw_text_scaled(x, y, text, color, 1.0f);
}

float graphics_measure_text(const char* text, float scale) {
    if (!text) return 0.0f;
    float width = 0.0f;
    for (int i = 0; text[i] != '\0'; i++) {
        const Glyph8* glyph = font8_get_glyph((uint8_t)text[i]);
        width += glyph->width * scale;
        // Добавить spacing только между символами (не после последнего)
        if (text[i + 1] != '\0') {
            width += FONT8_SPACING * scale;
        }
    }
    return width;
}

void graphics_end_frame(void) {
    sceGuFinish();
    sceGuSync(GU_SYNC_FINISH, GU_SYNC_WHAT_DONE);
    sceDisplayWaitVblankStart();
    sceGuSwapBuffers();
}

void graphics_shutdown(void) {
    sceGuDisplay(GU_FALSE);
    sceGuTerm();
}